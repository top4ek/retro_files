		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db  10h, 10h, 10h, 10h, 10h,	0, 10h,	  0
		.db  28h, 28h, 28h,   0,   0,	0,   0,	  0
		.db  18h, 3Ch, 7Eh,0FFh, 3Ch, 3Ch, 3Ch,	  0
		.db    0, 3Ch, 3Ch, 3Ch,0FFh, 7Eh, 3Ch,	18h
		.db  10h, 30h, 7Eh,0FEh,0FEh, 7Eh, 30h,	10h
		.db    8, 0Ch, 7Eh, 7Fh, 7Fh, 7Eh, 0Ch,	  8
		.db  30h, 10h, 20h,   0,   0,	0,   0,	  0
		.db    8, 10h, 20h, 20h, 20h, 10h,   8,	  0
		.db  20h, 10h,	 8,   8,   8, 10h, 20h,	  0
		.db  10h, 54h, 38h, 7Ch, 38h, 54h, 10h,	  0
		.db    0, 18h, 18h, 7Eh, 7Eh, 18h, 18h,	  0
		.db    0,   0,	 0,   0, 30h, 10h, 20h,	  0
		.db    0,   0,	 0, 7Ch,   0,	0,   0,	  0
		.db    0,   0,	 0,   0, 30h, 30h,   0,	  0
		.db    0,   2,	 4,   8, 10h, 20h, 40h,	  0
		.db  3Ch, 42h, 46h, 5Ah, 62h, 42h, 3Ch,	  0
		.db  10h, 30h, 50h, 10h, 10h, 10h, 7Ch,	  0
		.db  3Ch, 42h,	 2, 0Ch, 30h, 40h, 7Eh,	  0
		.db  3Ch, 42h,	 2, 3Ch,   2, 42h, 3Ch,	  0
		.db    4, 0Ch, 14h, 24h, 7Eh,	4,   4,	  0
		.db  7Eh, 40h, 78h,   4,   2, 44h, 38h,	  0
		.db  1Ch, 20h, 40h, 7Ch, 42h, 42h, 3Ch,	  0
		.db  7Eh, 42h,	 4,   8, 10h, 10h, 10h,	  0
		.db  3Ch, 42h, 42h, 3Ch, 42h, 42h, 3Ch,	  0
		.db  3Ch, 42h, 42h, 3Eh,   2,	4, 38h,	  0
		.db    0, 30h, 30h,   0, 30h, 30h,   0,	  0
		.db    0, 30h, 30h,   0, 30h, 10h, 20h,	  0
		.db  0Eh, 18h, 30h, 60h, 30h, 18h, 0Eh,	  0
		.db    0,   0, 7Eh,   0, 7Eh,	0,   0,	  0
		.db  70h, 18h, 0Ch,   6, 0Ch, 18h, 70h,	  0
		.db  3Ch, 42h,	 2, 0Ch, 10h,	0, 10h,	  0
		.db  1Ch, 22h, 4Ah, 56h, 4Ch, 20h, 1Eh,	  0
		.db  18h, 24h, 42h, 7Eh, 42h, 42h, 42h,	  0
		.db  7Ch, 42h, 42h, 7Ch, 42h, 42h, 7Ch,	  0
		.db  1Ch, 22h, 40h, 40h, 40h, 22h, 1Ch,	  0
		.db  78h, 24h, 22h, 22h, 22h, 24h, 78h,	  0
		.db  7Eh, 40h, 40h, 78h, 40h, 40h, 7Eh,	  0
		.db  7Eh, 40h, 40h, 78h, 40h, 40h, 40h,	  0
		.db  1Ch, 22h, 40h, 4Eh, 42h, 22h, 1Ch,	  0
		.db  42h, 42h, 42h, 7Eh, 42h, 42h, 42h,	  0
		.db  38h, 10h, 10h, 10h, 10h, 10h, 38h,	  0
		.db  0Eh,   4,	 4,   4,   4, 44h, 38h,	  0
		.db  42h, 44h, 48h, 70h, 48h, 44h, 42h,	  0
		.db  40h, 40h, 40h, 40h, 40h, 40h, 7Eh,	  0
		.db  42h, 66h, 5Ah, 5Ah, 42h, 42h, 42h,	  0
		.db  42h, 62h, 52h, 4Ah, 46h, 42h, 42h,	  0
		.db  18h, 24h, 42h, 42h, 42h, 24h, 18h,	  0
		.db  7Ch, 42h, 42h, 7Ch, 40h, 40h, 40h,	  0
		.db  18h, 24h, 42h, 42h, 4Ah, 24h, 1Ah,	  0
		.db  7Ch, 42h, 42h, 7Ch, 48h, 44h, 42h,	  0
		.db  3Ch, 42h, 40h, 3Ch,   2, 42h, 3Ch,	  0
		.db  7Ch, 10h, 10h, 10h, 10h, 10h, 10h,	  0
		.db  42h, 42h, 42h, 42h, 42h, 42h, 3Ch,	  0
		.db  42h, 42h, 42h, 24h, 24h, 18h, 18h,	  0
		.db  42h, 42h, 42h, 5Ah, 5Ah, 66h, 42h,	  0
		.db  42h, 42h, 24h, 18h, 24h, 42h, 42h,	  0
		.db  44h, 44h, 44h, 38h, 10h, 10h, 10h,	  0
		.db  7Eh,   2,	 4, 18h, 20h, 40h, 7Eh,	  0
		.db  3Ch, 20h, 20h, 20h, 20h, 20h, 3Ch,	  0
		.db    0,0BFh,0BFh,0BFh,   0,0FBh,0FBh,0FBh
		.db  78h,   8,	 8,   8,   8,	8, 78h,	  0
		.db  10h, 28h, 44h,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0, 7Eh,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   4,	 0,   0,   0,	0,   0,	  0
		.db    0, 80h,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0, 10h,	  0
		.db    0, 10h,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0, 80h,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   8,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	4,   0,	  0
		.db    0,   0,	 1,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   1,	0,   0,	  0
		.db    0,   0,	 0, 7Fh, 21h, 18h, 0Fh,	1Ch
		.db    1,   3,	 5,0D8h,0E8h, 70h,0F8h,0F8h
		.db    3,   1,	 0,   0,   0,	0,   0,	  0
		.db 0E0h,0F8h,0FCh,0C6h, 7Eh, 4Fh, 4Fh,	4Fh
		.db    0,   0, 0Eh, 3Fh, 7Fh, 7Fh,0E7h,0DBh
		.db    0,   0,	 0,0C0h,0F0h,0FCh,0FEh,0FEh
		.db  3Ch, 42h, 46h, 5Ah, 62h, 42h, 3Ch,	  0
		.db  10h, 30h, 50h, 10h, 10h, 10h, 7Ch,	  0
		.db  3Ch, 42h,	 2, 0Ch, 30h, 40h, 7Eh,	  0
		.db  3Ch, 42h,	 2, 3Ch,   2, 42h, 3Ch,	  0
		.db    4, 0Ch, 14h, 24h, 7Eh,	4,   4,	  0
		.db  7Eh, 40h, 78h,   4,   2, 44h, 38h,	  0
		.db  1Ch, 20h, 40h, 7Ch, 42h, 42h, 3Ch,	  0
		.db  7Eh, 42h,	 4,   8, 10h, 10h, 10h,	  0
		.db  3Ch, 42h, 42h, 3Ch, 42h, 42h, 3Ch,	  0
		.db  3Ch, 42h, 42h, 3Eh,   2,	4, 38h,	  0
		.db  36h, 27h,0AFh, 3Fh, 9Fh, 0Eh, 40h,	14h
		.db 0F8h,0F8h,0F8h, 78h, 38h, 18h,   8,	  0
		.db    1,   0,	 1,   7, 7Ch, 3Eh, 1Fh,	  7
		.db 0CFh,0FFh,0FFh,0E6h, 0Eh, 1Ch,0F8h,0E0h
		.db 0DFh, 7Fh, 7Fh, 3Fh, 1Fh,	7,   1,	  0
		.db 0E7h,0FBh,0FFh,0FEh,0FEh,0FCh,0F0h,	  0
		.db    0,   0, 3Ch, 5Eh,0BFh,0FFh, 7Eh,	3Ch
		.db    0,   0, 3Ch, 5Eh,0BFh,0FFh, 7Eh,	3Ch
		.db    0,   0, 3Ch, 5Eh,0BFh,0FFh, 7Eh,	3Ch
		.db    0,   0, 3Ch, 5Eh,0BFh,0FFh, 7Eh,	3Ch
		.db    0,   0, 3Ch, 5Eh,0BFh,0FFh, 7Eh,	3Ch
		.db    0,   0, 3Ch, 5Eh,0BFh,0FFh, 7Eh,	3Ch
		.db    0,   0, 3Ch, 5Eh,0BFh,0FFh, 7Eh,	3Ch
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db  0Ch, 0Ch, 0Ch, 0Ch, 0Ch, 0Ch, 0Ch,	0Ch
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    3,   4,	 3,   0,   7, 0Fh, 0Fh,	0Dh
		.db 0C0h, 20h,0C0h,   0,0E0h,0F0h,0F0h,0B0h
		.db    0,   0,	 0,   0,   0,	1, 11h,	39h
		.db  78h, 84h, 78h,   0,0FCh,0FEh,0FEh,0B4h
		.db  1Eh, 21h, 1Eh,   0, 3Fh, 7Fh, 7Fh,	2Dh
		.db    0,   0,	 0,   0,   0, 80h, 88h,	9Ch
		.db  3Ch, 5Eh,0BFh,0BFh,0FFh,0FFh, 7Eh,	3Ch
		.db  3Ch, 5Eh,0BFh,0BFh,0FFh,0FFh, 7Eh,	3Ch
		.db  3Ch, 5Eh,0BFh,0BFh,0FFh,0FFh, 7Eh,	3Ch
		.db  3Ch, 5Eh,0BFh,0BFh,0FFh,0FFh, 7Eh,	3Ch
		.db  3Ch, 5Eh,0BFh,0BFh,0FFh,0FFh, 7Eh,	3Ch
		.db  3Ch, 5Eh,0BFh,0BFh,0FFh,0FFh, 7Eh,	3Ch
		.db  3Ch, 5Eh,0BFh,0BFh,0FFh,0FFh, 7Eh,	3Ch
		.db  3Ch, 7Eh,0DBh,0DBh,0FFh,0DBh, 66h,	3Ch
		.db  18h, 18h, 18h, 18h, 18h, 3Ch, 3Ch,	18h
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db  45h,0E7h,0F3h,0FEh,0E8h,0E8h,0CEh,	8Eh
		.db 0A2h,0E7h,0CFh, 7Fh, 17h, 17h, 73h,	71h
		.db  5Ch,0AEh, 56h, 2Fh, 3Fh, 3Eh, 76h,	  4
		.db 0B4h,0FCh, 78h,0F8h, 84h,	4, 0Ah,	15h
		.db  2Dh, 3Fh, 1Eh, 1Fh, 21h, 20h, 50h,0A8h
		.db  3Ah, 75h, 6Ah,0F4h,0FCh, 7Ch, 6Eh,	20h
		.db  47h, 3Fh, 3Bh, 1Bh, 1Fh, 87h,0CFh,	78h
		.db  84h,0F4h, 7Ch, 6Ch,0ECh, 8Ch,0CEh,	7Ah
		.db  47h, 3Fh, 3Bh, 1Bh, 1Fh, 0Fh, 0Fh,	18h
		.db  8Ch,0F4h, 7Ch, 6Ch,0ECh,0CCh,0CEh,	7Ah
		.db  47h, 3Fh, 3Bh, 1Bh, 1Fh, 87h,0CFh,	78h
		.db  84h,0F4h, 7Ch, 6Ch,0ECh, 8Ch,0CEh,	7Ah
		.db  47h, 3Fh, 3Bh, 1Bh, 1Fh, 0Fh, 0Fh,	18h
		.db  8Ch,0F4h, 7Ch, 6Ch,0ECh,0CCh,0CEh,	7Ah
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db  0Fh, 0Eh, 0Eh, 0Eh, 1Eh, 1Fh, 39h,	0Eh
		.db 0F0h, 70h, 70h, 70h, 78h,0F8h, 9Ch,	70h
		.db  3Fh, 4Fh,0DFh,0BFh,0FFh, 73h, 1Ch,	  7
		.db 0F8h, 8Eh,0F3h,0FFh,0FFh,0FBh, 1Eh,0F8h
		.db  3Fh, 4Fh,0DFh,0BFh,0FFh, 73h, 1Ch,	  7
		.db 0F8h, 8Eh,0F3h,0FFh,0FFh,0FBh, 1Eh,0F8h
		.db  34h, 14h, 10h, 9Ch,0AFh,0ACh, 6Ch,	1Ch
		.db 0BAh,0AEh, 2Ah,0CAh,0CAh,0CAh,0DAh,0EEh
		.db  34h, 74h,0D0h, 9Ch, 0Fh, 0Ch, 2Ch,	1Ch
		.db 0BAh,0AEh, 2Ah,0CAh,0CAh,0CAh,0DAh,0EEh
		.db  34h, 14h, 10h, 9Ch,0AFh,0ACh, 6Ch,	1Ch
		.db 0BAh,0AEh, 2Ah,0CAh,0CAh,0CAh,0DAh,0EEh
		.db  34h, 74h,0D0h, 9Ch, 0Fh, 0Ch, 2Ch,	1Ch
		.db 0BAh,0AEh, 2Ah,0CAh,0CAh,0CAh,0DAh,0EEh
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,0FFh, 7Fh, 3Fh,   0,	  0
		.db    0,   0,	 0,0FFh,0FFh,0F8h,   0,	  0
		.db    0,   0,	 0,0FFh,0FFh, 1Fh,   0,	  0
		.db    0,   0,	 0,0FFh,0FEh,0FCh,   0,	  0
		.db    0,   0,	 0,0FFh,0FFh,0FFh,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    3, 0Fh, 1Fh, 3Ch, 3Bh, 35h, 15h,	17h
		.db 0C0h,0F0h,0F8h, 3Ch,0DCh,0ACh,0A8h,0E8h
		.db  42h, 42h, 42h, 7Eh, 42h, 42h, 42h,	  0
		.db  38h, 10h, 10h, 10h, 10h, 10h, 38h,	  0
		.db  3Ch, 42h, 40h, 3Ch,   2, 42h, 3Ch,	  0
		.db  1Ch, 22h, 40h, 40h, 40h, 22h, 1Ch,	  0
		.db  18h, 24h, 42h, 42h, 42h, 24h, 18h,	  0
		.db  7Ch, 42h, 42h, 7Ch, 48h, 44h, 42h,	  0
		.db  7Eh, 40h, 40h, 78h, 40h, 40h, 7Eh,	  0
		.db    0, 18h, 18h,   0,   0, 18h, 18h,	  0
		.db  40h, 40h, 40h, 40h, 40h, 40h, 7Eh,	  0
		.db  7Eh, 40h, 40h, 78h, 40h, 40h, 7Eh,	  0
		.db  7Eh, 40h, 40h, 78h, 40h, 40h, 40h,	  0
		.db  7Ch, 10h, 10h, 10h, 10h, 10h, 10h,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    6,   3, 7Fh, 40h, 7Dh, 0Bh, 16h,	3Ch
		.db  60h,0C0h,0FEh,   2,0BEh,0D0h, 68h,	3Ch
		.db    7, 0Bh, 15h, 15h, 17h, 16h, 3Bh,	30h
		.db 0E0h,0D0h,0A8h,0A8h,0E8h, 68h,0DCh,	0Ch
		.db    7, 0Bh, 0Dh, 15h, 17h, 26h, 33h,	1Bh
		.db 0E0h,0D0h,0B0h,0A8h,0E8h, 64h,0CCh,0D8h
		.db  0Fh, 1Fh, 1Eh, 37h, 37h, 1Fh, 0Fh,	  7
		.db    0, 80h, 80h,0C0h,0F8h,0FCh,0FCh,0FCh
		.db    0,   1,	 1,   3, 1Fh, 3Fh, 3Fh,	3Fh
		.db 0F0h,0F8h, 78h,0ECh,0ECh,0F8h,0F0h,0F0h
		.db    3,   7,	 7, 0Dh, 0Dh, 27h, 33h,	38h
		.db 0C0h,0E0h,0E0h,0F0h,0F8h,0F5h,0EDh,	1Bh
		.db    3,   7,	 7, 0Fh, 1Fh,0AFh,0B7h,0D8h
		.db 0C0h,0E0h,0E0h,0B0h,0B0h,0E4h,0CCh,	1Ch
		.db    0,   8,	 4, 20h, 10h,	0,   7,	0Fh
		.db    0, 10h, 20h,   4,   8,	0,0E0h,0F0h
		.db    0,   0, 10h,   8, 40h, 20h,   7,	0Fh
		.db    0,   0,	 8, 10h,   2,	4,0E0h,0F0h
		.db  6Fh, 5Dh, 34h, 75h, 2Fh, 0Eh, 0Eh,	1Eh
		.db 0F6h,0BAh, 2Ch,0AEh,0F4h, 70h, 70h,	78h
		.db  2Fh, 35h, 74h, 35h, 0Fh, 0Eh, 1Ch,	3Ch
		.db 0F4h,0ACh, 2Eh,0ACh,0F0h, 70h, 38h,	3Ch
		.db  1Fh, 3Fh, 7Fh,0EFh,0C7h,	7,   7,	0Fh
		.db  78h, 70h, 60h,   0,   0,	0,   0,	  0
		.db  1Eh, 0Eh,	 6,   0,   0,	0,   0,	  0
		.db 0F8h,0FCh,0FEh,0F7h,0E3h,0E0h,0E0h,0F0h
		.db  1Bh, 0Bh, 43h, 7Fh, 7Fh, 7Eh, 40h,	  0
		.db 0FEh,0F8h,0C2h,0FEh,0FEh, 7Eh,   2,	  0
		.db  7Fh, 1Fh, 43h, 7Fh, 7Fh, 7Eh, 40h,	  0
		.db 0D8h,0D0h,0C2h,0FEh,0FEh, 7Eh,   2,	  0
		.db  1Fh, 5Fh,0DFh,0DFh, 6Fh, 2Fh, 17h,	  3
		.db 0F8h,0F8h,0F8h,0E8h,0C6h,0EFh,0EFh,0DEh
		.db  1Fh, 1Fh, 1Fh, 17h, 63h,0F7h,0F7h,	7Bh
		.db 0F8h,0FAh,0FBh,0FBh,0F6h,0F4h,0E8h,0C0h
