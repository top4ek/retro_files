		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0FAh, 2Ah, 2Ah, 2Ah, 2Ah, 2Ah, 2Ah,	2Ah
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h, 70h, 70h, 70h, 70h,0A0h
		.db  80h, 80h, 80h, 70h, 70h, 70h, 70h,	70h
		.db 0A0h,0A0h,0A0h,0A0h,0A0h,0A0h,0A0h,0A0h
		.db 0A0h,0A0h,0A0h,0A0h,0A0h,0A0h,0A0h,0A0h
		.db 0A0h,0A0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F2h,0F2h,0F2h,0F2h,0F2h,0F2h,0F2h,0F2h
		.db 0F2h,0F2h,0F2h,0F2h,0F2h,0F2h,0F2h,0F2h
		.db 0F2h,0F2h,0F2h,0F2h,0F2h,0F2h,0F2h,0F2h
		.db 0F2h,0F2h,0F2h,0F2h,0F2h,0F2h,0F2h,0F2h
		.db 0F2h,0F2h,0F2h,0F2h,0F2h,0F2h,0F2h,0F2h
		.db 0F2h,0F2h,0F2h,0F2h,0F2h,0F2h,0F2h,0F2h
		.db 0F2h,0F2h,0F2h,0F2h,0F2h,0F2h,0F2h,0F2h
		.db 0F2h,0F2h,0F2h,0F2h,0F2h,0F2h,0F2h,0F2h
		.db 0F2h,0F2h,0F2h,0F2h,0F2h,0F2h,0F2h,0F2h
		.db 0F2h,0F2h,0F2h,0F2h,0F2h,0F2h,0F2h,0F2h
		.db 0A0h,0A0h,0A0h,0A0h,0A0h,0A0h,0A0h,0A0h
		.db  70h, 70h, 70h, 70h, 70h, 70h, 70h,	70h
		.db 0A0h,0A0h,0A0h,0A0h,0A0h,0A0h,0A0h,0A0h
		.db 0A0h,0A0h,0A0h,0A0h,0A0h,0A0h,0A0h,0A0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h, 40h, 40h, 40h, 40h, 40h,	40h
		.db  40h, 40h, 80h, 80h, 80h, 80h, 80h,	80h
		.db  80h, 80h,0D0h,0D0h,0D0h,0D0h,0D0h,0D0h
		.db 0D0h,0D0h, 20h, 20h, 20h, 20h, 20h,	20h
		.db  20h, 20h, 70h, 70h, 70h, 70h, 70h,	70h
		.db  70h, 70h,0A0h,0A0h,0A0h,0A0h,0A0h,0A0h
		.db 0A0h,0A0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db  80h, 80h, 80h, 80h, 80h, 80h, 80h,	80h
		.db  80h, 80h, 80h, 80h, 80h, 80h, 80h,	80h
		.db 0A0h,0A0h,0A0h,0A0h, 80h, 80h,0A0h,0A0h
		.db 0A0h,0A0h,0A0h,0A0h, 80h, 80h,0A0h,0A0h
		.db 0A0h,0A0h,0A0h,0A0h,0A0h, 80h,0A0h,0A0h
		.db 0A0h,0A0h,0A0h,0A0h, 80h, 80h,0A0h,0A0h
		.db 0A0h,0A0h,0A0h,0A0h, 80h, 80h,0A0h,0A0h
		.db 0A0h,0A0h,0A0h,0A0h,0A0h, 80h,0A0h,0A0h
		.db  40h, 40h, 40h, 40h, 40h, 40h, 40h,	40h
		.db  80h, 80h, 80h, 80h, 80h, 80h, 80h,	80h
		.db 0D0h,0D0h,0D0h,0D0h,0D0h,0D0h,0D0h,0D0h
		.db  20h, 20h, 20h, 20h, 20h, 20h, 20h,	20h
		.db  70h, 70h, 70h, 70h, 70h, 70h, 70h,	70h
		.db 0A0h,0A0h,0A0h,0A0h,0A0h,0A0h,0A0h,0A0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db  80h, 80h, 80h, 80h, 80h, 80h, 80h,	80h
		.db  80h, 80h, 80h, 80h, 80h, 80h, 80h,	80h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0A0h,0A0h,0A0h, 70h, 70h, 70h, 70h,	70h
		.db 0A0h,0A0h,0A0h, 70h, 70h, 70h, 70h,	70h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db  40h, 40h,0A0h,0A0h,0A0h,0A0h, 40h,	40h
		.db  40h, 40h,0A0h,0A0h,0A0h,0A0h, 40h,	40h
		.db  40h, 40h,0A0h,0A0h,0A0h,0A0h, 40h,	40h
		.db  40h, 40h,0A0h,0A0h,0A0h,0A0h, 40h,	40h
		.db  40h, 40h,0A0h,0A0h,0A0h,0A0h, 40h,	40h
		.db  40h, 40h,0A0h,0A0h,0A0h,0A0h, 40h,	40h
		.db  40h, 40h,0A0h,0A0h,0A0h,0A0h, 40h,	40h
		.db  40h, 40h,0A0h,0A0h,0A0h,0A0h, 40h,	40h
		.db  40h, 40h, 40h, 40h, 40h, 40h, 40h,	40h
		.db  40h, 40h, 40h, 40h, 40h, 40h, 40h,	40h
		.db 0D0h, 70h, 70h, 70h, 70h, 70h, 70h,	80h
		.db 0D0h, 70h, 70h, 70h, 70h, 70h, 70h,	80h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h, 70h, 70h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h, 70h, 70h,0F0h,0F0h,0F0h,0F0h
		.db  40h, 40h, 40h, 40h, 40h, 40h, 40h,	40h
		.db  40h, 40h, 40h, 40h, 40h, 40h, 40h,	40h
		.db  40h, 40h, 40h, 40h, 40h, 40h, 40h,	40h
		.db  40h, 40h, 40h, 40h, 40h, 40h, 40h,	40h
		.db  40h, 40h, 40h, 40h, 40h, 40h, 40h,	40h
		.db  40h, 40h, 40h, 40h, 40h, 40h, 40h,	40h
		.db  40h, 40h, 40h, 40h, 40h, 40h, 40h,	40h
		.db  40h, 40h, 40h, 40h, 40h, 40h, 40h,	40h
		.db  40h, 40h, 40h, 40h, 40h, 40h, 40h,	40h
		.db  40h, 40h, 40h, 40h, 40h, 40h, 40h,	40h
		.db  40h, 40h, 40h, 40h, 40h, 40h, 40h,	40h
		.db  40h, 40h, 40h, 40h, 40h, 40h, 40h,	40h
		.db  40h, 40h, 40h, 40h, 40h, 40h, 40h,	40h
		.db  40h, 40h, 40h, 40h, 40h, 40h, 40h,	40h
		.db  40h, 40h, 40h, 40h, 40h, 40h, 40h,	40h
		.db  40h, 40h, 40h, 40h, 40h, 40h, 40h,	40h
		.db  40h, 40h, 40h, 40h, 70h, 70h, 70h,	70h
		.db  70h, 70h, 70h, 40h, 70h, 70h, 70h,	70h
		.db  70h, 70h, 70h, 40h, 70h, 70h, 70h,	70h
		.db  70h, 70h, 70h, 40h, 70h, 70h, 70h,	70h
		.db  70h, 70h, 70h, 40h, 70h, 70h, 70h,	70h
		.db  70h, 70h, 70h, 70h, 70h, 70h, 70h,	70h
		.db  70h, 70h, 70h, 70h, 70h, 70h, 70h,	70h
		.db  70h, 70h, 70h, 70h, 70h, 70h, 70h,	70h
		.db  70h, 70h, 70h, 70h, 70h, 70h, 70h,	70h
		.db  70h, 70h, 70h, 70h, 70h, 70h, 70h,	70h
		.db  70h, 70h, 70h, 70h, 70h, 70h, 70h,	70h
		.db  70h, 70h, 70h, 70h, 70h, 70h, 70h,	70h
		.db  70h, 70h, 70h, 70h, 70h, 70h, 70h,	70h
		.db  70h, 70h, 70h, 70h, 70h, 70h, 70h,	70h
		.db 0A0h,0A0h,0A0h,0A0h,0A0h,0A0h,0A0h,0A0h
		.db 0A0h,0A0h,0A0h,0A0h,0A0h,0A0h,0A0h,0A0h
		.db 0F2h,0F2h,0F2h,0F2h,0F2h,0F2h,0F2h,0F2h
		.db 0F2h,0F2h,0F2h,0F2h,0F2h,0F2h,0F2h,0F2h
		.db 0F2h,0F2h,0F2h,0F2h,0F2h,0F2h,0F2h,0F2h
		.db 0F2h,0F2h,0F2h,0F2h,0F2h,0F2h,0F2h,0F2h
		.db 0F2h,0F2h,0F2h,0F2h,0F2h,0F2h,0F2h,0F2h
		.db 0F2h,0F2h,0F2h,0F2h,0F2h,0F2h,0F2h,0F2h
		.db 0F2h,0F2h,0F2h,0F2h,0F2h,0F2h,0F2h,0F2h
		.db 0F2h,0F2h,0F2h,0F2h,0F2h,0F2h,0F2h,0F2h
		.db 0F2h,0F2h,0F2h,0F2h,0F2h,0F2h,0F2h,0F2h
		.db 0F2h,0F2h,0F2h,0F2h,0F2h,0F2h,0F2h,0F2h
		.db 0F2h,0F2h,0F2h,0F2h,0F2h,0F2h,0F2h,0F2h
		.db 0F2h,0F2h,0F2h,0F2h,0F2h,0F2h,0F2h,0F2h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db 0A0h,0A0h,0D0h,0D0h,0D0h,0F0h,0F0h,	80h
		.db 0A0h,0A0h,0D0h,0D0h,0D0h,0F0h,0F0h,	80h
		.db  80h,0A0h,0A0h,0A0h,0A0h,0A0h,0A0h,0D0h
		.db  80h,0A0h,0A0h,0A0h,0A0h,0A0h,0A0h,0D0h
		.db  80h,0A0h,0A0h,0A0h,0A0h,0A0h,0A0h,0D0h
		.db  80h,0A0h,0A0h,0A0h,0A0h,0A0h,0A0h,0D0h
		.db  80h, 80h,0A0h,0A0h,0A0h,0A0h,0A0h,0D0h
		.db 0D0h, 80h, 80h, 80h, 80h, 80h, 80h,	80h
		.db  80h, 80h, 80h, 80h, 80h, 80h, 80h,	80h
		.db  80h, 80h,0A0h,0A0h,0A0h,0A0h,0A0h,0F0h
		.db  80h, 80h,0A0h,0A0h,0A0h,0A0h,0A0h,0D0h
		.db  80h, 80h, 80h, 80h, 80h, 80h, 80h,0D0h
		.db  80h, 80h, 80h, 80h, 80h, 80h, 80h,0D0h
		.db  80h, 80h,0A0h,0A0h,0A0h,0A0h,0A0h,0D0h
		.db 0D0h,0A0h,0A0h,0A0h,0A0h,0A0h, 80h,	80h
		.db  80h,0A0h,0A0h,0A0h,0A0h,0A0h, 80h,	80h
		.db  80h, 80h,0A0h,0A0h,0A0h,0A0h, 80h,	80h
		.db  80h, 80h,0A0h,0A0h,0A0h,0A0h, 80h,	80h
		.db 0D0h,0D0h,0D0h,0D0h,0F0h,0F0h,0F0h,	80h
		.db 0D0h,0D0h,0D0h,0D0h,0F0h,0F0h,0F0h,	80h
		.db 0D0h,0D0h,0D0h,0D0h,0F0h,0F0h,0F0h,	80h
		.db 0D0h,0D0h,0D0h,0D0h,0F0h,0F0h,0F0h,	80h
		.db 0D0h,0D0h,0D0h,0F0h,0F0h,0F0h,0F0h,	80h
		.db  80h, 80h, 80h, 80h, 80h, 80h, 80h,	80h
		.db  80h, 80h, 80h, 80h, 80h, 80h, 80h,	80h
		.db 0D0h,0D0h,0D0h,0F0h,0F0h,0F0h,0F0h,	80h
		.db 0D0h,0D0h,0D0h,0F0h,0F0h,0F0h, 80h,	80h
		.db 0D0h,0D0h,0D0h,0F0h,0F0h,0F0h, 80h,	80h
		.db 0D0h,0D0h,0D0h,0F0h,0F0h,0F0h, 80h,	80h
		.db 0D0h,0D0h,0D0h,0F0h,0F0h,0F0h, 80h,	80h
		.db  80h, 80h, 80h, 80h, 80h, 80h, 80h,	80h
		.db  80h, 80h, 80h, 80h, 80h, 80h, 80h,	80h
		.db  80h, 80h, 80h, 80h, 80h, 80h, 80h,	80h
		.db  80h, 80h, 80h, 80h, 80h, 80h, 80h,	80h
