demobeg:
		.db    0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,0BFh
		.db 0BFh,0BFh,0BFh,0BFh,0BFh,0BFh,0BFh,0BFh,0BFh,0BFh,0BFh,0BFh,0BFh,0BFh,0BFh,0BFh
		.db 0BFh,0BFh,0BFh,0BFh,0BFh,0BFh,0BFh,0BFh,0BFh,0BFh,0BFh,0BFh,0BFh,0BFh, 7Fh,0BFh
		.db 0BFh, 7Fh, 7Fh, 7Fh, 7Fh,0EFh,0EFh,0EFh,0EFh,0EFh,0EFh,0EFh,0EFh,0EFh,0EFh,0EFh
		.db 0EFh,0EFh,0EFh,0EFh,0EFh,0EFh,0EFh,0EFh,0EFh,0EFh,0EFh,0EFh,0EFh,0EFh,0EFh,0EFh
		.db 0EFh,0EFh,0EFh,0EFh,0EFh,0DFh,0DFh,0DFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh
		.db 0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh
		.db 0FFh,0FFh,0FFh, 7Fh, 7Fh,0FFh,0FFh,0FFh,0FFh,0BFh,0BFh,0BFh,0BFh,0BFh,0BFh,0BFh
		.db 0BFh,0BFh,0BFh,0BFh,0BFh,0BFh,0BFh,0BFh,0BFh,0BFh,0BFh,0BFh,0BFh,0BFh,0BFh,0BFh
		.db 0BFh,0BFh,0BFh,0BFh,0BFh,0BFh,0BFh,0BFh,0FFh,0FFh,0FFh,0BFh,0BFh,0BFh,0FFh,0FFh
		.db 0DFh,0DFh,0FFh,0FFh,0EFh,0EFh,0EFh,0FFh,0BFh,0BFh,0BFh,0BFh,0BFh,0FFh,0FFh,0FFh
		.db 0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh
		.db 0FFh,0FFh,0EFh,0EFh,0EFh,0EFh,0EFh,0EFh,0EFh,0EFh,0EFh,0EFh,0EFh,0EFh,0EFh,0EFh
		.db 0EFh,0EFh,0EFh,0EFh,0EFh,0EFh,0EFh,0EFh,0EFh,0EFh,0EFh,0EFh,0EFh,0EFh,0EFh,0EFh
		.db 0EFh,0EFh,0DFh,0DFh,0DFh,0FFh,0FFh,0FFh,0BFh,0BFh,0BFh,0BFh,0BFh,0BFh,0BFh,0BFh
		.db 0BFh,0BFh,0BFh,0BFh,0BFh,0BFh,0BFh,0BFh,0BFh,0BFh,0BFh,0BFh,0BFh,0BFh,0BFh,0BFh
		.db 0BFh,0BFh,0BFh,0BFh,0BFh,0BFh,0BFh,0BFh, 7Fh,0FFh,0FFh,0BFh, 7Fh, 7Fh, 7Fh,	7Fh
		.db 0FFh,0FFh,0EFh,0EFh,0FFh,0FFh,0BFh,0BFh,0BFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh
		.db 0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0BFh,0BFh,0BFh,0BFh,0DFh
		.db 0DFh,0DFh,0FFh,0FFh,0FFh,0FFh,0BFh,0BFh,0BFh,0FFh,0DFh,0DFh,0DFh,0FFh,0FFh,0FFh
		.db 0BFh,0BFh,0FFh,0FFh,0EFh,0EFh,0EFh,0EFh,0EFh,0FFh,0FFh, 7Fh, 7Fh, 7Fh, 7Fh,0FFh
		.db 0FFh,0FFh,0BFh,0BFh,0BFh,0FFh,0FFh,0FFh,0FFh,0FFh,0BFh,0BFh,0FFh,0FFh,0FFh,0FFh
		.db 0FFh,0FFh, 7Fh, 7Fh, 7Fh, 7Fh, 7Fh,	7Fh, 7Fh,0FFh,0EFh,0EFh,0EFh,0FFh,0DFh,0DFh
		.db 0DFh,0DFh,0FFh,0EFh,0EFh,0EFh,0FFh,	7Fh,0FFh,0EFh,0EFh,0EFh,0EFh,0FFh, 7Fh,0FFh
		.db 0FFh,0FFh,0DFh,0DFh,0FFh,0FFh, 7Fh,	7Fh, 7Fh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh
		.db 0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0EFh,0EFh,0FFh
		.db 0FFh,0DFh,0FFh,0FFh, 7Fh,0FFh,0FFh,0FFh,0BFh,0BFh,0BFh,0BFh,0FFh,0FFh,0FFh,	7Fh
		.db  7Fh,0FFh,0FFh,0FFh,0EFh,0EFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh
		.db 0EFh,0EFh,0EFh,0EFh,0FFh,0DFh,0DFh,0FFh,0EFh,0EFh,0EFh,0EFh,0EFh,0EFh,0EFh,0FFh
		.db 0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0EFh,0EFh,0EFh,0EFh,0EFh,0EFh,0EFh,0EFh
		.db 0EFh,0DFh,0DFh,0DFh,0BFh,0BFh,0BFh,0BFh,0BFh,0BFh,0BFh,0BFh,0BFh,0BFh,0BFh,	7Fh
		.db  7Fh, 7Fh, 7Fh,0EFh,0EFh,0EFh,0EFh,0EFh,0EFh,0EFh,0EFh,0EFh,0EFh,0EFh,0EFh,0DFh
		.db 0DFh,0DFh,0DFh,0DFh,0FFh,0FFh,0EFh,0EFh,0EFh,0FFh,0BFh,0BFh,0BFh,0FFh, 7Fh,	7Fh
		.db  7Fh, 7Fh,0FFh,0FFh,0EFh,0EFh,0EFh,0EFh,0EFh,0EFh,0EFh,0EFh,0FFh,0FFh,0FFh,	7Fh
		.db  7Fh, 7Fh, 7Fh,0FFh,0FFh,0EFh,0FFh,0FFh,0BFh,0BFh,0FFh,0FFh,0EFh,0FFh,0FFh,0FFh
		.db 0FFh,0DFh,0DFh,0DFh,0DFh,0FFh,0FFh,0FFh,0EFh,0EFh,0EFh,0EFh,0FFh,0FFh,0DFh,0DFh
		.db 0FFh,0FFh,0EFh,0FFh,0FFh,0DFh,0FFh,0FFh, 7Fh, 7Fh, 7Fh,0FFh,0FFh,0FFh,0FFh,0FFh
		.db 0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh, 7Fh, 7Fh, 7Fh, 7Fh,	7Fh
		.db  7Fh, 7Fh, 7Fh, 7Fh,0FFh,0FFh,0DFh,0DFh,0DFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0DFh
		.db 0DFh,0DFh,0DFh,0DFh,0DFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh
		.db 0BFh,0BFh,0BFh,0BFh,0BFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh
		.db 0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0BFh,0BFh,0FFh,0FFh,0FFh,0FFh
		.db 0FFh,0FFh, 7Fh, 7Fh,0FFh,0FFh,0BFh,0FFh, 7Fh, 7Fh,0FFh,0FFh,0BFh, 7Fh, 7Fh,	7Fh
		.db  7Fh,0FFh,0FFh,0FFh,0BFh,0BFh,0BFh,0BFh,0FFh,0FFh,0DFh,0DFh,0FFh,0FFh, 7Fh,0FFh
		.db 0EFh,0EFh,0EFh,0FFh,0FFh,0BFh,0BFh,0BFh,0FFh, 7Fh,0FFh,0BFh,0BFh,0FFh,0FFh,0DFh
		.db 0FFh,0BFh,0BFh,0DFh,0DFh,0DFh,0FFh,0FFh,0EFh,0EFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh
		.db 0BFh,0BFh,0BFh,0FFh,0FFh,0DFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0BFh
		.db 0BFh,0BFh,0BFh,0BFh,0BFh,0FFh,0FFh,0FFh,0FFh,0DFh,0FFh,0EFh,0EFh, 7Fh, 7Fh,	7Fh
		.db  7Fh, 7Fh,0FFh,0FFh,0BFh,0FFh,0FFh,0EFh,0FFh, 7Fh, 7Fh, 7Fh,0FFh,0FFh,0FFh,0FFh
		.db 0FFh,0FFh,0FFh,0BFh,0BFh,0BFh,0BFh,0BFh,0BFh,0BFh,0FFh,0DFh,0DFh,0DFh,0DFh,0DFh
		.db 0DFh,0DFh,0FFh,0FFh,0FFh,0FFh,0EFh,0EFh,0EFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0BFh
		.db 0BFh,0BFh,0BFh,0BFh,0BFh,0BFh,0FFh,	7Fh,0FFh,0BFh,0BFh,0BFh,0BFh,0FFh,0FFh,0DFh
		.db 0FFh, 7Fh,0FFh,0EFh,0EFh,0EFh,0EFh,0FFh,0FFh, 7Fh,0FFh,0FFh,0FFh,0DFh,0DFh,0FFh
		.db  7Fh, 7Fh,0EFh,0EFh,0EFh,0EFh,0FFh,0FFh, 7Fh, 7Fh, 7Fh,0FFh,0FFh,0FFh,0FFh,0FFh
		.db 0FFh,0FFh,0FFh,0FFh,0FFh,0BFh,0BFh,0BFh,0BFh,0BFh,0BFh, 7Fh, 7Fh, 7Fh, 7Fh,0FFh
		.db 0FFh,0FFh,0DFh,0DFh,0DFh,0DFh,0DFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh
demoend:
ZGSYM:		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db  18h,   0, 18h, 18h, 3Ch, 3Ch, 18h,	  0
		.db    0,   0,	 0,   0, 6Ch, 6Ch, 6Ch,	  0
		.db  6Ch, 6Ch,0FEh, 6Ch,0FEh, 6Ch, 6Ch,	  0
		.db    8, 7Eh, 0Bh, 3Eh, 68h, 3Fh,   8,	  0
		.db 0C6h, 66h, 30h, 18h,0CCh,0C6h,   0,	  0
		.db  76h,0CCh,0DCh, 76h, 38h, 6Ch, 38h,	  0
		.db    0,   0,	 0,   0, 30h, 18h, 18h,	  0
		.db  0Ch, 18h, 30h, 30h, 30h, 18h, 0Ch,	  0
		.db  30h, 18h, 0Ch, 0Ch, 0Ch, 18h, 30h,	  0
		.db    0, 66h, 3Ch,0FFh, 3Ch, 66h,   0,	  0
		.db    0, 18h, 18h, 7Eh, 18h, 18h,   0,	30h
		.db  18h, 18h,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0, 7Eh,   0,	0,   0,	  0
		.db  18h, 18h,	 0,   0,   0,	0,   0,	  0
		.db  80h,0C0h, 60h, 30h, 18h, 0Ch,   6,	  0
		.db  7Ch,0C6h,0E6h,0D6h,0CEh,0C6h, 7Ch,	  0
		.db  3Ch, 18h, 18h, 18h, 78h, 38h, 18h,	  0
		.db 0FEh, 30h, 18h, 0Ch,0C6h,0C6h, 7Ch,	  0
		.db  7Ch,0C6h,	 6, 7Ch,   8, 0Ch,0FEh,	  0
		.db    6,   6,	 6,0FEh,0C6h,0C6h,0C6h,	  0
		.db  7Ch,0C6h,	 6,   6,0FCh,0C0h,0FEh,	  0
		.db  7Ch,0C6h,0C6h,0FCh,0C0h,0C0h, 7Ch,	  0
		.db  18h, 18h, 18h, 18h, 0Ch,	6,0FEh,	  0
		.db  7Ch,0C6h,0C6h, 7Ch,0C6h,0C6h, 7Ch,	  0
		.db  7Ch,0C6h,	 6, 7Eh,0C6h,0C6h, 7Ch,	  0
		.db    0, 18h, 18h,   0, 18h, 18h,   0,	  0
		.db  30h, 18h, 18h,   0, 18h, 18h,   0,	  0
		.db  0Ch, 18h, 30h, 60h, 30h, 18h, 0Ch,	  0
		.db    0, 7Eh,	 0,   0, 7Eh,	0,   0,	  0
		.db  60h, 30h, 18h, 0Ch, 18h, 30h, 60h,	  0
		.db  18h,   0, 18h, 0Ch, 66h, 66h, 3Ch,	  0
		.db 0C0h, 9Ch, 74h, 12h,0E3h, 32h, 22h,	13h
		.db  27h, 4Bh,0B5h, 74h, 10h, 28h, 49h,	80h
		.db 0F1h, 3Ah, 13h,0C8h, 12h, 82h, 3Ch,	0Dh
		.db  55h, 9Bh, 33h, 33h, 33h,0FAh, 3Ch,	  0
		.db 0F8h, 6Ch, 66h, 66h, 66h, 6Ch,0F8h,	  0
		.db 0FEh,0C2h,0C0h,0F8h,0C0h,0C2h,0FEh,	  0
		.db 0C0h,0C0h,0C0h,0F0h,0C0h,0C2h,0FEh,	  0
		.db  3Eh, 66h,0CEh,0C0h,0C0h, 66h, 3Ch,	  0
		.db  66h, 66h, 66h, 7Eh, 66h, 66h, 66h,	  0
		.db  7Eh, 18h, 18h, 18h, 18h, 18h, 7Eh,	  0
		.db  78h,0CCh,0CCh, 0Ch, 0Ch, 0Ch, 1Eh,	  0
		.db 0E6h, 66h, 6Ch, 78h, 6Ch, 66h,0E6h,	  0
		.db 0FEh, 66h, 62h, 60h, 60h, 60h,0F0h,	  0
		.db 0C6h,0C6h,0D6h,0FEh,0FEh,0EEh,0C6h,	  0
		.db 0C6h,0C6h,0CEh,0DEh,0F6h,0E6h,0C6h,	  0
		.db  38h, 6Ch,0C6h,0C6h,0C6h, 6Ch, 38h,	  0
		.db 0F0h, 60h, 60h, 7Ch, 66h, 66h,0FCh,	  0
		.db  7Ah,0CCh,0CEh,0C6h,0C6h,0C6h, 7Ch,	  0
		.db 0E6h, 66h, 6Ch, 7Ch, 66h, 66h,0FCh,	  0
		.db  3Ch, 66h,	 6, 3Ch, 60h, 66h, 3Ch,	  0
		.db  18h, 18h, 18h, 18h, 18h, 5Ah, 7Eh,	  0
		.db  3Ch, 66h, 66h, 66h, 66h, 66h, 66h,	  0
		.db  18h, 3Ch, 66h, 66h, 66h, 66h, 66h,	  0
		.db 0C6h,0EEh,0FEh,0D6h,0C6h,0C6h,0C6h,	  0
		.db 0C6h,0C6h, 6Ch, 38h, 38h, 6Ch,0C6h,	  0
		.db  3Ch, 18h, 18h, 3Ch, 66h, 66h, 66h,	  0
		.db 0FEh, 66h, 32h, 18h, 8Ch,0C6h,0FEh,	  0
		.db  3Ch, 30h, 30h, 30h, 30h, 30h, 3Ch,	  0
		.db    2,   6, 0Ch, 18h, 30h, 60h,0C0h,	  0
		.db  3Ch, 0Ch, 0Ch, 0Ch, 0Ch, 0Ch, 3Ch,	  0
		.db    0,   0,	 0,   0, 66h, 3Ch, 18h,0FFh
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db 0CEh,0DBh,0DBh,0FBh,0DBh,0DBh,0CEh,	  0
		.db 0C6h,0C6h,0FEh, 66h, 36h, 1Eh, 0Eh,	  0
		.db 0FCh,0C6h,0C6h,0FCh,0C0h,0C0h,0FCh,	  0
		.db 0FEh,0CCh,0CCh,0CCh,0CCh,0CCh,0CCh,	  0
		.db 0FFh, 66h, 66h, 66h, 66h, 66h, 7Eh,	  0
		.db 0FEh,0C0h,0C0h,0F8h,0C0h,0C0h,0FCh,	  0
		.db  18h, 7Eh,0DBh,0DBh,0DBh, 7Eh, 18h,	  0
		.db 0C0h,0C0h,0C0h,0C0h,0C0h,0C0h,0FCh,	  0
		.db 0C3h, 66h, 3Ch, 18h, 3Ch, 66h,0C3h,	  0
		.db 0C6h,0E6h,0F6h,0DEh,0CEh,0C6h,0C6h,	  0
		.db 0C6h,0E6h,0F6h,0DEh,0CEh,0C6h,0D6h,	  0
		.db 0C6h,0C6h,0CCh,0F8h,0D8h,0CCh,0C6h,	  0
		.db 0C6h,0C6h, 66h, 36h, 1Eh, 0Eh,   6,	  0
		.db 0C6h,0C6h,0C6h,0D6h,0FEh,0EEh,0C6h,	  0
		.db 0C6h,0C6h,0C6h,0FEh,0C6h,0C6h,0C6h,	  0
		.db  7Ch,0C6h,0C6h,0C6h,0C6h,0C6h, 7Ch,	  0
		.db 0C6h,0C6h,0C6h,0C6h,0C6h,0C6h,0FEh,	  0
		.db 0C6h, 66h, 36h, 7Eh,0C6h,0C6h, 7Eh,	  0
		.db 0C0h,0C0h,0C0h,0FCh,0C6h,0C6h,0FCh,	  0
		.db  7Ch,0C6h,0C0h,0C0h,0C0h,0C6h, 7Ch,	  0
		.db  30h, 30h, 30h, 30h, 30h, 30h,0FCh,	  0
		.db  7Ch,0C6h,	 6, 7Eh,0C6h,0C6h,0C6h,	  0
		.db 0DBh,0DBh, 7Eh, 18h, 7Eh,0DBh,0DBh,	  0
		.db 0FCh,0C6h,0C6h,0FCh,0CCh,0CCh,0F8h,	  0
		.db 0FCh,0C6h,0C6h,0FCh,0C0h,0C0h,0C0h,	  0
		.db 0F2h,0DAh,0DAh,0F2h,0C2h,0C2h,0C2h,	  0
		.db  7Ch,0C6h,	 6, 3Ch,   6, 66h, 3Ch,	  0
		.db 0FEh,0D6h,0D6h,0D6h,0D6h,0D6h,0D6h,	  0
		.db  7Ch,0C6h,	 6, 1Eh,   6,0C6h, 7Ch,	  3
		.db 0FFh,0D6h,0D6h,0D6h,0D6h,0D6h,0D6h,	  0
		.db    6,   6,	 6, 7Eh,0C6h,0C6h,0C6h,	  0
		.db  3Eh, 33h, 33h, 3Eh, 30h, 30h,0F0h,	  0
		.db    0, 88h,	 0, 22h,   0, 88h,   0,	22h
		.db  55h,0AAh, 55h,0AAh, 55h,0AAh, 55h,0AAh
		.db    0, 76h,0FEh,0DCh,0FEh, 76h,0FEh,0DCh
		.db  10h, 10h, 10h, 10h, 10h, 10h, 10h,	10h
		.db  10h, 10h, 10h,0F0h, 10h, 10h, 10h,	10h
		.db  10h, 10h,0F0h, 10h,0F0h, 10h, 10h,	10h
		.db  28h, 28h, 28h,0E8h, 28h, 28h, 28h,	28h
		.db  28h, 28h, 28h,0F8h,   0,	0,   0,	  0
		.db  10h, 10h,0F0h, 10h,0F0h,	0,   0,	  0
		.db  28h, 28h,0E8h,   8,0E8h, 28h, 28h,	28h
		.db  28h, 28h, 28h, 28h, 28h, 28h, 28h,	28h
		.db  28h, 28h,0E8h,   8,0F8h,	0,   0,	  0
		.db    0,   0,0F8h,   8,0E8h, 28h, 28h,	28h
		.db  28h,   0,	 0,0F8h, 28h, 28h, 28h,	28h
		.db    0,   0,0F0h, 10h,0F0h, 10h, 10h,	10h
		.db  10h, 10h, 10h,0F0h,   0,	0,   0,	  0
		.db    0,   0,	 0, 1Fh, 10h, 10h, 10h,	10h
		.db    0,   0,	 0,0FFh, 10h, 10h, 10h,	10h
		.db  10h, 10h, 10h,0FFh,   0,	0,   0,	  0
		.db  10h, 10h, 10h, 1Fh, 10h, 10h, 10h,	10h
		.db    0,   0,	 0,0FFh,   0,	0,   0,	  0
		.db  10h, 10h, 10h,0FFh, 10h, 10h, 10h,	10h
		.db  10h, 10h, 1Fh, 10h, 1Fh, 10h, 10h,	10h
		.db  28h, 28h, 28h, 2Fh, 28h, 28h, 28h,	28h
		.db    0,   0, 3Fh, 20h, 2Fh, 28h, 28h,	28h
		.db  28h, 28h, 2Fh, 20h, 3Fh,	0,   0,	  0
		.db    0,   0,0FFh,   0,0EFh, 28h, 28h,	28h
		.db  28h, 28h,0EFh,   0,0FFh,	0,   0,	  0
		.db  28h, 28h, 2Fh, 20h, 2Fh, 28h, 28h,	28h
		.db    0,   0,0FFh,   0,0FFh,	0,   0,	  0
		.db    0, 28h, 28h,0EFh,   0,0EFh, 28h,	28h
		.db  28h,   0,0FFh,   0,0FFh, 10h, 10h,	10h
AVTGRF:		.db 0A8h,0E8h, 8Ah,0AAh,0A1h,0C2h, 22h,	93h,0AAh, 80h, 49h,0E7h, 9Eh, 7Ch,0F3h,0C0h
		.db  92h, 71h,0A8h,0A8h, 8Eh,0AAh,0E1h,	42h, 23h, 92h,0ABh, 80h, 49h,	4, 90h,	24h
		.db  82h, 40h,0F0h,   8,0AEh,0A8h,0EAh,0AAh,0A1h, 42h, 3Ah,0BAh,0B2h, 8Eh, 49h,0C7h
		.db  9Ch, 24h,0E3h, 80h, 90h, 10h,0AAh,0A8h,0AAh,0EEh,0A1h, 42h, 2Ah,0BAh,0AAh,	80h
		.db  49h,   4, 10h, 24h, 82h, 40h, 90h,	  8,0EEh,0EEh,0E4h,0AAh, 41h, 43h,0B9h,	12h
		.db 0A9h,   0, 39h,0E7h, 9Eh, 1Ch,0F3h,0C0h, 70h, 70h,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0
		.db  7Fh,0E0h, 7Fh,   0, 60h, 70h, 7Fh,	80h, 7Fh,   0, 7Fh, 80h, 60h,	0, 60h,	70h
		.db  7Fh,0FEh,0FFh,0F0h,0FFh, 80h,0F0h,0F8h,0FFh,0E0h,0FFh, 80h,0FFh,0E0h,0F0h,	  0
		.db 0F0h,0F8h,0FFh,0FFh,0F0h, 78h,0F1h,0C0h,0F0h,0F8h,0F0h,0F0h,0F1h,0C0h,0F0h,0F0h
		.db 0F0h,   0,0F0h,0F8h,0FFh,0FFh,0E0h,	3Ch,0E0h,0E0h,0F0h,0F8h,0E0h, 38h,0E0h,0E0h
		.db 0E0h, 38h,0F0h,   0,0F0h,0F8h, 7Fh,0FEh,0F0h, 1Ch,0F0h, 70h,0F0h, 7Ch,0F0h,	  0
		.db 0F0h, 70h,0F0h,   0,0F0h,	0,0F0h,	7Ch, 1Ch, 38h,0F0h, 1Ch,0F0h, 78h,0F8h,	7Ch
		.db  78h,   0,0F0h, 78h, 78h,	0,0F0h,	  0,0F8h, 7Ch, 1Ch, 3Ch,0F8h, 3Ch,0F8h,	38h
		.db  78h, 3Ch, 3Eh,   0,0F8h, 38h, 3Eh,	  0,0F0h,   0, 7Fh,0FCh, 1Ch, 1Ch, 7Fh,0F8h
		.db  78h, 3Ch, 78h, 3Ch, 0Fh,0E0h, 78h,	3Ch, 0Fh,0E0h, 77h,0E0h, 7Fh,0FCh, 1Ch,	1Eh
		.db  7Fh,0F0h, 7Ch, 1Ch, 3Ch, 1Eh,   1,0F8h, 7Ch, 1Ch,	 1,0F8h, 7Fh,0F8h, 3Eh,	3Eh
		.db  0Eh, 0Eh, 3Ch, 1Ch, 3Ch, 1Eh, 3Ch,	1Eh,   0, 1Ch, 3Ch, 1Eh,   0, 1Ch, 7Ch,	1Ch
		.db  3Ch, 1Eh, 0Eh, 0Eh, 3Eh, 0Eh, 3Eh,	0Eh, 1Eh, 0Eh,	 0, 0Eh, 3Eh, 0Eh,   0,	0Eh
		.db  3Ch, 0Eh, 1Eh, 0Eh, 0Fh,	7, 1Eh,	  7, 1Eh, 0Eh, 0Eh, 0Eh, 1Ch, 0Fh, 1Eh,	0Eh
		.db  1Ch, 0Fh, 3Ch, 0Fh, 0Eh, 0Eh,   7,	  7, 0Fh,   3, 0Fh,   6,   7,	6, 1Eh,	  7
		.db  0Fh,   6, 1Eh,   7, 1Eh,	7,   7,	  6,   7, 83h,	 7, 87h,   7, 8Eh,   3,	8Eh
		.db  0Fh, 0Fh,	 7, 8Eh, 0Fh, 0Fh, 0Fh,	0Fh,   3, 8Eh,	 3,0C7h,   3,0FFh,   3,0FEh
		.db    1,0FEh,	 7,0FEh,   3,0FEh,   7,0FEh,   7,0FEh,	 1,0FEh,   1,0FFh,   0,0FEh
		.db    0,0FCh,	 0, 7Ch,   1,0FCh,   0,0FCh,   1,0FCh,	 1,0FCh,   0, 7Ch,   0,	7Eh
		.db    0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0
BAZGRF:		.db    0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,0EFh,0EFh,0EFh,   0,0FBh,0FBh,0FBh,   0,0EFh,0EFh,0EFh,   0,0FBh,0FBh,0FBh
		.db    0, 7Bh, 7Bh, 7Bh,   0,0EFh,0EFh,0EFh,   0, 7Bh, 7Bh, 7Bh,   0,0EFh,0EFh,0EFh
		.db  44h,0AAh, 11h,0AAh, 44h,0AAh, 11h,0AAh, 44h,0AAh, 11h,0AAh, 44h,0AAh, 11h,0AAh
		.db  44h,0AAh, 11h,0AAh, 44h,0AAh, 11h,0AAh, 44h,0AAh, 11h,0AAh, 44h,0AAh, 11h,0AAh
		.db    7, 18h, 21h, 42h, 49h, 85h,0AAh,	9Dh,0D7h, 9Bh,0B5h, 4Fh, 4Bh, 26h, 18h,	  7
		.db 0E0h, 18h,	 4, 42h, 62h,0A9h,0DDh,0FBh,0FEh,0DFh,0FDh,0FEh,0FAh,0F4h, 18h,0E0h
		.db    0,   0,	 1,   2,   4,	8, 10h,	20h, 2Ah, 14h, 0Ah,   4,   2,	1,   0,	  0
		.db    0,   0, 80h,0C0h,0A0h,0D0h,0F8h,	24h,0FEh,0ACh,0F8h,0B0h,0E0h,0C0h, 80h,	  0
		.db    1,   2,	 4, 0Ah, 18h, 22h, 50h,	80h,0AAh, 5Eh, 2Ah, 14h, 0Ah,	5,   2,	  1
		.db  80h, 40h,0A0h,0D0h,0A8h,0D4h,0FEh,	15h,0FFh,0BEh,0FCh,0F8h,0F0h,0E0h,0C0h,	80h
		.db    9,   2, 24h, 0Ah, 94h, 2Ah, 54h,	80h,0BFh, 5Ah, 2Eh, 95h, 0Ah, 25h,   2,	  9
		.db  90h,0C0h,0E4h,0B0h,0F9h,0ECh,0FEh,	95h,0FFh,0FEh,0FCh,0F9h,0F0h,0E4h,0C0h,	90h
		.db    0, 7Fh, 7Fh, 60h, 60h, 60h, 63h,	63h, 63h, 63h, 60h, 60h, 60h, 7Fh, 7Fh,	  0
		.db    0,0FEh,0FEh,   6,   6,	6,0C6h,0C6h,0C6h,0C6h,	 6,   6,   6,0FEh,0FEh,	  0
		.db    0, 7Fh, 7Fh, 60h, 60h, 66h, 66h,	60h, 60h, 66h, 66h, 60h, 60h, 7Fh, 7Fh,	  0
		.db    0,0FEh,0FEh,   6,   6, 66h, 66h,	  6,   6, 66h, 66h,   6,   6,0FEh,0FEh,	  0
		.db    0, 7Fh, 40h, 58h, 58h, 40h, 40h,	40h, 40h, 40h, 40h, 58h, 58h, 40h, 7Fh,	  0
		.db    0,0FEh,	 2, 1Ah, 1Ah,	2,   2,	  2,   2,   2,	 2, 1Ah, 1Ah,	2,0FEh,	  0
		.db    0,   0,	 0,   0,   2, 10h,   9,	  2, 0Bh, 22h,	 8, 21h,   1,	0,   0,	  0
		.db    0,   0, 80h,   0, 20h,	0, 88h,0A0h, 40h,0A0h, 10h,   0,   0,	0,   0,	  0
		.db    0, 20h,	 4,   0, 22h, 18h,   9,	43h, 0Bh, 22h, 88h, 21h, 0Dh,	8, 10h,	  0
		.db    0,   0, 80h,   8, 20h, 84h, 88h,0A0h,0CCh,0A0h, 30h,   8, 42h,	0, 40h,	  0
		.db    0, 20h, 14h, 0Ah, 23h, 18h,   8,	62h,   9, 24h, 8Bh, 21h, 0Dh, 4Ah, 10h,	  4
		.db    0, 40h,0A0h,   8, 22h,0ACh, 98h,	30h, 4Fh,0A4h, 30h,   8, 62h, 28h, 50h,	  8
		.db    1,   1,	 1,   1,   1,	1,   1,	  1,   1,   1,	 1,   1,   1,	1,   1,	  1
		.db  80h, 80h, 80h, 80h, 80h, 80h, 80h,	80h, 80h, 80h, 80h, 80h, 80h, 80h, 80h,	80h
		.db  11h, 19h, 19h, 15h, 15h, 13h, 15h,	15h, 15h, 15h, 13h, 15h, 15h, 19h, 19h,	11h
		.db  88h, 98h, 98h,0A8h,0A8h,0C8h,0A8h,0A8h,0A8h,0A8h,0C8h,0A8h,0A8h, 98h, 98h,	88h
		.db  81h,0C1h,0A1h, 91h,0A9h,0A5h,0B3h,0B9h,0B1h,0A3h,0A5h, 89h, 91h,0A1h,0C1h,	81h
		.db  81h, 83h, 85h, 89h, 95h,0A5h,0CDh,	9Dh, 8Dh,0C5h,0A5h, 91h, 89h, 85h, 83h,	81h
		.db  78h,   8,	 8, 0Ch,   6, 23h, 21h,	19h, 0Dh,   3, 1Fh, 3Eh, 23h, 23h, 1Ch,	  8
		.db  1Eh, 10h, 10h, 30h, 60h,0C4h, 84h,	98h,0B0h,0C0h,0F8h, 7Ch,0C4h,0C4h, 38h,	10h
		.db  78h,   8,	 8, 0Ch,   6, 23h, 21h,	19h, 0Dh,   3, 1Fh, 3Eh, 23h, 23h, 1Ch,	  8
		.db  1Eh, 10h, 10h, 30h, 60h,0C4h, 84h,	98h,0B0h,0C0h,0F8h, 7Ch,0C4h,0C4h, 38h,	10h
		.db  78h,   8,	 8, 0Ch,   6, 23h, 21h,	19h, 0Dh,   3, 1Fh, 3Eh, 23h, 3Fh, 1Ch,	  8
		.db  1Eh, 10h, 10h, 30h, 60h,0C4h, 84h,	98h,0B0h,0C0h,0F8h, 7Ch,0C4h,0FCh, 38h,	10h
		.db  78h,   8,	 8, 0Ch,   6, 0Bh, 11h,	19h, 0Dh,   3, 1Fh, 3Eh, 23h, 23h, 1Ch,	  8
		.db  3Ch, 20h, 20h, 60h, 40h,0D0h, 88h,	98h,0B0h,0C0h,0F8h, 7Ch,0C4h,0C4h, 38h,	10h
		.db  78h,   8,	 8, 0Ch,   6, 0Bh, 11h,	19h, 0Dh,   3, 1Fh, 3Eh, 23h, 23h, 1Ch,	  8
		.db  3Ch, 20h, 20h, 60h, 40h,0D0h, 88h,	98h,0B0h,0C0h,0F8h, 7Ch,0C4h,0C4h, 38h,	10h
		.db  18h, 28h, 48h, 0Ch,   6, 0Bh, 11h,	19h, 0Dh,   3, 1Fh, 3Eh, 23h, 23h, 1Ch,	  8
		.db  3Ch, 20h, 20h, 60h, 40h,0D0h, 88h,	98h,0B0h,0C0h,0F8h, 7Ch,0C4h,0C4h, 38h,	10h
		.db    3,   2,	 6,   6,   2, 0Ah, 0Bh,	0Bh, 0Fh,   7,	 3, 1Fh, 3Fh, 3Fh, 1Fh,	  6
		.db  80h,   0, 80h, 40h,0C0h, 80h,   0,	40h, 40h, 80h,0F0h,0FCh, 18h, 10h,0E0h,	  0
		.db    4,   8, 1Ch,   4,   6, 0Ah, 13h,	1Bh, 0Fh, 0Fh,	 3, 1Fh, 3Fh, 3Fh, 1Fh,	  6
		.db  38h, 20h, 20h, 60h, 60h,0C8h, 10h,	30h, 60h,   0,0F0h,0FCh, 18h, 10h,0E0h,	  0
		.db  10h, 20h, 70h, 0Ch,   6,	2, 33h,	23h, 27h, 3Fh,	 3, 1Fh, 3Fh, 3Fh, 1Fh,	  6
		.db  1Ch, 12h, 10h, 30h, 60h,0C0h,   0,	3Ch, 62h,   2,0F0h,0FCh, 18h, 10h,0E0h,	  0
		.db    1,   0,	 1,   2,   3,	1,   0,	  2,   2,   1, 0Fh, 3Fh, 18h,	8,   7,	  0
		.db 0C0h, 40h, 60h, 60h, 40h, 50h,0D0h,0D0h,0F0h,0E0h,0C0h,0F8h,0FCh,0FCh,0F8h,	60h
		.db  1Ch,   4,	 4,   6,   6, 13h,   8,	0Ch,   6,   0, 0Fh, 3Fh, 18h,	8,   7,	  0
		.db  20h, 10h, 38h, 20h, 60h, 50h,0C8h,0D8h,0F0h,0F0h,0C0h,0F8h,0FCh,0FCh,0F8h,	60h
		.db  38h, 48h,	 8, 0Ch,   6,	3,   0,	3Ch, 46h, 40h, 0Fh, 3Fh, 18h,	8,   7,	  0
		.db    8,   4, 0Eh, 30h, 60h, 40h,0CCh,0C4h,0E4h,0FCh,0C0h,0F8h,0FCh,0FCh,0F8h,	60h
		.db    4,   2,	 4,   4,   6, 23h, 21h,	19h, 0Dh,   3, 1Fh, 3Eh, 23h, 23h, 1Ch,	  8
		.db  1Eh, 10h, 10h, 30h, 60h,0C0h, 80h,	80h,0BCh,0C2h,0F9h, 7Ch,0C4h,0C4h, 38h,	10h
		.db  78h,   8,	 8, 0Ch,   6, 23h, 21h,	19h, 0Dh,   3, 1Fh, 3Eh, 23h, 23h, 1Ch,	  8
		.db  1Eh, 10h, 10h, 30h, 60h,0C4h, 84h,	98h,0B0h,0C0h,0F8h, 7Ch,0C4h,0C4h, 38h,	10h
		.db  78h,   8,	 8, 0Ch,   6,	3,   1,	  1, 3Dh, 43h, 9Fh, 3Eh, 23h, 23h, 1Ch,	  8
		.db  20h, 40h, 20h, 20h, 60h,0C4h, 84h,	98h,0B0h,0C0h,0F8h, 7Ch,0C4h,0C4h, 38h,	10h
		.db    4,   2,	 4,   4,   6, 23h, 21h,	19h, 0Dh,   3, 1Fh, 3Eh, 23h, 23h, 1Ch,	  8
		.db  1Eh, 10h, 10h, 30h, 60h,0C0h, 80h,	80h,0BCh,0C2h,0F9h, 7Ch,0C4h,0C4h, 38h,	10h
		.db  78h,   8,	 8, 0Ch,   6, 23h, 21h,	19h, 0Dh,   3, 1Fh, 3Eh, 23h, 23h, 1Ch,	  8
		.db  1Eh, 10h, 10h, 30h, 60h,0C4h, 84h,	98h,0B0h,0C0h,0F8h, 7Ch,0C4h,0C4h, 38h,	10h
		.db  78h,   8,	 8, 0Ch,   6,	3,   1,	  1, 3Dh, 43h, 9Fh, 3Eh, 23h, 23h, 1Ch,	  8
		.db  20h, 40h, 20h, 20h, 60h,0C4h, 84h,	98h,0B0h,0C0h,0F8h, 7Ch,0C4h,0C4h, 38h,	10h
		.db    4,0E4h,	 9,0C7h, 1Eh,	9, 12h,	  8, 20h, 88h,	 9,   2,   8,0E3h, 84h,	  9
		.db    2,   9, 24h, 82h,   9, 12h, 19h,	24h, 92h,   4,0E4h,   8,0C3h, 0Ch,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0
GIRGRF:		.db 0D1h,   0, 84h, 1Eh, 19h, 18h, 1Bh,	40h,0CBh, 0Bh, 84h, 82h, 81h, 80h, 87h,0EDh
		.db    0, 86h,0BBh, 44h,0BBh,0BBh, 44h,	44h,0F8h, 3Fh, 81h, 1Ah,0CBh, 3Bh, 81h,	29h
		.db 0E2h, 3Fh,0CDh, 3Eh,0CDh,	1, 40h,	48h,   0, 84h, 77h, 77h, 88h, 77h,0EDh,	  0
		.db  86h,0BBh, 44h,0BBh,0BBh, 44h, 44h,0DEh,0FFh, 85h, 11h, 11h, 2Dh,	5, 11h,0C4h
		.db 0FFh, 85h, 92h, 28h,0F0h, 28h, 92h,0C4h,0FFh, 81h, 89h,0C3h, 9Bh, 81h,0C7h,0C3h
		.db 0FFh, 81h, 22h,0CBh,0FFh, 81h, 11h,0C4h,0FFh, 85h, 0Fh, 7Bh, 0Bh,0BBh,0BBh,0D9h
		.db 0FFh, 85h, 44h,0BBh,0BBh,0B4h,0ABh,0C4h,0E8h, 88h,0CDh,0D2h,0DDh,0DDh, 22h,	22h
		.db  2Dh, 32h,0C4h, 17h, 85h,	1, 1Eh,	11h, 11h,0EEh,0D2h,   0, 87h, 4Eh, 4Eh,0EEh
		.db 0BEh, 96h, 86h, 8Eh,0EFh,	0, 84h,0BBh,0BBh, 44h,0BBh,0EDh,   0, 86h,0DDh,	22h
		.db 0DDh,0DDh, 22h, 22h,0D1h,0FFh, 83h,0E8h,0E8h, 90h,0C4h, 99h,0C6h,0FFh, 81h,	0Fh
		.db 0C3h, 33h, 81h,0C3h,0C4h,0FFh, 85h,	1Bh,0BBh,0EBh,0C3h,0D3h,0C4h,0FFh, 81h,	96h
		.db 0C3h, 33h, 81h, 0Fh,0C3h,0FFh, 81h,	44h,0CBh,0FFh, 81h, 22h,0C4h,0FFh, 85h,0E2h
		.db 0E2h, 92h, 22h, 22h,0D9h,0FFh, 85h,	97h, 67h, 7Fh,0F3h, 35h,0C4h, 5Dh, 88h,0F9h
		.db  3Fh,0B3h,0ABh, 54h, 4Ch,0C0h,   6,0C4h,0A2h, 85h, 60h,0A6h, 2Ah, 32h,0C2h,0D2h
		.db    0, 84h, 6Dh,0D7h, 17h, 6Fh,0C3h,0C6h,0C8h,   0, 82h,0E8h,0B0h,0C5h,   0,	83h
		.db  46h, 45h, 45h,0C8h,   0, 85h, 21h,	27h, 21h, 25h, 21h,0D0h,   0, 84h,0EEh,0EEh
		.db  11h,0EEh,0EDh,   0, 86h, 77h, 88h,	77h, 77h, 88h, 88h,0D1h,0FFh, 87h,0C7h,	7Dh
		.db  5Dh, 6Dh, 75h, 7Dh,0C7h,0C6h,0FFh,	85h, 11h, 11h, 21h, 11h, 11h,0C4h,0FFh,	85h
		.db  92h, 2Eh, 12h, 22h, 96h,0C4h,0FFh,0C4h, 33h, 81h, 8Bh,0C3h,0FFh, 81h, 44h,0CBh
		.db 0FFh, 81h, 22h,0C4h,0FFh, 85h, 92h,	2Eh, 12h, 22h, 96h,0D9h,0FFh, 81h, 68h,0C4h
		.db 0EFh,0C5h,0EEh,0C3h,0EFh,0C3h, 10h,0C5h, 11h,0C4h, 10h, 81h, 5Bh,0D2h,   0,0C3h
		.db    6, 81h, 5Ch,0C3h,0C6h,0CAh,   0,	89h, 10h, 12h, 12h, 16h, 16h, 1Fh, 0Fh,0EDh
		.db 0E9h,0C7h,	 0, 85h, 30h,0E4h,0D4h,0F4h, 30h,0D0h,	 0, 84h,0BBh,0BBh, 44h,0BBh
		.db 0EDh,   0, 86h,0DDh, 22h,0DDh,0DDh,	22h, 22h,0D1h,0FFh, 87h, 92h, 28h,   8,	38h
		.db  20h, 28h, 92h,0C6h,0FFh, 85h, 0Fh,0BBh,0B7h,0BBh, 0Fh,0C4h,0FFh, 85h, 77h,	77h
		.db  4Bh, 63h, 77h,0C4h,0FFh, 81h,0A5h,0C3h, 33h, 81h, 96h,0C3h,0FFh, 81h, 88h,0CBh
		.db 0FFh, 81h, 44h,0C4h,0FFh, 87h,0A5h,	11h, 11h, 25h, 1Dh,0A5h,0D9h,0D7h,0FFh,	81h
		.db  11h,0C3h,0FFh, 81h, 88h,0C4h,0FFh,	88h, 3Bh, 43h,0BFh,0BFh, 40h, 40h,0BCh,0C4h
		.db 0C3h,   0, 82h,0A2h,0DDh,0C3h,   0,	81h,0EEh,0D2h,	 0, 81h, 76h,0C6h,0D6h,0C9h
		.db    0, 81h, 84h,0C3h, 80h,0E2h,   0,	84h,0DDh,0DDh, 22h,0DDh,0EDh,	0, 86h,0EEh
		.db  11h,0EEh,0EEh, 11h, 11h,0D1h,0FFh,	81h, 4Bh,0C3h,0E7h, 83h,0C3h, 83h,0A3h,0C6h
		.db 0FFh, 85h,0A5h,0D1h,0A1h, 11h, 11h,0C4h,0FFh,0C4h,0CFh, 81h, 12h,0C4h,0FFh,	85h
		.db 0B1h, 11h, 41h, 69h, 79h,0C3h,0FFh,	81h, 44h,0CBh,0FFh, 81h, 22h,0C4h,0FFh,	85h
		.db  22h, 22h, 12h, 22h, 22h,0D9h,0FFh,	81h,0B6h,0C3h,0DEh, 81h, 7Ah,0C8h,0FEh,0C8h
		.db    1, 81h,0E3h,0C3h, 21h, 81h,0D0h,0D2h,   0, 87h, 4Eh, 6Eh, 7Eh, 56h, 46h,	4Eh
		.db  4Eh,0EFh,	 0, 84h,0BBh,0BBh, 44h,0BBh,0EDh,   0, 86h,0DDh, 22h,0DDh,0DDh,	22h
		.db  22h,0D1h,0FFh, 87h, 10h, 2Eh, 96h,0E0h, 28h, 28h, 92h,0C6h,0FFh, 85h,0B1h,	11h
		.db  41h, 69h, 79h,0C4h,0FFh, 85h, 7Bh,	43h, 77h, 77h, 43h,0C4h,0FFh, 85h, 11h,	11h
		.db  21h, 11h, 11h,0C3h,0FFh, 81h, 11h,0CBh,0FFh, 81h, 88h,0C4h,0FFh, 81h,0C3h,0C3h
		.db  33h, 81h,0A5h,0D9h,0FFh, 81h, 1Eh,0C5h,0EFh, 8Eh, 66h, 65h, 63h, 6Fh, 77h,	76h
		.db  75h, 8Ah, 89h, 88h, 90h, 9Ch, 9Ah,	99h,0C5h, 10h, 81h,0B4h,0C7h,	0, 81h,0DCh
		.db 0C5h, 66h, 81h, 2Fh,0C4h,	0, 87h,	74h, 48h, 48h, 70h, 48h, 48h, 74h,0EFh,	  0
		.db  84h,0BBh,0BBh, 44h,0BBh,0EDh,   0,	86h,0DDh, 22h,0DDh,0DDh, 22h, 22h,0D1h,0FFh
		.db  87h, 92h, 28h,   8, 38h, 20h, 28h,	92h,0C6h,0FFh, 85h, 8Fh,0BBh, 8Fh,0B7h,0B7h
		.db 0C4h,0FFh, 81h,0C3h,0C3h, 33h, 81h,0A5h,0C4h,0FFh, 85h, 22h,   2, 32h, 22h,	22h
		.db 0C3h,0FFh, 81h, 88h,0CBh,0FFh, 81h,	44h,0C4h,0FFh, 85h,0A1h, 1Dh, 21h, 11h,0A5h
		.db 0D9h,0FFh, 81h, 16h,0C5h, 77h, 8Eh,	7Fh, 67h, 57h, 37h,0F7h, 77h, 77h, 88h,	88h
		.db    8,0C8h,0A8h, 98h, 80h,0C5h, 88h,	81h,0BCh,0C7h,	 0, 87h,0E4h,0E4h, 44h,	14h
		.db  3Ch, 2Ch, 24h,0FAh,   0, 84h,0EEh,0EEh, 11h,0EEh,0EDh,   0, 86h, 77h, 88h,	77h
		.db  77h, 88h, 88h,0CFh,0FFh, 84h,0ABh,0B3h,0A3h,0A3h,0CBh,0FFh,0C4h,0CFh, 81h,	21h
		.db 0C4h,0FFh, 85h, 22h, 22h, 12h, 22h,	22h,0C4h,0FFh,0C4h,0CFh, 81h, 8Bh,0C3h,0FFh
		.db  81h, 44h,0CBh,0FFh, 81h, 22h,0EFh,0FFh,0C8h,   0, 81h, 0Eh,0C3h, 10h, 81h,	97h
		.db 0C7h,   0, 87h, 82h, 22h, 72h, 3Ah,	82h, 82h,0BAh,0C4h,   0,0C6h,0C6h, 81h,0DCh
		.db 0EFh,   0, 84h,0EEh,0EEh, 11h,0EEh,0EDh,   0, 86h, 77h, 88h, 77h, 77h, 88h,	88h
		.db 0DEh,0FFh, 85h,0C5h, 77h,0C7h,0B7h,0C3h,0C4h,0FFh, 85h, 11h, 11h, 21h, 11h,	11h
		.db 0C4h,0FFh, 85h, 92h, 2Eh, 12h, 22h,	96h,0C3h,0FFh, 81h, 88h,0CBh,0FFh, 81h,	44h
		.db 0C4h,0FFh,0C4h, 33h, 81h, 21h,0D9h,0FFh, 81h, 12h,0CCh, 7Bh,0C8h, 84h, 81h,	0Fh
		.db 0C3h,   0, 81h,0BBh,0D2h,	0,0C3h,0C0h, 84h,0DEh,0E4h,0E4h,0DEh,0DAh,   0,	84h
		.db    5, 23h, 2Fh, 0Dh,0D1h,	0, 84h,	77h, 77h, 88h, 77h,0EDh,   0, 86h,0BBh,	44h
		.db 0BBh,0BBh, 44h, 44h,0D1h,0FFh, 87h,	21h, 1Bh, 1Bh, 21h, 11h, 11h, 25h,0C6h,0FFh
		.db  81h, 10h,0C4h, 33h,0C4h,0FFh, 85h,	85h,0ADh, 85h,0B5h,0B5h,0C4h,0FFh, 85h,	7Dh
		.db 0DDh, 8Dh,0A5h,0B5h,0C3h,0FFh, 81h,	22h,0CBh,0FFh, 81h, 11h,0C4h,0FFh, 81h,	0Fh
		.db 0C3h, 33h, 81h,0C3h,0DDh,0FFh,0C9h,0FEh,0C8h,   1, 81h,0C3h,0C3h, 20h, 81h,0F1h
		.db 0C7h,   0,0C6h,0C6h, 81h, 76h,0C4h,	  0, 81h, 38h,0C5h,0C6h, 81h, 5Eh,0DAh,	  0
		.db  84h, 39h, 5Dh, 6Dh, 29h,0D1h,   0,	84h, 77h, 77h, 88h, 77h,0EDh,	0, 86h,0BBh
		.db  44h,0BBh,0BBh, 44h, 44h,0D1h,0FFh,	81h,0A1h,0C5h, 39h, 81h, 92h,0C6h,0FFh,	85h
		.db 0BBh, 9Bh,0ABh,0BBh,0BBh,0C4h,0FFh,	85h,0C7h, 7Bh, 47h, 77h,0C3h,0C4h,0FFh,	85h
		.db  25h, 11h, 25h, 1Dh, 1Dh,0C3h,0FFh,	81h, 11h,0CBh,0FFh, 81h, 88h,0C4h,0FFh,	85h
		.db 0C3h, 77h, 7Bh, 77h,0C3h,0D9h,0FFh,	86h,0C2h,0FDh, 9Dh, 5Dh,0DAh,0D5h,0C7h,0E8h
		.db 0C8h, 17h, 85h, 19h, 96h, 51h, 31h,	0Eh,0C7h,   0, 87h, 4Eh, 4Eh, 44h, 70h,	50h
		.db  44h, 4Eh,0C4h,   0,0C6h,0C0h, 81h,0B8h,0EFh,   0, 84h,0DDh,0DDh, 22h,0DDh,0EDh
		.db    0, 86h,0EEh, 11h,0EEh,0EEh, 11h,	11h,0D1h,0FFh, 87h,0B1h,0B1h, 11h, 41h,	69h
		.db  79h, 71h,0C6h,0FFh, 85h, 77h, 57h,	67h, 77h, 77h,0CDh,0FFh, 85h, 11h, 11h,	21h
		.db  11h, 11h,0C3h,0FFh, 81h, 11h,0CBh,0FFh, 81h, 88h,0C4h,0FFh, 81h,0C3h,0C3h,	33h
		.db  81h,0A5h,0D9h,0FFh, 86h, 0Eh,0FEh,0E6h,0EAh, 6Ch,0ACh,0C7h, 5Dh,0C8h,0A2h,	85h
		.db 0CAh, 0Ch, 80h, 98h, 68h,0D2h,   0,0C3h,0C0h, 84h,0B8h, 82h, 82h,0B8h,0EFh,	  0
		.db  84h,0DDh,0DDh, 22h,0DDh,0EDh,   0,	86h,0EEh, 11h,0EEh,0EEh, 11h, 11h,0D1h,0FFh
		.db 0C6h, 3Fh, 81h, 8Bh,0C6h,0FFh, 82h,	7Bh, 7Bh,0C7h,0FFh, 85h,0A5h,0D1h,0A1h,	11h
		.db  11h,0C4h,0FFh, 85h, 1Ch, 34h, 1Ch,	2Ch, 2Ch,0C3h,0FFh, 81h, 88h,0CBh,0FFh,	81h
		.db  44h,0C4h,0FFh, 87h,0A5h, 11h, 11h,	25h, 1Dh,0A5h,0D9h,0D7h,0FFh, 81h,0F1h,0CBh
		.db 0EEh, 81h, 67h,0C3h, 10h,0C6h, 11h,0C3h, 10h, 81h, 5Bh,0D2h,   0, 87h,0E4h,0E4h
		.db 0DCh, 44h, 14h, 3Ch, 2Ch,0EFh,   0,	84h,0EEh,0EEh, 11h,0EEh,0EDh,	0, 86h,	77h
		.db  88h, 77h, 77h, 88h, 88h,0D1h,0FFh,	81h,0C7h,0C5h, 39h, 81h,0A1h,0CFh,0FFh,	85h
		.db  96h, 22h, 2Eh, 22h, 96h,0C4h,0FFh,	85h, 0Bh,0B7h, 8Bh,0BBh, 0Fh,0C3h,0FFh,	81h
		.db  44h,0CBh,0FFh, 81h, 22h,0C4h,0FFh,	85h, 22h,   2, 32h, 22h, 22h,0E4h,0FFh,	86h
		.db  89h, 76h, 89h, 88h, 70h, 8Ch,0C4h,	7Ah, 85h, 40h,0BCh, 44h, 45h,0BAh,0D2h,	  0
		.db 0C3h,0C6h, 84h,0F4h,0DCh,0CCh,0E4h,0EFh,   0, 84h,0EEh,0EEh, 11h,0EEh,0EDh,	  0
		.db  86h, 77h, 88h, 77h, 77h, 88h, 88h,0D1h,0FFh,0C6h, 3Fh, 81h, 47h,0CFh,0FFh,0C4h
		.db 0CFh, 81h, 21h,0CCh,0FFh, 81h, 11h,0CBh,0FFh, 81h, 88h,0C4h,0FFh, 85h,0C7h,	7Bh
		.db  47h, 77h,0C3h,0C6h,0FFh,0C5h,0FEh,0DAh,0FFh, 84h, 5Dh, 22h,0A2h, 62h,0C6h,	20h
		.db  82h, 51h, 91h,0D4h,   0,0C3h,0C6h,	84h, 5Eh, 76h, 66h, 4Eh,0C9h,	0, 81h,	47h
		.db 0C3h,   1,0E2h,   0, 84h,0DDh,0DDh,	22h,0DDh,0EDh,	 0, 86h,0EEh, 11h,0EEh,0EEh
		.db  11h, 11h,0D1h,0FFh,0C3h, 3Fh, 84h,	8Bh,0B1h,0B1h, 8Bh,0CFh,0FFh, 85h, 7Bh,	43h
		.db  77h, 77h, 43h,0CAh,0FFh, 8Ah,0D5h,0D9h, 11h, 91h, 9Dh, 9Dh, 9Ch, 9Ch, 9Eh,	9Eh
		.db 0C3h,0B8h, 84h,0A1h, 21h,0E1h,0E1h,0C3h,0E0h,0C7h,0C0h, 81h,   8,0C8h,   0,	83h
		.db 0C4h,0C4h,0D4h,0C3h,0F0h,0C3h,0F8h,	83h,0DEh,0DEh,0DCh,0CCh,0FFh, 82h,0EFh,0EFh
		.db 0DFh,   0, 84h, 7Bh, 53h, 53h, 7Bh,0C3h,0C3h,0CAh,	 0, 89h,0C4h, 84h, 84h,0A4h
		.db 0A4h, 34h, 3Ch, 7Bh, 5Bh,0C7h,   0,	85h, 3Fh, 14h, 18h, 1Ch, 3Fh,0D0h,   0,	84h
		.db 0EEh,0EEh, 11h,0EEh,0EDh,	0, 86h,	77h, 88h, 77h, 77h, 88h, 88h,0D1h,0FFh,	87h
		.db  7Dh, 7Dh, 45h,0DDh, 8Dh,0A5h,0B5h,0CFh,0FFh, 81h,0A5h,0C3h, 33h, 81h, 96h,0C8h
		.db 0FFh, 86h, 76h, 70h, 78h, 68h, 48h,	  8,0ECh,   0, 8Fh, 46h,0C4h, 85h, 94h,	80h
		.db  85h, 84h, 84h, 85h, 85h,0C3h, 40h,	49h, 4Dh, 5Ch,0C4h, 10h, 84h,	2,   2,	42h
		.db  62h,0C3h,0C0h, 81h, 51h,0E1h,   0,	82h, 8Eh, 94h,0C5h,   0, 83h,	4,0C4h,0C4h
		.db 0C8h,   0, 85h,0E2h, 82h,0E2h,0C2h,0E2h,0D0h,   0, 84h,0EEh,0EEh, 11h,0EEh,0EDh
		.db    0, 86h, 77h, 88h, 77h, 77h, 88h,	88h,0D1h,0FFh, 81h, 44h,0C5h, 99h, 81h,0A3h
		.db 0CFh,0FFh, 87h, 22h,   2, 32h, 22h,	22h,0EEh,0DEh,0C6h,0FFh, 81h, 8Bh,0F1h,	  0
		.db  85h,   4,0D4h, 44h,   4, 44h,0C4h,	40h, 85h, 12h, 22h, 5Ah,0DCh,0DDh, 40h,	55h
		.db    0, 84h,0EEh,0EEh, 11h,0EEh,0EDh,	  0, 86h, 77h, 88h, 77h, 77h, 88h, 88h,0CFh
		.db 0FFh, 84h,0B3h,0BFh,0B7h,0B7h,0D4h,0FFh, 85h,0A5h, 11h, 1Dh, 11h,0A5h,0CAh,0FFh
		.db  83h, 6Eh, 2Eh, 2Eh,0C4h, 1Fh,0C5h,	0Fh,0C8h,   7, 81h, 8Eh, 40h, 7Eh,   0,	84h
		.db 0BBh,0BBh, 44h,0BBh,0EDh,	0, 86h,0DDh, 22h,0DDh,0DDh, 22h, 22h,0E7h,0FFh,0C4h
		.db 0CFh, 81h, 12h,0D6h,0FFh, 87h, 76h,	74h, 70h, 78h, 68h, 48h,   8,0FAh,   0,	84h
		.db  47h, 43h, 43h, 47h,0EBh,	0, 86h,0DAh, 7Dh, 17h, 38h, 2Ch, 21h,0D1h,   0,	84h
		.db 0EEh,0EEh, 11h,0EEh,0EDh,	0, 86h,	77h, 88h, 77h, 77h, 88h, 88h,0D1h,0FFh,	85h
		.db 0C5h, 77h,0C7h,0B7h,0C3h,0D1h,0FFh,	85h, 21h, 1Bh, 25h, 11h, 25h,0D0h,0FFh,	85h
		.db 0EFh,0E9h,0E1h,0F1h,0D1h,0E5h,   0,	88h, 89h, 8Bh, 8Fh, 87h, 8Fh, 8Fh, 8Bh,	89h
		.db 0D5h,   0, 84h,0C4h, 84h,	4,0C4h,0DDh,   0, 84h, 21h, 25h, 25h, 2Dh,0CBh,	  0
		.db  8Ch, 91h,0EEh,0BDh, 41h, 90h, 61h,	0Bh, 1Dh, 14h, 17h, 13h, 10h,0CAh,   0,	84h
		.db  77h, 77h, 88h, 77h,0EDh,	0, 86h,0BBh, 44h,0BBh,0BBh, 44h, 44h,0D1h,0FFh,	86h
		.db 0BDh,0EDh,0C5h,0D1h,0DBh,0DEh,0D0h,0FFh, 85h, 90h, 22h, 92h,0E2h, 96h,0CEh,0FFh
		.db  82h, 78h,	 8,0DFh,   0, 8Ah, 45h,	45h, 47h, 47h, 43h, 4Bh, 4Bh, 5Bh, 7Bh,	3Bh
		.db 0CAh,0FFh, 84h, 5Dh, 1Dh, 3Eh, 2Ah,0F1h,   0, 83h,0F1h,0E1h,0F1h,0C7h,   0,	92h
		.db  89h, 8Fh, 87h, 94h,0BBh, 45h, 9Fh,0A3h,0C5h,0DBh,	 7,0BDh,0D7h,0BEh,0D7h,	33h
		.db 0F4h, 4Bh,0C6h,0BFh, 87h,0BBh, 44h,	44h,0BBh,0BBh, 44h,0BBh,0EDh,	0, 86h,0DDh
		.db  22h,0DDh,0DDh, 22h, 22h,0D1h,0FFh,	85h, 22h, 82h, 92h, 22h, 92h,0CFh,0FFh,	84h
		.db  57h, 67h, 47h, 47h,0D1h,0FFh, 84h,	4Bh, 43h, 47h, 47h,0CAh,   1,0C5h,   3,0C4h
		.db    7,0C3h, 0Fh, 8Eh, 3Ch, 3Eh, 1Bh,	11h, 44h,0EFh,0B9h,0B4h,0ECh,0C5h,0D1h,0DBh
		.db 0DEh,0DCh,0CAh,0FFh, 91h,0EFh,0E9h,0F1h, 91h, 11h, 11h, 10h, 36h, 0Fh, 1Dh,	10h
		.db  12h, 16h, 1Eh, 1Eh, 16h, 12h,0C4h,	  0, 83h, 89h, 8Bh, 89h,0DCh,	0, 86h,	  4
		.db 0E4h,   4,0A4h,   4,   4,0C5h,   0,	93h, 23h, 22h, 2Dh,0DDh,0DDh,0DCh, 0Fh,0D1h
		.db 0D9h,0D9h, 5Fh,0DFh,0DFh, 5Fh,0DFh,	99h,0C5h,0BDh, 5Dh,0C9h,0FFh, 86h, 11h,	11h
		.db 0EEh,0EEh, 11h,0EEh,0EDh,	0, 86h,	77h, 88h, 77h, 77h, 88h, 88h, 40h, 4Ch,0FFh
		.db 0A9h,0BAh,0B8h,0BDh,0B7h,0A2h, 89h,0DFh, 73h, 2Ah, 99h,0FEh, 31h, 9Fh,0E2h,	39h
		.db 0EFh, 1Ah, 69h,0DFh,0AAh,0ABh, 32h,	78h,0DCh, 8Dh,0A5h,0B4h,0B4h,0A4h,0A4h,	84h
		.db 0C5h, 46h, 40h, 4Dh, 57h, 63h, 8Bh,0DBh, 7Bh, 3Bh,0C9h,0FFh, 89h, 1Dh, 3Dh,	2Dh
		.db 0E5h,0C5h, 85h,0E5h, 25h, 25h,0C3h,	  3, 82h, 10h, 10h,0C8h,   0, 82h, 89h,	8Bh
		.db 0C5h, 0Fh,0C5h, 1Fh,0C4h, 3Fh,0C4h,	7Fh,0C3h,0FFh, 85h,0C3h, 2Bh, 9Bh,0FBh,	3Bh
		.db 0D7h,0FFh, 86h, 22h, 22h,0DDh,0DDh,	22h,0DDh,0EDh,	 0, 86h,0EEh, 11h,0EEh,0EEh
		.db  11h, 11h,0D1h,0FFh, 87h, 89h,0B7h,	0Fh, 79h,0B1h,0B1h, 0Bh,0ECh,0FFh,0A9h,0BAh
		.db 0B8h,0BDh,0B7h,0A2h, 89h,0DFh, 73h,	2Bh, 9Ah,0F9h, 3Eh,0A1h, 93h,0E9h, 1Fh,0F2h
		.db  29h, 9Fh,0F2h, 29h, 9Fh,0F2h, 29h,	8Fh, 8Bh, 0Bh, 82h,   0,   6,	6,0CEh,	4Eh
		.db  4Dh, 56h, 73h, 23h, 8Ah,0D8h, 67h,	3Bh,0E2h,0FFh,0C4h, 7Fh,0F4h,0FFh, 86h,	22h
		.db  22h,0DDh,0DDh, 22h,0DDh,0EDh,   0,	86h,0EEh, 11h,0EEh,0EEh, 11h, 11h,0D1h,0FFh
		.db  87h, 0Bh,0B1h,0B1h, 0Bh,0B1h,0B1h,	0Bh,0E7h,0FFh,0ABh,0B7h,0A5h, 8Eh,0DFh,	71h
		.db  2Ah, 9Bh,0FBh, 3Bh,0B3h,0AFh, 99h,0FEh, 93h,0AAh, 31h,0FFh, 19h,0AAh,0ABh,	37h
		.db  99h,0FFh, 33h,0ABh, 9Ah,0F8h, 3Ch,0B4h,0A4h, 84h, 44h, 41h, 4Eh, 51h, 6Eh,	10h
		.db 0EDh, 17h,0E3h, 0Bh, 5Bh, 3Bh, 40h,	5Dh,0FFh, 86h, 22h, 22h,0DDh,0DDh, 22h,0DDh
		.db 0EDh,   0, 86h,0EEh, 11h,0EEh,0EEh,	11h, 11h,0D1h,0FFh, 87h, 0Bh,0B1h, 71h,	0Bh
		.db  7Fh, 7Bh, 89h,0EAh,0FFh,0A1h, 3Bh,0FBh, 9Bh, 2Bh,0F3h, 9Fh,0A9h,0B2h,0BFh,0B9h
		.db  3Ah,0FBh, 9Bh,0EBh, 1Bh,0FBh, 39h,0BCh,0B4h,0A6h, 80h, 4Dh, 46h, 61h, 0Eh,0D1h
		.db  6Eh, 11h,0E7h, 0Bh,0DBh, 7Bh, 3Bh,	40h, 64h,0FFh, 86h, 22h, 22h,0DDh,0DDh,	22h
		.db 0DDh,0EDh,	 0, 86h,0EEh, 11h,0EEh,0EEh, 11h, 11h,0D1h,0FFh, 87h, 0Bh,0B1h,	71h
		.db  71h, 8Bh,0B7h, 89h,0F2h,0FFh, 92h,	3Bh,0FBh, 9Bh, 28h,0F1h, 9Dh,0ABh,0B3h,0BFh
		.db 0B9h, 3Ah, 39h,0FFh, 13h,0EBh, 1Bh,0FBh, 3Bh, 40h, 6Bh,0FFh, 86h, 22h, 22h,0DDh
		.db 0DDh, 22h,0DDh,0EDh,   0, 86h,0EEh,	11h,0EEh,0EEh, 11h, 11h, 40h, 4Eh,0FFh,0C6h
		.db  7Fh, 40h, 73h,0FFh, 86h, 88h, 88h,	77h, 77h, 88h, 77h,0EDh,   0, 86h,0BBh,	45h
		.db 0BDh,0B1h, 49h, 49h, 40h,0C7h,0CDh,	86h, 2Fh, 2Fh,0D7h,0DBh, 23h,0DDh,0EFh,	  0
		.db  82h, 10h, 13h, 40h,0CBh,	3, 82h,	8Ah, 89h,0F1h,	 0, 82h,0BBh,0BBh,0FBh,	  0
		.db 0CBh,   3,0E3h,   0,0CBh,	1, 82h,	1Fh, 23h,0CDh,	 2, 81h, 12h, 40h, 47h,	  0
		.db  82h, 77h, 77h,0F1h,   0, 82h,0BBh,0BBh,0E0h,   0, 85h,0EEh,0EEh,0D2h,0FAh,0EEh
		.db 0C4h,   0, 85h, 6Dh,0D7h, 0Fh,0D7h,	6Dh,0C4h,   0, 81h, 76h,0C3h, 64h, 81h,	38h
		.db 0C4h,   0, 84h,0DDh,0DDh,0A1h, 1Bh,0C3h, 3Fh, 84h, 28h, 92h,0EEh,0EEh,0C5h,	  0
		.db  85h,0F0h, 84h,0F4h, 44h, 44h,0D9h,	  0, 85h,0BBh, 44h, 44h, 4Bh, 54h,0C4h,	17h
		.db  88h, 32h, 2Dh, 22h, 22h,0DDh,0DDh,0D2h,0CDh,0C4h,0E8h, 86h,0FEh,0E1h,0EEh,0EEh
		.db  11h,0EEh,0D1h,   0, 87h, 4Eh, 4Eh,0EEh,0BEh, 96h, 86h, 8Eh,0EFh,	0, 82h,0BBh
		.db 0BBh,0F1h,	 0, 82h,0DDh,0DDh,0D3h,	  0, 83h, 17h, 17h, 6Fh,0C4h, 66h,0C6h,	  0
		.db  81h,0F0h,0C3h,0CCh, 81h, 3Ch,0C4h,	  0, 85h,0E4h, 44h, 14h, 3Ch, 2Ch,0C4h,	  0
		.db  81h, 69h,0C3h,0CCh, 81h,0F0h,0C4h,	  0, 8Bh,0BBh,0BBh, 45h, 7Bh, 7Bh, 43h,	7Bh
		.db  7Bh, 47h,0BBh,0BBh,0C5h,	0, 85h,	2Eh, 2Eh, 5Eh,0EEh,0EEh,0D9h,	0, 85h,0F1h
		.db    1, 19h, 95h, 53h,0C4h,0A2h, 88h,0CAh, 0Ch, 83h, 98h, 60h, 7Ch,0F2h, 35h,0C4h
		.db  5Dh, 86h,0F9h, 3Eh,0B0h,0ACh, 54h,0A4h,0D1h,   0, 84h, 5Eh,0E4h, 24h, 5Ch,0C3h
		.db 0C6h,0C8h,	 0, 82h, 71h, 29h,0D1h,	  0, 82h, 8Ah, 8Ch,0D2h,   0, 82h,0BBh,0BBh
		.db 0F1h,   0, 82h,0DDh,0DDh,0D3h,   0,	87h, 6Dh,0D7h,0F7h,0C7h,0DFh,0D7h, 6Dh,0C6h
		.db    0, 85h, 44h, 44h, 74h, 44h, 44h,0C4h,   0, 85h, 38h, 84h,0B8h, 88h, 3Ch,0C4h
		.db    0,0C4h,0CCh, 81h,0DEh,0C4h,   0,	8Bh,0EEh,0EEh, 28h, 28h, 22h, 16h, 36h,	22h
		.db  28h,0EEh,0EEh,0C5h,   0, 85h,0F4h,	48h, 74h, 44h,0F0h,0D9h,   0, 81h, 5Bh,0C4h
		.db  10h,0C5h, 11h, 83h, 32h,0F2h, 32h,0C3h, 2Fh,0C5h, 2Eh,0C4h, 2Fh, 82h, 31h,	2Eh
		.db 0D1h,   0,0C3h,   6, 81h,0F6h,0C3h,0C6h,0DBh,   0, 82h, 54h, 64h,0D2h,   0,	82h
		.db 0DDh,0DDh,0F1h,   0, 82h,0EEh,0EEh,0D3h,   0, 87h,0F4h, 4Eh, 6Eh, 5Eh, 46h,	4Eh
		.db 0F4h,0C6h,	 0, 85h, 3Ch, 88h, 84h,	88h, 3Ch,0C4h,	 0, 85h,0EEh,0EEh,0D2h,0FAh
		.db 0EEh,0C4h,	 0, 81h, 69h,0C3h,0CCh,	81h,0F0h,0C4h,	 0, 82h,0BBh,0BBh,0C3h,	3Fh
		.db  86h, 21h, 1Bh, 1Bh, 21h,0DDh,0DDh,0C5h,   0, 87h, 69h,0DDh,0DDh,0E9h,0D1h,	69h
		.db  15h,0D7h,	 0, 81h, 77h,0C3h,   0,	81h,0BBh,0C4h,	 0, 88h,0A2h,0DAh, 27h,	26h
		.db 0D8h,0D8h, 24h, 5Eh,0C3h, 80h, 82h,	6Eh, 11h,0C3h,0FFh, 82h, 88h, 77h,0D1h,	  0
		.db  81h,0BAh,0C6h,0D6h,0EFh,	0, 82h,0DDh,0DDh,0F1h,	 0, 82h,0EEh,0EEh,0D3h,	  0
		.db  81h,0B4h,0C3h, 18h, 83h, 3Ch, 7Ch,	5Ch,0C6h,   0, 85h, 5Ah, 2Eh, 5Eh,0EEh,0EEh
		.db 0C4h,   0,0C4h, 30h, 81h,0EDh,0C4h,	  0, 85h, 4Eh,0EEh,0BEh, 96h, 86h,0C4h,	  0
		.db  8Bh,0BBh,0BBh, 47h, 7Bh, 7Bh, 43h,	7Bh, 7Bh, 47h,0BBh,0BBh,0C5h,	0, 85h,0EEh
		.db 0EEh,0DEh,0EEh,0EEh,0C7h,	0, 87h,0D7h,0D7h,0EFh, 77h, 27h, 0Fh, 1Fh,0CBh,	  0
		.db  81h, 49h,0C3h, 21h, 81h, 85h,0C6h,	  1, 82h,0DFh, 23h,0C7h,   2, 82h,0F3h,	23h
		.db 0C3h,0D2h, 82h,0BAh, 6Bh,0D1h,   0,	87h, 82h,0A2h,0B2h, 9Ah, 8Ah, 82h, 82h,0EFh
		.db    0, 82h,0DDh,0DDh,0F1h,	0, 82h,0EEh,0EEh,0D3h,	 0, 87h, 76h, 48h,0F0h,	86h
		.db  4Eh, 4Eh,0F4h,0C6h,   0, 85h, 82h,	22h, 72h, 5Ah, 4Ah,0C4h,   0, 85h,0E2h,0DAh
		.db 0EEh,0EEh,0DAh,0C4h,   0, 85h,0DDh,0DDh,0EDh,0DDh,0DDh,0C4h,   0, 82h, 77h,	77h
		.db 0C6h,0E7h, 83h,0C5h,0BBh,0BBh,0C5h,	  0, 81h, 5Ah,0C3h,0CCh, 81h, 69h,0D9h,	  0
		.db  81h, 78h,0C5h, 10h, 8Eh, 55h, 56h,	50h, 5Ch, 44h, 45h, 46h,0B9h,0BAh,0BBh,0A3h
		.db 0AFh,0A9h,0AEh,0C5h,0E9h, 82h, 2Bh,0D2h,0C6h,   0, 81h,0EFh,0C5h, 66h, 81h,0B6h
		.db 0C4h,   0, 87h,0B8h, 84h, 84h,0BCh,	84h, 84h,0B8h,0EFh,   0, 82h,0DDh,0DDh,0F1h
		.db    0, 82h,0EEh,0EEh,0D3h,	0, 87h,0F4h, 4Eh, 6Eh, 5Eh, 46h, 4Eh,0F4h,0C6h,	  0
		.db  85h,0BCh, 88h,0BCh, 84h, 84h,0C4h,	  0, 81h, 5Ah,0C3h,0CCh, 81h, 69h,0C4h,	  0
		.db  85h, 44h, 64h, 54h, 44h, 44h,0C4h,	  0, 86h,0BBh,0BBh, 48h, 60h, 60h, 48h,0C3h
		.db  3Ch, 82h,0DDh,0DDh,0C5h,	0, 85h,	6Dh,0D1h,0EDh,0DDh, 69h,0C7h,	0,0C6h,	18h
		.db  81h,0F6h,0CBh,   0, 81h,0BCh,0C5h,	88h, 8Eh, 2Ah, 32h,   2, 62h,0A2h, 5Dh,	22h
		.db  22h,0A2h, 62h, 82h,0F2h,0CAh,0D6h,0C5h, 74h, 82h, 15h,0E9h,0C6h,	0, 87h,	4Eh
		.db  4Eh,0EEh,0BEh, 96h, 86h, 8Eh,0FAh,	  0, 82h,0BBh,0BBh,0F1h,   0, 82h,0DDh,0DDh
		.db 0D1h,   0, 84h,   1, 19h,	9,   9,0CBh,   0,0C4h, 30h, 81h, 74h,0C4h,   0,	85h
		.db  88h, 88h,0B8h, 88h, 88h,0C4h,   0,0C4h, 30h, 81h,0DEh,0C4h,   0,0CBh,0FFh,0D1h
		.db    0, 87h,0D7h,0D7h,0EFh, 77h, 27h,	0Fh, 1Fh,0D6h,	 0, 82h, 76h, 88h,0C7h,	  1
		.db  82h, 5Bh, 64h,0C3h, 2Fh, 82h,   2,	3Dh,0C6h,   0, 87h,0D7h, 77h, 27h, 6Fh,0D7h
		.db 0D7h,0EFh,0C4h,   0,0C6h,0C6h, 81h,	76h,0EFh,   0, 82h,0BBh,0BBh,0F1h,   0,	82h
		.db 0DDh,0DDh,0C6h,   0, 87h,0D7h,0D7h,	77h, 27h, 0Fh, 1Fh, 17h,0D3h,	0, 85h,0F6h
		.db  44h,0F4h, 84h,0F0h,0C4h,	0, 85h,	88h, 88h,0B8h, 88h, 88h,0C4h,	0, 85h,	5Eh
		.db 0E2h,0DEh,0EEh, 5Ah,0C4h,	0, 8Bh,0EEh,0EEh, 12h, 28h, 28h, 12h, 22h, 22h,	16h
		.db 0EEh,0EEh,0C5h,   0,0C4h,0CCh, 81h,	74h,0C7h,   0, 87h, 82h, 82h, 88h,0BCh,	9Ch
		.db  88h, 82h,0CBh,   0, 81h,0DEh,0CAh,	84h, 82h, 94h, 95h,0C7h, 7Ah, 82h,0F3h,0F0h
		.db 0C3h,0FFh, 82h, 44h,0BBh,0D1h,   0,0C3h,0C0h, 84h,0DEh,0E4h,0E4h,0DEh,0DAh,	  0
		.db  82h, 19h, 1Dh,0D3h,   0, 82h, 77h,	77h,0F1h,   0, 82h,0BBh,0BBh,0C6h,   0,	85h
		.db  5Eh,0E2h,0DEh,0EEh, 5Ah,0C8h,   0,	87h,0EDh,0D7h,0D7h,0EDh,0DDh,0DDh,0E9h,0C6h
		.db    0, 81h, 76h,0C4h,0CCh,0C4h,   0,	85h,0B6h, 9Eh,0B6h, 86h, 86h,0C4h,   0,	85h
		.db 0E4h, 44h, 14h, 3Ch, 2Ch,0C4h,   0,	8Bh,0EEh,0EEh, 10h, 2Eh, 2Eh, 16h, 2Eh,	2Eh
		.db  12h,0EEh,0EEh,0C5h,   0, 81h,0F0h,0C3h,0CCh, 81h, 3Ch,0C7h,   0, 87h,0F9h,0F9h
		.db  5Ch, 3Ah, 5Ch,0F9h,0F9h,0CFh,   0,0C7h,   1, 82h,0E8h, 10h,0C7h,	2, 87h,	6Ah
		.db  9Ah, 59h, 58h, 58h, 98h, 68h,0C6h,	  0,0C6h,0C6h, 81h,0BAh,0C4h,	0, 81h,	5Eh
		.db 0C5h,0C6h, 81h, 6Dh,0DAh,	0, 82h,	98h,0B8h,0D3h,	 0, 82h,0BBh,0BBh,0F1h,	  0
		.db  82h,0DDh,0DDh,0C6h,   0, 87h, 69h,0DDh,0DDh,0E9h,0D1h, 69h, 15h,0C6h,   0,	81h
		.db 0F4h,0C5h,0C6h, 81h, 38h,0C6h,   0,	85h,0EEh,0CEh,0FEh,0EEh,0EEh,0C4h,   0,	85h
		.db  6Dh,0D1h,0EDh,0DDh, 69h,0C4h,   0,	85h, 70h, 44h, 70h, 48h, 48h,0C4h,   0,	8Bh
		.db 0BBh,0BBh, 7Dh, 7Dh, 77h, 43h, 63h,	77h, 7Dh,0BBh,0BBh,0C5h,   0, 85h, 5Ah,0EEh
		.db 0E2h,0EEh, 5Ah,0C7h,   0, 87h, 6Fh,	71h, 71h, 6Dh, 71h, 71h, 6Fh,0CBh,   0,	86h
		.db  97h,0A8h,0C8h,   8, 8Fh, 80h,0C7h,	17h,0C8h,0E8h, 86h,0B3h, 3Ch,0FBh, 1Bh,	64h
		.db  5Bh,0C6h,	 0, 87h,0E4h,0E4h,0EEh,0DAh,0FAh,0EEh,0E4h,0C4h,   0,0C6h,0C0h,	81h
		.db 0EDh,0EFh,	 0, 82h, 77h, 77h,0F1h,	  0, 82h,0BBh,0BBh,0C6h,   0, 85h, 5Eh,0E2h
		.db 0DEh,0EEh, 5Ah,0C8h,   0, 87h,0D7h,0D7h, 77h, 27h, 0Fh, 1Fh, 17h,0C6h,   0,	85h
		.db  44h, 64h, 54h, 44h, 44h,0CDh,   0,	85h, 88h, 88h,0B8h, 88h, 88h,0C4h,   0,	82h
		.db 0DDh,0DDh,0C6h,0E7h, 83h, 90h,0EEh,0EEh,0C5h,   0, 81h,0F0h,0C3h,0CCh, 81h,	3Ch
		.db 0C7h,   0, 86h, 2Eh, 2Eh, 22h, 22h,	2Eh, 2Eh,0CCh,	 0, 86h,0F1h,	1, 19h,	15h
		.db  93h, 53h,0C7h,0A2h,0C8h, 5Dh, 86h,	35h,0F2h, 7Ch, 60h, 98h, 68h,0D1h,   0,0C3h
		.db 0C0h, 84h,0B8h, 82h, 82h,0B8h,0EFh,	  0, 82h,0DDh,0DDh,0F1h,   0, 82h,0EEh,0EEh
		.db 0C6h,   0, 81h, 76h,0C3h, 64h, 81h,	38h,0C8h,   0,0C6h,0C0h, 81h,0DEh,0C6h,	  0
		.db  82h,0D1h,0D1h,0C7h,   0, 85h,0F0h,	84h,0F4h, 44h, 44h,0C4h,   0, 85h,0B6h,	9Eh
		.db 0B6h, 86h, 86h,0C4h,   0, 83h,0DDh,0DDh,0A1h,0C5h, 39h, 83h, 92h,0EEh,0EEh,0C5h
		.db    0, 87h,0F0h, 44h, 44h, 70h, 48h,0F0h, 8Ch,0D7h,	 0, 81h, 5Bh,0CAh, 11h,	82h
		.db 0F3h, 32h,0C3h, 2Fh,0C6h, 2Eh,0C3h,	2Fh, 82h, 31h, 2Eh,0D1h,   0, 87h, 4Eh,	4Eh
		.db  76h,0EEh,0BEh, 96h, 86h,0EFh,   0,	82h,0BBh,0BBh,0F1h,   0, 82h,0DDh,0DDh,0C6h
		.db    0, 85h, 6Dh,0D1h,0EDh,0DDh, 69h,0C8h,   0, 81h,0F4h,0C5h,0C6h, 81h, 38h,0C6h
		.db    0,0C6h,0C6h, 88h,0DCh, 22h, 22h,	5Ah,0EEh,0E2h,0EEh, 5Ah,0C4h,	0, 85h,	6Dh
		.db 0D1h,0EDh,0DDh, 69h,0C4h,	0, 82h,	77h, 77h,0C3h, 3Fh, 86h, 47h, 7Dh, 7Dh,	47h
		.db 0BBh,0BBh,0C5h,   0, 85h,0EEh,0CEh,0FEh,0EEh,0EEh,0E4h,   0, 86h,0EFh, 10h,0EFh
		.db 0EEh, 16h,0EAh,0C4h, 85h, 86h, 73h,	8Fh, 77h, 76h, 89h, 76h,0D1h,	0,0C3h,0C6h
		.db  84h, 92h,0BAh,0AAh, 82h,0EFh,   0,	82h,0DDh,0DDh,0F1h,   0, 82h,0EEh,0EEh,0C6h
		.db    0, 85h, 74h, 4Eh, 70h, 44h, 70h,0C8h,   0,0C6h,0C0h, 81h,0B8h,0C6h,   0,	85h
		.db 0EEh,0CEh,0FEh,0EEh,0EEh,0C4h,   0,0C4h, 30h, 81h,0EDh,0CDh,   0, 8Bh, 77h,	77h
		.db 0B1h,0B1h, 89h, 11h, 41h, 69h, 79h,	77h, 77h,0C5h,	 0, 85h, 38h, 84h,0B8h,	88h
		.db  3Ch,0E4h,	 0, 85h,0DDh, 22h,0A2h,	62h, 82h,0C6h,0D0h, 83h,0B1h, 51h, 91h,0C3h
		.db    0,0C5h,	 1,0CBh,   0,0C3h,0C6h,	84h, 5Eh, 76h, 66h, 4Eh,0EFh,	0, 82h,0BBh
		.db 0BBh,0F1h,	 0, 82h,0DDh,0DDh,0C6h,	  0, 85h, 69h, 1Dh, 6Dh,0DDh,0DDh,0C8h,	  0
		.db 0C3h,0C0h, 84h, 74h, 4Eh, 4Eh, 74h,0C6h,   0, 81h,0BAh,0C4h,0D6h,0C4h,   0,	85h
		.db 0E2h,0DAh,0EEh,0EEh,0DAh,0CAh,   0,	84h, 19h, 15h, 1Dh, 9Dh,0C5h, 80h,0A3h,	  9
		.db    8,   9,	 9, 0Ah, 89h, 8Ah, 8Ch,	8Ah, 8Ch, 80h, 8Ch, 98h, 80h, 99h, 80h,	99h
		.db  80h, 99h, 80h, 89h, 98h,0A9h, 9Ah,	89h, 8Ah, 89h, 8Ah, 89h, 8Ah, 89h, 8Ah,	89h
		.db  88h, 89h,0D0h,   0, 85h,0BAh, 44h,	46h, 40h, 40h,0C3h,   8, 96h, 32h, 32h,	  2
		.db  42h, 62h, 62h, 74h,0ADh,0BDh,   9,	3Dh,   9, 3Dh, 0Dh,0B5h, 69h,	7, 30h,	2Bh
		.db  26h, 20h, 23h,0C3h,   0, 84h,0E2h,0CAh,0CAh,0E2h,0C3h,0C3h,0DBh,	0, 82h,	80h
		.db  8Ch,0D2h,	 0, 82h,0BBh,0BBh,0F1h,	  0, 82h,0DDh,0DDh,0D3h,   0, 87h,0D7h,0D7h
		.db 0EFh, 77h, 27h, 0Fh, 1Fh,0C6h,   0,	85h, 44h, 64h, 54h, 44h, 44h,0C4h,   0,	81h
		.db  3Ch,0C3h,0CCh, 81h, 5Ah,0CAh,   0,	  0, 4Ch, 13h, 14h, 13h, 14h, 1Bh, 54h,	5Bh
		.db  84h, 9Ah,	 4,0BAh,   6, 3Ah,   6,	3Ah, 46h, 3Eh, 46h,0BEh, 46h,0BEh, 46h,0BEh
		.db  46h,0BEh, 46h,0BEh, 46h,0BEh, 46h,0BEh, 46h,0BEh, 46h,0BEh, 46h,0BEh, 46h,0BEh
		.db  46h,0BAh, 46h,0BAh, 44h,0BBh, 46h,0B9h, 41h, 33h, 11h, 10h,   1, 15h, 10h,	11h
		.db  11h, 10h, 10h, 16h, 15h, 1Ch, 19h,	0Bh,   3,   3,	 5,   5, 35h, 35h, 79h,	59h
		.db 0D9h,0D9h,0C1h, 41h, 81h,0C3h,0C0h,	92h,   8, 48h, 68h, 70h, 76h, 77h, 73h,0D7h
		.db  27h,0DFh,0A5h, 1Fh,0C3h,0ADh, 9Ah,	81h, 8Ch, 8Bh,0CBh,   0, 82h, 42h, 58h,0D1h
		.db    0, 82h, 62h,   2,0D2h,	0, 82h,0EEh,0EEh,0F1h,	 0, 82h, 77h, 77h,0C6h,	  0
		.db  87h, 82h, 82h,0BAh, 22h, 72h, 5Ah,	4Ah,0C6h,   0, 81h,0DDh,0C5h, 66h, 81h,	6Fh
		.db 0C6h,   0,0C4h, 30h, 81h, 74h,0C4h,	  0, 87h, 88h,0A8h, 98h, 88h, 88h, 44h,	74h
		.db 0C7h,   0, 85h, 76h, 88h, 7Dh, 9Dh,	5Dh,0E8h,0FFh, 91h,0AEh,   4, 1Bh, 11h,	50h
		.db  83h, 14h, 5Ah,   4, 5Ah, 44h, 5Ah,	5Ch, 23h, 11h, 11h,0EEh,0D8h,	0, 83h,	48h
		.db  78h, 74h,0C4h,0FFh, 8Ch, 3Bh,0BBh,0F9h, 2Eh, 51h, 82h, 61h, 56h, 4Dh, 40h,	46h
		.db  45h,0EBh,	 0, 82h,0DDh,0DDh,0F1h,	  0, 82h,0EEh,0EEh,0C6h,   0, 82h,0B8h,0B8h
		.db 0C9h,   0, 84h, 4Ch, 40h, 48h, 48h,0CBh,   0, 85h, 5Eh,0E2h,0DEh,0EEh, 5Ah,0C4h
		.db    0, 85h, 69h,0DDh,0D1h,0DDh, 69h,0CBh,   0, 82h,	 8,   8,0C4h,0C0h,0C5h,0E0h
		.db 0C9h,0F0h,0C4h,0F8h, 88h,0BDh,0BEh,0BDh,0BCh,0B9h,0B8h,0B9h,0B9h,0C6h,0FCh,	8Ah
		.db 0DAh,0DAh,0CAh,0D3h,0F0h, 87h, 69h,0B5h, 9Dh, 5Dh,0C7h,0FFh,0B2h, 6Eh,0BEh,	44h
		.db  1Bh, 14h,0D3h, 30h, 33h,	0,   0,	  3, 18h, 19h, 18h, 19h, 18h, 19h, 18h,	  3
		.db    1,   3,	 1,   1, 35h, 31h, 35h,	31h, 35h, 59h, 55h, 59h, 55h,0D9h, 11h,0D1h
		.db 0F1h,0E9h,0AEh,0EEh,0EEh,0CAh,0FEh,0CEh,0AEh, 4Eh,0BAh, 44h, 1Bh,0F1h, 0Eh,0E9h
		.db    0, 82h, 77h, 77h,0F1h,	0, 82h,0BBh,0BBh,0C6h,	 0, 87h, 5Eh,0E4h, 24h,	1Eh
		.db  24h, 44h, 1Eh,0DCh,   0,0C4h, 30h,	81h,0EDh,0D9h,	 0, 9Fh, 89h, 8Ah, 8Dh,	83h
		.db  9Eh,0A4h,0D4h,0A0h, 59h, 3Ah,0E9h,	2Ah,0CDh, 42h, 9Dh,   2, 9Dh,0A3h,0DDh,	23h
		.db 0DDh,0A3h, 9Dh, 82h, 8Dh, 8Ah, 89h,0D0h, 3Ch,0C2h, 75h,0C5h,0FFh, 84h,0AFh,	91h
		.db 0ACh,0BCh,0CAh,0FFh,0B2h, 5Dh, 9Dh,	5Dh, 8Dh, 75h, 89h, 62h,0A2h, 22h, 28h,	37h
		.db    9, 76h, 8Ah, 7Ah, 9Eh, 5Dh, 9Dh,	7Dh, 1Dh, 7Dh, 1Dh, 4Dh, 7Dh, 95h, 5Dh,	9Dh
		.db  5Dh, 5Dh,0DDh,0DDh,0DCh,0DEh,0DDh,0DFh,0DAh,0D2h, 42h,0A2h, 22h,0A2h,0A2h,	62h
		.db  62h,   2,	 2, 32h, 32h, 2Ah, 2Ah,0C4h,   4,0C4h,	 2, 87h, 10h,0E8h, 4Eh,	24h
		.db  0Bh, 1Fh, 12h,0D1h,   0, 82h, 77h,	77h,0F1h,   0, 82h,0BBh,0BBh,0C6h,   0,	82h
		.db  12h, 12h,0CBh,   0, 85h, 6Fh,0DDh,	6Dh, 1Dh, 69h,0C8h,   0,0C4h,0CCh, 81h,	74h
		.db 0C4h,   0, 85h,0B8h, 82h,0BCh, 88h,0BCh,0D2h,   0, 96h, 23h, 20h, 27h, 28h,	16h
		.db  7Ah, 92h, 43h,0E0h,0A7h, 28h, 37h,	  9, 77h, 89h, 7Dh, 8Dh, 7Dh, 9Dh, 5Dh,	9Dh
		.db  5Dh,0C9h,0FFh, 92h, 6Eh,0EEh, 6Eh,0AEh,0EEh, 2Eh, 4Eh,0AEh,0AFh,0DDh,0C9h,0F1h
		.db 0F1h,0E1h,0E1h,0E9h,0EDh,0EFh,0CEh,0FFh, 8Ah,0B7h, 8Bh, 88h, 23h,0F6h, 77h,0F7h
		.db 0B7h, 37h,0F7h,0CDh,0FFh,0ABh,0A6h,0C9h, 6Fh, 13h, 6Bh, 53h,0CFh,	3, 0Fh,	61h
		.db  56h, 54h, 57h, 4Bh, 4Bh, 53h, 48h,	5Dh, 6Ch, 54h, 7Bh, 5Bh, 68h, 58h, 6Ah,	5Bh
		.db  6Bh, 54h, 64h, 45h, 50h,0C4h,0BBh,0E8h, 14h,0C5h, 34h, 5Eh, 48h, 41h, 42h,	46h
		.db  45h,0CAh,	 0, 82h,0DDh,0DDh,0F1h,	  0, 82h,0EEh,0EEh,0D3h,   0, 86h,0E8h,0B8h
		.db  90h, 84h, 8Eh, 8Bh,0C7h,	0, 81h,	3Ch,0C3h,0CCh, 81h, 5Ah,0C4h,	0, 85h,	6Fh
		.db 0DDh, 6Dh, 1Dh, 69h,0CFh,	0, 8Dh,	8Ah, 9Dh,0A3h,0CDh,   3, 87h, 9Fh,0A7h,0D7h
		.db  37h,0F7h, 77h,0F7h,0D1h,0FFh, 8Bh,0BAh,0BAh,0B8h,0B8h,0BCh,0BCh,0B4h,0A4h,0A4h
		.db  84h,0C4h,0CCh,   0, 9Eh,0A2h,0E2h,0C3h,0D1h,0D9h,0DFh,0DFh,0DCh,0DDh,0DCh,0DFh
		.db 0D8h,0D7h,0CAh,0D2h,0C2h, 63h, 80h,0A7h, 68h,0E7h,0A9h,0E7h,0A9h,0E7h,0A9h,0E5h
		.db  87h, 91h, 5Dh,0C5h,0FFh, 86h,0C2h,0B6h, 36h, 7Eh, 7Eh,0EEh,0C3h,0FEh,0C3h,0FCh
		.db 0A1h,0F4h, 14h, 6Ch, 70h, 74h, 96h,	47h, 97h, 77h, 77h,0B7h, 77h,0F7h,0F0h,0B8h
		.db  29h,0EFh, 47h, 14h,0BBh, 45h, 9Fh,0A3h,0C5h,0DBh,	 7,0BDh,0D7h,0BEh,0D7h,	33h
		.db 0F4h, 48h,0C7h, 80h, 84h, 44h, 44h,0BBh,0BBh,0F1h,	 0, 82h,0DDh,0DDh,0D3h,	  0
		.db  85h,0DDh, 7Dh, 6Dh,0DDh, 6Dh,0C8h,	  0, 8Bh, 8Bh, 8Eh, 8Bh, 88h, 8Bh, 88h,	88h
		.db 0A8h, 98h,0B8h,0B8h,0D2h,	0, 83h,0F4h, 2Ch,0BCh,0CAh,0FCh,0C5h,0F8h,0C4h,0F0h
		.db 0C3h,0E0h, 8Ch,0E2h,0E2h,0A3h,0A1h,	24h, 2Fh, 39h, 34h, 2Ch, 25h, 21h, 23h,0D2h
		.db    0, 92h, 90h,0B6h, 8Fh,0DDh,0F1h,0E9h, 61h, 71h, 31h,0A1h, 49h, 11h, 11h,	3Bh
		.db  44h,0BBh, 6Dh,0EFh,0CEh,0FFh, 85h,	37h, 7Fh, 73h, 68h,   8,0C9h,	0, 9Dh,	  4
		.db 0E4h,   4,0E4h,   4,   4,0C4h,0A4h,0D4h, 94h,0B4h,0A4h, 64h, 4Bh,0BBh,0BBh,0BAh
		.db  68h,0B4h,0BCh,0BCh, 38h,0B8h,0B8h,	38h,0B8h,0FCh,0A4h,0C4h,0CCh,	0, 82h,0DDh
		.db 0DDh,0F1h,	 0, 82h,0EEh,0EEh,0E0h,	  0, 85h, 7Fh,0EBh, 6Bh,0EBh, 4Bh,0EBh,	  0
		.db  98h, 45h, 47h, 42h, 49h, 5Fh, 73h,	2Ah, 99h,0FEh, 31h, 9Fh,0E2h, 39h,0EFh,	1Ah
		.db  69h,0DFh,0AAh,0ABh, 32h, 78h, 5Ch,	4Dh, 45h,0C5h,	 0, 88h, 23h, 20h, 26h,	2Ah
		.db  32h,   2,0E2h,0A2h,0CCh,	0, 90h,	91h,0F1h, 21h,	 1, 41h, 21h,0E1h,0E1h,0F9h
		.db 0F9h,0D9h,0CDh,0CDh,0DFh,0FFh,0EFh,0C4h,0FFh, 83h, 76h, 74h, 68h,0D6h,   0,	83h
		.db  24h, 84h,0C4h,0DAh,   0, 82h,0DDh,0DDh,0F1h,   0, 82h,0EEh,0EEh,0D3h,   0,	87h
		.db  76h, 48h,0F0h, 86h, 4Eh, 4Eh,0F4h,0C6h,   0, 85h,0B2h, 63h, 62h, 62h,0A3h,0E3h
		.db    0,0A5h, 23h, 21h, 24h, 2Fh, 39h,	15h, 4Dh,0FCh, 9Fh, 58h,0C7h,0F5h, 8Fh,	79h
		.db  94h, 4Fh,0F9h, 94h, 4Fh,0F9h, 94h,	4Fh,0E9h,0EDh, 6Dh,0E4h, 66h, 60h, 60h,0A8h
		.db  28h, 2Bh, 30h, 15h, 45h,0ECh,0BEh,	40h, 5Eh,   0, 82h,0EEh,0EEh,0F1h,   0,	82h
		.db  77h, 77h,0D3h,   0, 87h, 38h, 82h,	82h, 38h, 82h, 82h, 38h,0C6h,	0, 85h,	21h
		.db 0E4h, 45h, 44h,0E1h,0DEh,	0,0A7h,	1Bh, 0Ah, 24h, 7Fh,0CEh,0AEh, 6Eh,0E6h,0FAh
		.db 0CCh,0ABh,0C6h,0FFh, 64h,0AAh, 4Ch,0FFh,0FEh, 62h,0CCh,0AAh, 66h,0FEh,0CFh,0ADh
		.db  69h,0E1h,0F1h,0D1h, 11h, 14h, 1Bh,	  4, 3Bh, 45h,0B9h, 41h,0B1h, 51h, 40h,	61h
		.db    0, 82h, 77h, 77h,0F1h,	0, 82h,0BBh,0BBh,0D3h,	 0, 87h, 5Eh,0E4h, 24h,	5Eh
		.db  2Ah, 2Eh,0DCh,0C6h,   0, 85h,0F2h,	17h,0F7h, 77h,0D2h,0E0h,   0, 9Eh,   8,	48h
		.db 0E8h, 38h, 50h, 64h, 7Eh, 73h, 75h,0F6h, 37h, 57h, 27h,0D7h, 3Fh,0F5h, 70h,	78h
		.db  6Ah, 4Ch, 81h, 8Ah,0ADh,0C2h, 1Dh,0A2h,0DCh, 28h,0C8h,   8, 40h, 68h,   0,	82h
		.db 0BBh,0BBh,0F1h,   0, 82h,0DDh,0DDh,0D3h,   0, 87h, 6Dh,0D7h, 17h, 17h,0EDh,0D1h
		.db 0EFh,0C6h,	 0, 85h, 4Bh,0E8h, 8Bh,0EEh, 4Eh,0E8h,	 0, 90h,0C4h, 84h, 24h,0F5h
		.db  9Dh,0ABh,0B3h,0BFh,0B9h, 3Ah, 38h,0FCh, 14h,0E4h,	 4,0C4h, 40h, 6Eh,   0,	82h
		.db 0DDh,0DDh,0F1h,   0, 82h,0EEh,0EEh,0E0h,   0, 85h, 4Eh,0EEh, 68h,0EEh,0EEh,	40h
		.db 0A6h,   0, 82h,0BBh,0BBh,0F1h,   0,	82h,0DAh,0D6h, 40h,0CBh, 0Ch, 82h,0E5h,0E9h
		.db  41h, 9Bh,	 0,0DCh,   3, 40h, 9Ch,	  0, 85h, 44h, 44h, 78h, 50h, 44h,0C4h,	  0
		.db  85h, 38h, 82h, 5Ah, 82h, 38h,0C4h,	  0, 81h,0DCh,0C3h, 64h, 81h, 6Dh,0C6h,	  0
		.db  82h,0F4h, 4Eh,0C3h,0C0h, 82h, 82h,	38h,0C7h,   0, 85h, 5Ah, 2Eh, 5Eh,0EEh,0EEh
		.db 0D8h,   0,0DCh,0FFh,0E0h,	0, 83h,	16h, 16h, 14h,0C3h,   7,0C3h,	3,0C3h,	  1
		.db  40h, 63h,	 0, 83h, 8Eh, 8Eh,0F6h,0C4h, 66h,0C6h,	 0, 81h, 3Ch,0C3h,0CCh,	81h
		.db  5Ah,0C4h,	 0, 85h,0D7h, 77h, 27h,	0Fh, 1Fh,0C4h,	 0, 81h,0F0h,0C3h,0CCh,	81h
		.db  3Ch,0C6h,	 0, 87h,0DCh,0E2h,0E2h,0DAh,0E2h,0E2h,0DEh,0C7h,   0, 85h, 1Dh,	1Dh
		.db  6Dh,0DDh,0DDh,0D8h,   0, 85h, 68h,	78h, 70h, 74h, 76h,0C6h,0FFh, 86h,0BAh,0B8h
		.db 0BCh,0BCh,0B8h,0BAh,0C6h,0FFh, 85h,0DCh,0DEh,0DAh,0D2h,0C2h,0E1h,	0, 87h,	91h
		.db 0D1h,0F1h,0E1h,0E9h,0EDh,0EEh,0C3h,0EFh, 88h, 7Fh, 73h, 77h,0F7h,0B7h, 97h,	8Bh
		.db  8Fh,0C3h, 0Fh, 85h, 43h, 4Fh, 41h,	46h, 45h, 40h, 54h,   0, 87h, 5Eh,0E4h,0C4h
		.db 0F4h,0ECh,0E4h, 5Eh,0C6h,	0, 85h,0DDh,0DDh,0EDh,0DDh,0DDh,0C4h,	0, 85h,0F4h
		.db  48h, 74h, 44h,0F0h,0C4h,	0,0C4h,0CCh, 81h,0B8h,0C6h,   0, 87h,0E4h,0E4h,0EEh
		.db 0DAh,0FAh,0EEh,0E4h,0C7h,	0, 85h,	6Dh,0D1h,0EDh,0DDh, 69h,0D8h,	0,0DCh,	3Fh
		.db 0E1h,   0, 87h, 89h, 8Bh, 8Fh, 8Fh,	87h, 87h, 97h,0C3h,0FFh, 83h,0BAh,0B9h,0A7h
		.db 0CBh,0FFh, 84h, 3Ch,0E3h, 1Ah, 2Dh,	40h, 52h,   0, 87h, 6Dh,0D7h,0F7h,0C7h,0DFh
		.db 0D7h, 6Dh,0C6h,   0, 85h,0F0h, 44h,	48h, 44h,0F0h,0C4h,   0, 85h, 88h, 88h,0B4h
		.db  9Ch, 88h,0C4h,   0, 81h, 5Ah,0C3h,0CCh, 81h, 69h,0C6h,   0,0C3h,0C0h, 84h,	74h
		.db  4Eh, 4Eh, 74h,0C7h,   0, 87h, 3Ch,	88h, 88h,0BCh, 84h, 3Ch, 40h,0D6h,   0,0C7h
		.db 0FFh,0C3h, 80h, 81h,0DEh,0C6h,0FEh,	81h,0EDh,0C3h, 80h,0C7h,0FFh,0E0h,   0,	85h
		.db  68h, 78h, 78h, 70h, 70h,0C3h,0FCh,	8Dh,0BAh, 3Ah,0BAh,0BAh,0B8h,0B8h,0BCh,0BEh
		.db 0BFh,0B3h,0B3h,0ABh,0FBh,0C4h,0FFh,	85h,0C4h,0BBh, 23h,0DCh, 23h, 40h, 51h,	  0
		.db  81h, 2Dh,0C3h, 18h, 83h,0F0h,0B0h,	90h,0C6h,   0, 85h, 3Ch, 48h, 38h, 88h,	88h
		.db 0C4h,   0,0C4h, 30h, 81h,0DEh,0C4h,	  0, 85h,0D7h, 77h, 27h, 0Fh, 1Fh,0C6h,	  0
		.db  87h, 74h, 48h, 48h, 70h, 48h, 48h,	74h,0C7h,   0, 85h, 88h, 88h,0B8h, 88h,	88h
		.db 0D8h,   0, 81h,0C1h,0C5h,0F3h, 81h,0F2h,0CEh,   3, 81h, 6Bh,0C5h,0F3h, 81h,0A7h
		.db 0EEh,   0, 82h, 23h, 2Dh,0C5h,0FFh,	89h,0FCh,0EEh,0FFh,0C8h,0F5h, 91h, 12h,	2Dh
		.db 0F1h, 40h, 51h,   0, 87h, 76h, 48h,0F0h, 86h, 4Eh, 4Eh,0F4h,0C6h,	0, 85h,	82h
		.db  22h, 72h, 5Ah, 4Ah,0C4h,	0, 85h,0E2h,0DAh,0EEh,0EEh,0DAh,0C4h,	0, 85h,0DDh
		.db 0DDh,0EDh,0DDh,0DDh,0C6h,	0,0C6h,	18h, 81h,0F6h,0C7h,   0, 81h, 3Ch,0C3h,0CCh
		.db  81h, 5Ah,0D8h,   0, 81h,0E1h,0C6h,0F9h, 81h, 73h,0CCh,0FFh, 81h,0BFh,0C6h,0F9h
		.db  81h,0D2h,0E6h,   0, 96h, 16h, 1Eh,	0Ah,   8, 26h, 3Eh, 0Eh, 2Eh,0EEh, 6Eh,0EEh
		.db 0CEh,0EEh,0EEh,0CEh,0ADh,0E9h, 71h,	16h, 29h, 51h, 91h, 40h, 53h,	0, 87h,0F4h
		.db  4Eh, 6Eh, 5Eh, 46h, 4Eh,0F4h,0C6h,	  0, 85h,0BCh, 88h,0BCh, 84h, 84h,0C4h,	  0
		.db  81h, 5Ah,0C3h,0CCh, 81h, 69h,0C4h,	  0, 85h, 44h, 64h, 54h, 44h, 44h,0C6h,	  0
		.db  84h,0B7h, 9Fh, 9Fh,0B7h,0C3h,0C3h,0C7h,   0, 85h, 5Eh,0E2h,0DEh,0EEh, 5Ah,0D8h
		.db    0, 81h,0E9h,0C7h,0FCh, 8Ch, 70h,	78h, 68h, 48h,	 8, 88h, 88h,	8, 48h,	68h
		.db  78h, 70h,0C7h,0FCh, 81h,0BCh,0E4h,	  0, 85h, 2Dh, 5Dh,0DDh, 9Fh,0FDh,0C3h,0FFh
		.db  8Fh,0A6h,0EEh,0CEh,0EEh,0CAh,0CAh,0AEh,0AEh, 2Ah, 6Ah, 21h, 11h,0D5h, 29h,	16h
		.db  40h, 52h,	 0, 84h, 98h, 80h, 90h,	90h,0CBh,   0,0C4h, 30h, 81h,0B8h,0C4h,	  0
		.db  85h,0EEh,0EEh,0DEh,0EEh,0EEh,0C4h,	  0,0C4h, 30h, 81h,0EDh,0F2h,	0,0D4h,	  1
		.db  81h, 97h,0C5h, 3Fh, 81h, 5Bh,0E1h,	  0, 81h, 23h,0C7h,0FFh, 85h,0EFh,0EEh,0EEh
		.db 0EFh,0FFh,0C3h,0FCh, 8Dh, 70h, 71h,	39h, 79h, 29h,0EDh,0C9h,   1, 8Ah,0C0h,	  8
		.db  70h, 8Fh, 40h, 5Eh,   0, 85h, 3Ah,	88h, 38h, 48h, 3Ch,0C4h,   0, 85h,0EEh,0EEh
		.db 0DEh,0EEh,0EEh,0C4h,   0, 85h, 6Dh,0D1h,0EDh,0DDh, 69h,0C6h,   0, 87h, 74h,	4Eh
		.db  4Eh, 74h, 44h, 44h, 70h,0C7h,   0,0C4h,0CCh, 81h,0B8h,0D8h,   0, 81h,0DEh,0D4h
		.db 0FEh,0C7h,0FFh,0E0h,   0, 84h, 12h,0EAh,0E6h,0E4h,0C3h,0EFh, 8Bh, 56h, 57h,	56h
		.db  37h,0B7h,0B5h,0F7h,0F7h, 75h, 77h,	76h,0C4h,0FFh, 89h,0BAh, 3Bh, 7Bh,0F2h,0EDh
		.db    4, 44h, 84h, 7Bh, 40h, 50h,   0,	87h,0DEh,0E4h,0E4h,0DEh,0EEh,0EEh,0DAh,0C6h
		.db    0, 81h,0EFh,0C4h,0CCh,0C4h,   0,	85h, 7Ah, 52h, 7Ah, 4Ah, 4Ah,0C4h,   0,	85h
		.db  82h, 22h, 72h, 5Ah, 4Ah,0C6h,   0,	87h,0DCh,0E2h,0E2h,0DAh,0E2h,0E2h,0DEh,0C7h
		.db    0, 81h, 69h,0C3h,0CCh, 81h,0F0h,0DCh,   0, 81h, 45h,0D0h,   3, 83h,0C1h,0D1h
		.db 0D3h,0C3h,0F0h, 81h,0F1h,0E0h,   0,	84h, 48h, 57h, 67h, 27h,0C3h,0F7h,0C3h,0FBh
		.db 0C3h,0FDh, 82h,0BAh,0BAh,0C7h,0FFh,	89h, 5Dh,0DCh,0DEh,0CFh,0E3h,	8, 62h,	21h
		.db 0DEh, 40h, 50h,   0, 81h, 6Dh,0C5h,0C6h, 81h,0F4h,0C6h,   0, 85h, 88h,0A8h,	98h
		.db  88h, 88h,0C4h,   0, 85h, 5Eh,0E2h,0DEh,0EEh, 5Ah,0C4h,   0, 85h,0E9h,0DDh,0E9h
		.db 0D1h,0D1h,0C6h,   0, 87h, 4Eh, 4Eh,	44h, 70h, 50h, 44h, 4Eh,0C7h,	0, 85h,	3Ch
		.db  88h, 84h, 88h, 3Ch,0D8h,	0, 83h,	3Dh, 1Dh, 5Dh,0D6h,0FFh, 83h, 6Eh, 2Eh,	0Eh
		.db 0E1h,   0, 82h,   8, 70h,0C6h,0FFh,	85h, 3Bh,0BBh,0BBh, 3Bh, 33h,0C3h, 3Fh,	8Dh
		.db  3Dh,0BDh,0AFh,0ADh,0A7h, 84h,0A0h,0B3h, 62h, 30h, 22h, 3Dh,0C2h, 40h, 51h,	  0
		.db  87h,0D7h,0D7h, 77h, 27h, 0Fh, 1Fh,	17h,0C6h,   0, 85h, 44h, 64h, 54h, 44h,	44h
		.db 0CDh,   0, 85h, 88h, 88h,0B8h, 88h,	88h,0C6h,   0,0C6h, 18h, 81h, 5Ch,0C7h,	  0
		.db  81h, 69h,0C3h,0CCh, 81h,0F0h,0D8h,	  0, 85h,0A4h,0B4h,0BCh,0B8h,0BAh,0D2h,0FFh
		.db  85h,0DCh,0DEh,0DAh,0D2h,0C2h,0E4h,	  0, 85h,0E1h,0EFh,0EEh,0ACh,0EAh,0C3h,0FFh
		.db  90h, 65h, 77h, 73h, 77h, 53h, 53h,	75h, 75h, 54h, 56h, 84h, 88h,0ABh, 94h,	68h
		.db    8, 40h, 53h,   0,0C6h,0C0h, 81h,0B8h,0C6h,   0, 82h,0E2h,0E2h,0C7h,   0,	85h
		.db  69h, 1Dh, 6Dh,0DDh,0DDh,0C4h,   0,	85h, 7Ah, 52h, 7Ah, 4Ah, 4Ah,0C6h,   0,	81h
		.db  38h,0C5h,0C6h, 81h, 5Eh,0C7h,   0,	87h, 69h,0DDh,0DDh,0E9h,0D1h, 69h, 15h,0D6h
		.db    0,0DCh, 3Fh,0E6h,   0, 96h, 68h,	78h, 50h, 10h, 64h, 7Ch, 70h, 74h, 77h,	76h
		.db  77h, 73h, 77h, 77h, 73h,0B5h, 97h,	8Eh, 68h, 94h, 8Ah, 89h, 40h, 53h,   0,	81h
		.db  38h,0C5h,0C6h, 81h, 5Eh,0CFh,   0,	85h, 69h,0DDh,0D1h,0DDh, 69h,0C4h,   0,	85h
		.db 0F4h, 48h, 74h, 44h,0F0h,0C6h,   0,0C3h,0C0h, 84h,0B8h, 82h, 82h,0B8h,0C7h,	  0
		.db  85h,0EEh,0CEh,0FEh,0EEh,0EEh,0D9h,	  0,0CAh, 80h, 81h,0EFh,0CFh,0FFh, 81h,	76h
		.db 0EEh,   0, 82h,0C4h,0B4h,0C5h,0FFh,	89h, 95h,0DDh, 55h,0B9h,   5, 23h,0E2h,	1Eh
		.db  25h, 40h, 51h,   0,0C6h,0C0h, 81h,0EDh,0CFh,   0,0C4h, 30h, 81h, 74h,0CFh,	  0
		.db  87h, 82h, 82h,0BAh, 22h, 72h, 5Ah,	4Ah,0C7h,   0, 85h, 5Eh,0E2h,0DEh,0EEh,	5Ah
		.db 0E6h,   0, 83h, 91h,0D1h,0F1h,0C6h,0F0h, 83h, 68h, 48h,   8,0E2h,	0, 85h,	43h
		.db  4Bh, 4Bh, 5Bh, 5Bh,0C3h, 3Fh, 8Dh,	5Dh, 5Ch, 5Dh, 5Dh, 1Dh, 1Dh, 3Dh, 7Dh,0FDh
		.db 0CDh,0CDh,0D5h,0DFh,0C4h,0FFh, 85h,	76h, 88h, 91h, 6Eh, 91h, 40h, 51h,   0,0C3h
		.db 0C0h, 84h, 74h, 4Eh, 4Eh, 74h,0CFh,	  0, 85h, 84h,0BCh, 88h, 88h,0BCh,0CAh,	  0
		.db  84h, 2Ah, 26h, 2Eh, 2Eh, 40h, 69h,	  0, 87h, 91h,0D1h,0F1h,0F1h,0E1h,0E1h,0E9h
		.db 0C3h,0FFh, 83h,0F7h, 37h, 4Fh,0CBh,0FFh, 84h, 3Ch,0C7h, 58h,0B4h, 40h, 52h,	  0
		.db  87h,0E4h,0E4h,0DCh, 44h, 14h, 3Ch,	2Ch,0CFh,   0, 81h, 69h,0C3h,0CCh, 81h,0F0h
		.db  40h, 77h,	 0, 87h, 45h, 47h, 43h,	4Bh, 5Bh, 7Bh,0BBh,0C3h,0F7h, 88h,0CDh,0FDh
		.db 0DDh,0DCh,0DEh,0DAh,0E2h,0C2h,0C3h,0F0h, 85h,0F1h,0C1h,0B1h, 51h, 91h, 40h,	54h
		.db    0, 81h, 77h,0C5h, 66h, 81h, 3Ah,0CFh,   0, 87h,0EEh,0CEh,0FEh,0EEh,0EEh,	22h
		.db  12h, 40h, 74h,   0, 83h,0F1h,0F1h,0B1h,0C3h,0E0h,0C3h,0C0h,0C3h, 80h, 40h,	61h
		.db    0, 84h, 80h, 8Ch, 84h, 84h,0D4h,	  0, 85h, 3Ch, 88h, 84h, 88h, 3Ch, 40h,0FBh
		.db    0,0C4h, 30h, 81h,0DEh, 40h, 57h,	  0, 84h, 12h, 16h, 16h, 12h,0EBh,   0,	86h
		.db  70h,0D7h,0BDh, 92h, 86h, 8Bh, 40h,	59h,   0, 85h, 3Ah, 88h, 38h, 48h, 3Ch,0D1h
		.db    0, 85h,0DEh,0E4h,0DAh,0EEh,0DAh,	40h, 57h,   0, 84h, 91h,0D1h,0D1h, 91h,0DDh
		.db    0, 84h, 8Bh, 8Eh, 8Fh, 87h,0C8h,	  0, 8Fh, 46h, 44h, 44h,0C4h,0BBh,0E8h,	14h
		.db 0C5h, 34h, 5Eh, 48h, 41h, 42h, 46h,	45h, 40h, 52h,	 0, 86h, 42h, 12h, 3Ah,	2Eh
		.db  24h, 21h,0D0h,   0, 85h, 6Fh,0DDh,	6Dh, 1Dh, 69h, 40h, 78h,   0, 83h, 68h,0B8h
		.db  68h,0C6h,	 0, 93h, 45h, 45h, 43h,	4Bh, 58h, 77h, 89h, 53h, 6Fh,	9, 17h,0CBh
		.db  71h, 1Bh, 72h, 1Bh,0FFh, 38h, 84h,	40h, 51h,   0, 85h,0EEh, 4Eh, 5Eh,0EEh,	5Eh
		.db 0CFh,   0, 84h, 31h,   1, 21h, 21h,	40h, 58h,   0, 83h, 89h, 8Bh, 89h,0DDh,	  0
		.db  83h,   4, 44h,   4,0C9h,	0, 90h,	2Dh,0DDh,0DDh,0DCh, 0Eh,0D2h,0DAh,0DAh,	5Eh
		.db 0DEh,0DEh, 5Eh,0DEh, 9Ah,0C2h,0A2h,	40h,0C4h,   0, 84h,0D1h,0F1h,0F1h,0D1h,0E7h
		.db    0, 83h,0E8h, 48h,   8, 40h, 62h,	  0, 87h,0BAh, 84h, 3Ch, 4Ah, 82h, 82h,	38h
		.db  40h,0F9h,	 0, 87h, 5Eh,0E4h,0E4h,	5Eh,0E4h,0E4h, 5Eh, 40h,0F9h,	0, 87h,	6Dh
		.db 0D7h, 17h, 6Dh, 19h, 1Dh,0EFh,0F9h,	  0, 81h, 80h, 40h,0BFh,   0, 87h, 38h,	82h
		.db  42h, 42h,0B8h, 84h,0BAh, 42h,0D0h,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0
PARLEV:		.db  14h,   1, 0Ch,   0,   1,	1, 50h,	96h, 3Fh, 3Fh, 87h, 17h
		.db  14h,   1,	 0, 18h,   1, 26h, 28h,0FAh,0ADh, 3Fh, 87h, 17h
		.db    1, 14h, 0Bh,   8, 14h,	1, 28h,0FAh,0ADh, 38h,0DAh, 2Fh
		.db  14h,   1,	 0, 18h,   4, 11h, 14h,0A0h,0ADh,0FFh,0C7h, 3Fh
		.db  14h, 26h,	 0,   0, 14h, 26h, 19h,0C8h,0ADh,0D7h, 0Fh, 2Fh
		.db    1,   1, 0Ch, 18h,   5,	1, 0Ah,0A0h,0ADh, 3Fh, 87h, 17h
		.db    2,   2, 0Ch, 18h, 0Bh, 26h,   9,	1Eh,0ADh, 38h,0DAh, 2Fh
		.db  14h,   8, 0Ch, 18h, 14h,	1, 20h,0C8h,0ADh,0FFh,0C7h, 3Fh
		.db    1,   1,	 0, 18h,   1,	3, 32h,0F0h,0ADh,0D7h, 0Fh, 2Fh
		.db    1, 26h, 0Ch,   0,   1, 14h, 32h,0B4h,0ADh, 3Fh, 87h, 17h
		.db  14h,   1,	 0, 18h,   1,	1, 5Ah,	6Eh,0ADh, 38h,0DAh, 2Fh
		.db  14h,   1, 0Ch,   0,   1,	1, 50h,	96h, 3Fh, 3Fh, 87h, 17h
		.db  14h,   1, 0Ch,   0,   1,	1, 50h,	96h, 3Fh, 3Fh, 87h, 17h
		.db  14h,   1, 0Ch,   0,   1,	1, 50h,	96h, 3Fh, 3Fh, 87h, 17h
		.db    1, 26h, 0Ch,   0,   1, 14h, 32h,0B4h, 3Fh, 3Fh, 87h, 17h
		.db  14h,   1,	 0, 18h,   1,	1, 5Ah,	6Eh, 3Fh, 3Fh, 3Fh, 3Fh
		.db    0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0
LEVEL:		.db    1,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0
		.db  11h, 11h, 11h, 11h, 11h, 11h, 11h,	11h, 11h, 11h, 11h, 11h, 11h, 11h, 11h,	11h, 11h, 11h, 11h,   1
		.db    1,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   1
		.db    1,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   1
		.db    1,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   1
		.db    1,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   1
		.db    1,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   1
		.db    1,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   1
		.db    1,   0,	 0, 10h,   0,	0, 10h,	  0,   1,   0,	 0,   1, 10h,	0,   0,	10h,   0,   0,	 1,   1
		.db    0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   1
		.db    0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   1
		.db    0, 10h, 11h,   1, 11h, 11h,   1,	11h, 10h, 11h, 11h, 10h,   1, 11h, 11h,	  1, 11h, 11h,	 0,   1
		.db    0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0
		.db    0, 33h, 33h,   0, 30h, 33h,   0,	  3,   0,   3,	 3,   0,   3, 33h, 33h,	  3,   3,   0,	 0,   0
		.db    0,   3,	 0,   3,   3,	0,   3,	30h,   0,   3, 33h, 33h,   3,	3,   0,	  0,   3,   0,	 0,   0
		.db    0,   3,	 0,   3,   3,	0,   3,	30h,   0,   3, 30h, 30h,   0,	3,   0,	  0,   3,   0,	 0,   0
		.db    0,   3,	 0,   3,   3,	0,   3,	30h,   0,   3, 30h, 30h,   0,	3,   0,	  0, 33h, 33h,	 0,   0
		.db    0, 33h, 33h,   0,   3,	0,   3,	30h,   0,   3, 30h, 30h,   0, 33h,   3,	  0,   3,   0,	 3,   0
		.db    0,   3,	 0,   0,   3,	0,   3,	30h,   0,   3, 30h, 30h,   0,	3,   0,	  0,   3,   0,	 3,   0
		.db    0,   3,	 0,   0,   3,	0,   3,	30h,   0,   3, 30h, 30h,   0,	3,   0,	  0,   3,   0,	 3,   0
		.db    0, 33h, 33h,   3, 30h, 33h,   0,	  0, 33h,   3,	 0, 33h,   0, 33h, 33h,	  3, 33h, 33h,	 0,   0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0
		.db  11h, 11h, 11h, 11h, 11h, 11h, 11h,	11h, 11h, 11h, 11h, 11h, 11h, 11h, 11h,	11h, 11h, 11h, 11h, 11h
		.db  41h,   4, 42h,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0, 12h
		.db  31h, 23h,	 3, 20h, 11h, 11h, 11h,	11h, 11h, 11h, 11h, 11h, 11h, 11h, 11h,	11h, 11h, 11h, 11h, 12h
		.db    1, 30h,	 0, 10h, 22h, 22h, 22h,	22h, 22h, 22h, 22h, 22h, 22h, 22h, 22h,	22h, 22h, 22h, 22h, 12h
		.db  11h,   1,	 0, 10h, 12h, 13h, 13h,	13h, 13h, 13h, 13h, 13h, 13h, 13h, 13h,	13h, 13h, 13h, 13h, 13h
		.db  21h,   3,	 0,   0,   3, 43h, 43h,	43h, 43h, 43h, 43h, 43h, 43h, 43h, 43h,	43h, 43h, 43h,	 3, 13h
		.db  21h, 11h, 11h, 11h, 11h, 11h, 11h,	11h, 11h, 11h, 11h, 11h, 11h, 11h, 11h,	11h, 11h, 11h, 11h, 11h
		.db  41h, 21h, 22h, 23h, 11h, 10h, 22h,	22h, 22h, 22h, 22h, 22h, 12h, 22h, 14h,	  0,   0,   0,	 0, 10h
		.db  21h, 21h, 30h, 23h, 41h, 10h, 22h,	12h, 11h, 11h, 11h, 11h, 12h,	2, 13h,	  0,   0,   0,	 0, 10h
		.db  21h, 23h, 12h, 40h,   3, 10h, 22h,	32h, 24h, 22h, 22h, 22h, 12h, 22h, 13h,	  0,   0,   0,	 0, 10h
		.db  21h, 23h, 12h, 21h, 11h, 11h, 22h,	12h, 11h, 11h, 11h, 11h, 11h, 22h, 13h,	  0,   0,   1,	 0, 10h
		.db  21h, 22h, 22h, 30h, 22h, 22h, 22h,	22h, 22h, 22h, 22h, 22h, 22h, 22h, 22h,	  0,   0,   0,	 0, 10h
		.db  11h, 11h, 11h, 11h, 11h, 11h, 11h,	11h, 11h, 11h, 11h, 11h, 11h, 11h, 11h,	  0,   0,   2,	 0, 10h
		.db  21h, 40h, 40h, 20h, 22h, 22h, 22h,	14h, 24h, 22h,	 0, 21h, 23h, 32h, 22h,	11h, 12h, 13h, 22h, 12h
		.db  21h,   0,	 0, 20h, 22h, 43h, 20h,	12h, 24h, 22h, 20h, 32h, 22h, 22h, 22h,	21h, 12h, 13h, 22h, 12h
		.db  21h,   0,	 2, 20h, 22h, 43h, 22h,	12h,   3, 22h, 32h, 22h, 32h, 12h, 13h,	22h, 41h, 43h, 21h, 12h
		.db  11h,   1,	 3, 22h, 22h, 43h, 22h,	12h, 23h, 22h, 33h, 32h, 23h, 41h, 23h,	12h, 33h, 33h, 13h, 12h
		.db  21h, 22h, 24h, 22h, 22h, 43h, 22h,	12h, 43h, 22h, 33h, 21h, 32h, 22h, 32h,	12h, 34h, 33h, 14h, 12h
		.db  21h, 22h, 23h, 22h, 22h, 43h, 22h,	12h, 23h, 22h, 32h, 32h, 22h, 32h, 22h,	12h, 33h, 33h, 13h, 12h
		.db  21h, 32h, 33h, 22h, 22h, 43h, 22h,	22h, 23h, 22h, 22h, 23h, 22h, 22h, 13h,	12h, 33h, 33h, 13h, 12h
		.db  81h, 32h, 33h, 22h, 22h, 22h, 22h,	22h, 22h, 22h, 23h, 12h, 32h, 12h, 23h,	12h, 33h, 33h, 13h, 14h
		.db  11h, 11h, 11h, 11h, 11h, 11h, 11h,	11h, 11h, 11h, 11h, 11h, 11h, 11h, 11h,	11h, 11h, 11h, 11h, 11h
		.db  11h, 11h, 11h, 11h, 11h, 11h, 11h,	11h, 11h, 11h, 11h, 11h, 11h, 11h, 11h,	11h, 11h, 11h, 11h, 11h
		.db  31h, 23h,	 0, 40h,   2, 22h, 22h,	20h, 12h, 32h, 38h, 21h,   2,	2,   2,	  0,   0,   0, 20h, 14h
		.db  21h, 22h, 20h, 32h,   3,	0,   0,	20h, 12h, 32h, 32h, 21h,   2,	2,   2,	  0,   2,   0, 10h, 14h
		.db    1,   0, 20h, 30h,   0,	2, 20h,	30h, 12h, 32h, 32h,   1,   2,	2,   2,	  0,   3,   0, 10h, 14h
		.db    1,   2, 22h, 20h, 20h, 23h, 32h,	  0, 30h, 32h, 32h,   1,   3,	3,   3,	10h, 13h,   0, 10h, 14h
		.db    1, 22h, 23h, 30h, 20h, 23h, 22h,	  2, 12h, 30h, 30h, 22h, 22h, 22h,   2,	31h, 33h,   1, 20h, 14h
		.db    1, 34h, 42h, 22h, 42h, 22h, 22h,	22h, 12h,   0,	 0, 31h, 34h, 34h, 14h,	43h, 43h, 13h, 10h, 13h
		.db  11h, 11h, 11h, 11h, 11h, 11h, 11h,	11h, 11h,   0,	 0, 11h, 11h, 11h, 11h,	11h, 11h, 11h, 11h, 11h
		.db  11h,   0,	 0, 11h, 22h, 22h, 22h,	22h, 12h,   0,	 0, 21h, 22h, 22h, 22h,	22h, 22h,   0, 33h, 13h
		.db  71h,   0,	 0, 17h, 22h, 22h, 72h,	22h, 12h,   0,	 0, 21h, 12h, 11h, 11h,	11h, 11h,   0, 30h, 13h
		.db    1, 10h,	 1, 10h, 22h, 22h,   2,	22h, 12h,   0,	 0, 21h, 12h, 22h, 22h,	22h, 22h,   1,	 0, 13h
		.db    1, 10h,	 1, 10h, 22h, 22h,   2,	22h, 12h,   0,	 0, 41h, 12h, 12h, 13h,	11h, 21h,   1,	 0, 10h
		.db    1, 70h,	 0, 10h, 22h, 22h,   2,	12h, 11h,   0,	 0, 31h, 11h, 12h, 23h,	22h, 21h, 11h, 11h, 10h
		.db  11h,   0,	 0, 11h, 22h, 22h,   2,	23h, 22h,   0,	 0, 22h, 22h, 12h, 23h,	22h, 21h, 22h, 32h, 10h
		.db  11h, 11h, 11h, 11h, 11h, 11h, 11h,	11h, 11h, 10h, 11h, 11h, 11h, 11h, 11h,	11h, 11h, 11h, 11h, 11h
		.db  21h, 33h, 33h, 22h,   0, 30h,   2,	30h, 12h, 20h, 33h,   1,   0,	2,   0,	  0,   2,   3,	 0, 10h
		.db  21h, 23h, 22h, 22h,   1, 11h, 12h,	12h, 12h, 20h, 33h,   1,   0,	2,   0,	  0,   2, 11h, 21h, 11h
		.db  21h, 32h, 23h, 22h,   1, 12h, 12h,	12h, 12h, 20h, 33h,   1, 20h, 24h,   0,	20h, 24h,   0, 41h, 11h
		.db  21h, 22h, 32h, 22h,   1, 12h, 12h,	12h, 12h, 20h, 33h,   0, 42h, 44h,   2,	42h, 44h,   2, 41h, 11h
		.db  21h, 23h, 32h, 22h,   1, 12h, 12h,	12h, 12h, 24h, 33h,   1,   0,	4,   0,	  0,   4,   0, 41h, 11h
		.db  21h, 32h, 23h, 22h,   2,	2, 30h,	  2, 23h, 24h, 33h,   1,   0,	0,   0,	  0,   0,   0, 41h, 11h
		.db  11h, 11h, 11h, 11h, 11h, 11h, 11h,	11h, 11h, 11h, 11h, 11h, 11h, 11h, 11h,	11h, 11h, 11h, 11h, 11h
		.db  11h, 11h, 11h, 11h, 11h, 11h, 11h,	11h, 11h, 11h, 11h, 11h, 11h, 11h, 11h,	11h, 11h, 11h, 11h, 11h
		.db    1,   0, 10h, 13h, 33h,	2,   0,	  3,   3, 10h,	 0,   0, 42h, 33h,   0,	10h,   0,   0,	 0, 10h
		.db    1,   0, 10h, 14h, 33h,	2,   0,	  0, 21h, 10h,	 0,   0, 41h,	3,   0,	10h,   0,   0,	 0, 10h
		.db    1,   0, 10h, 14h, 34h,	2,   0,	  0, 11h, 10h,	 0,   0, 31h,	0,   0,	20h,   0,   0,	 0, 10h
		.db    1,   0, 10h, 14h, 33h,	0,   0,	  0, 41h, 10h,	 0,   0,   1,	0,   0,	10h,   0,   0,	 0, 10h
		.db    1,   0, 10h, 14h,   3,	0,   0,	  0,   1, 10h,	 0,   0,   1,	0,   0,	10h,   0,   0,	 0, 10h
		.db  11h, 10h, 11h, 12h, 11h, 10h, 11h,	21h, 11h,   1, 10h,   0, 11h,	1, 21h,	12h,   1, 21h, 22h, 11h
		.db    1, 10h,	 0,   3,   0,	0,   0,	  0,   0,   0,	 0,   1,   0,	0,   0,	  0,   0,   0,	 0, 10h
		.db    1, 30h,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0, 10h
		.db    1,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0, 10h
		.db    1, 22h,	 0, 20h,   0,	2,   2,	  2,   0, 20h,	 0,   2,   0,	2,   0,	  2,   2,   2,	 2, 10h
		.db  11h, 33h, 11h, 31h,   1, 13h, 23h,	13h, 11h, 31h, 11h, 13h, 11h, 13h, 11h,	13h, 13h, 13h, 13h, 12h
		.db  21h, 33h, 22h, 32h, 22h, 23h, 23h,	23h, 22h, 32h, 22h, 23h, 22h, 23h, 22h,	23h, 23h, 33h, 13h, 12h
		.db  21h, 23h, 23h, 23h, 23h, 23h, 23h,	24h, 22h, 23h, 23h, 24h, 22h, 24h, 22h,	23h, 23h, 23h, 13h, 12h
		.db  21h, 23h, 23h, 23h, 23h, 23h, 23h,	23h, 22h, 23h, 23h, 23h, 22h, 23h, 22h,	33h, 23h, 23h, 13h, 12h
		.db  21h, 33h, 22h, 23h, 23h, 23h, 23h,	23h, 22h, 23h, 23h, 23h, 22h, 33h, 23h,	23h, 23h, 23h, 13h, 12h
		.db  21h, 23h, 24h, 23h, 24h, 23h, 23h,	23h, 22h, 23h, 23h, 23h, 22h, 23h, 23h,	23h, 23h, 32h, 13h, 12h
		.db  21h, 34h, 22h, 32h, 22h, 32h, 24h,	33h, 24h, 42h, 22h, 33h, 23h, 33h, 24h,	32h, 24h, 22h, 14h, 12h
		.db  21h, 22h, 22h, 22h, 22h, 22h, 22h,	22h, 22h, 22h, 22h, 22h, 22h, 22h, 22h,	22h, 22h, 22h, 12h, 12h
		.db  11h, 11h, 11h, 11h, 11h, 11h, 11h,	11h, 11h, 11h, 11h, 11h, 11h, 11h, 11h,	11h, 11h, 11h, 11h, 10h
		.db  81h,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0, 10h
		.db  11h, 11h, 11h, 11h, 11h, 11h, 11h,	11h, 11h, 11h, 11h, 11h, 11h, 11h, 11h,	11h, 11h, 11h, 11h, 11h
		.db  11h, 11h, 11h, 11h, 11h, 11h, 11h,	11h, 11h, 11h, 11h, 11h, 11h, 11h, 11h,	11h, 11h, 11h, 11h, 11h
		.db  41h, 21h, 22h, 22h, 12h, 22h, 22h,	22h, 22h, 22h, 22h, 22h, 22h, 22h, 22h,	22h, 22h, 22h, 22h, 10h
		.db  21h, 21h, 11h, 11h, 12h, 11h, 11h,	11h, 21h, 11h, 11h, 11h, 11h, 12h, 11h,	11h, 11h, 33h, 21h, 10h
		.db  21h, 21h, 22h, 21h, 22h, 22h, 22h,	22h, 22h, 21h, 11h, 22h, 12h, 32h, 22h,	22h, 22h, 22h, 12h, 10h
		.db  21h, 11h, 12h, 11h, 11h, 11h, 11h,	11h, 11h, 21h, 22h, 12h, 12h, 11h, 21h,	11h, 11h, 11h, 12h, 10h
		.db  21h, 22h, 22h, 21h, 12h, 21h, 21h,	21h, 22h, 22h, 11h, 21h, 12h, 22h, 21h,	22h, 22h, 11h, 12h, 10h
		.db  11h, 11h, 11h, 21h, 12h, 21h, 22h,	21h, 21h, 22h, 21h, 22h, 21h, 21h, 11h,	11h, 21h, 11h, 32h, 10h
		.db  31h, 22h, 21h, 22h, 12h, 22h, 21h,	11h, 11h, 21h, 21h, 12h, 22h, 21h, 21h,	12h, 21h, 12h, 11h, 11h
		.db  31h, 22h, 22h, 11h, 12h, 22h, 21h,	21h, 11h, 22h, 21h, 11h, 22h, 21h, 22h,	22h, 21h, 11h, 22h, 12h
		.db  31h, 12h, 22h, 21h, 12h, 12h, 21h,	21h, 21h, 12h, 21h, 12h, 21h, 11h, 11h,	21h, 21h, 11h, 12h, 12h
		.db  31h, 12h, 22h, 31h, 11h, 22h, 21h,	21h, 11h, 22h, 12h, 23h, 22h, 22h, 12h,	22h, 21h, 21h, 12h, 12h
		.db  31h, 12h, 21h,   3, 22h, 12h, 21h,	22h, 22h, 12h, 22h, 23h, 11h, 11h, 22h,	22h, 22h, 22h, 21h, 12h
		.db  31h, 12h, 11h, 11h, 11h, 11h, 11h,	11h, 11h, 11h, 11h, 11h, 31h, 33h, 11h,	11h, 11h, 11h, 11h, 13h
		.db  21h, 12h, 22h, 32h, 31h, 31h, 22h,	32h, 31h,   1, 32h, 70h, 21h,	0,   0,	71h, 10h,   0, 11h, 10h
		.db  21h, 12h, 22h, 32h,   1, 21h, 23h,	23h,   1,   1,	 2,   0, 21h,	0,   0,	  1, 10h,   1,	 1, 10h
		.db  21h, 12h, 22h, 32h,   1, 21h, 32h,	22h,   1,   1,	 2,   0, 21h,	0,   0,	  0,   0,   0,	 1, 10h
		.db  21h, 12h, 33h, 33h,   1, 21h, 23h,	23h,   1,   1,	 2,   0, 21h,	0,   0,	11h,   1, 10h, 11h, 10h
		.db  21h, 12h, 23h, 32h,   1, 31h, 22h,	32h,   1,   1,	 2,   0, 21h,	0,   0,	  1,   0,   0,	 0, 10h
		.db  21h, 12h, 23h, 32h, 71h, 31h, 33h,	33h, 71h,   1,	 2,   0, 21h,	0,   0,	  1, 10h,   1,	 1, 11h
		.db    1,   0, 11h, 11h, 20h, 10h, 11h,	11h, 20h, 10h,	 2, 12h, 21h, 20h, 11h,	11h, 11h, 11h, 11h, 11h
		.db    1,   0,	 0,   0, 30h,	0,   0,	  0, 30h,   0,	 2,   0, 23h, 30h,   0,	  0,   0,   0,	 0, 18h
		.db  11h, 11h, 11h, 11h, 11h, 11h, 11h,	11h, 11h, 11h, 11h, 11h, 11h, 11h, 11h,	11h, 11h, 11h, 11h, 11h
		.db  11h, 11h, 11h, 11h, 11h, 11h, 11h,	11h, 11h, 11h, 11h, 11h, 11h, 11h, 11h,	11h, 11h, 11h, 11h, 11h
		.db    1, 22h, 23h, 32h, 22h, 21h, 21h,	12h, 22h, 22h, 12h, 22h, 22h, 22h, 22h,	22h, 12h, 22h, 22h, 13h
		.db  31h, 23h, 22h, 21h, 22h, 31h, 12h,	22h, 23h, 22h, 13h, 22h, 32h, 21h, 22h,	23h, 12h, 23h, 22h, 12h
		.db  21h, 33h, 23h, 12h, 22h, 21h, 32h,	22h, 22h, 22h, 12h, 22h, 12h, 32h, 32h,	32h, 12h, 32h, 24h, 12h
		.db  21h, 33h, 22h, 32h, 32h, 21h, 12h,	21h, 22h, 23h, 12h, 32h, 22h, 22h, 12h,	22h, 23h, 32h, 22h, 12h
		.db  21h, 22h, 32h, 43h, 21h, 22h, 13h,	22h, 23h, 22h, 11h, 22h, 21h, 22h, 21h,	31h, 22h, 32h, 32h, 12h
		.db  11h, 22h, 33h, 22h, 23h, 22h, 22h,	22h, 21h, 24h, 22h, 23h, 31h, 32h, 22h,	12h, 11h, 11h, 11h, 11h
		.db  11h, 23h, 32h, 13h, 22h, 23h, 11h,	32h, 21h, 32h, 12h, 22h, 21h, 22h, 22h,	22h, 22h, 22h, 22h, 13h
		.db  11h, 22h, 32h, 33h, 22h, 22h, 12h,	22h, 32h, 22h, 21h, 22h, 21h, 22h, 21h,	21h, 11h, 23h, 11h, 11h
		.db  11h, 22h, 21h, 12h, 32h, 32h, 12h,	11h, 12h, 11h, 22h, 22h, 23h, 23h, 32h,	22h, 22h, 22h, 22h, 12h
		.db  21h, 32h, 22h, 32h, 22h, 22h, 23h,	23h, 12h, 32h, 22h, 31h, 22h, 22h, 22h,	12h, 22h, 11h, 21h, 13h
		.db  21h, 31h, 33h, 12h, 32h, 23h, 22h,	12h, 22h, 22h, 12h, 22h, 12h, 11h, 22h,	12h, 23h, 22h, 24h, 12h
		.db  21h, 13h, 22h, 31h, 23h, 23h, 23h,	32h, 12h, 24h, 23h, 22h, 12h, 23h, 12h,	23h, 22h, 22h, 22h, 12h
		.db  21h, 23h, 22h, 22h, 22h, 22h, 32h,	22h, 23h, 13h, 22h, 23h, 22h, 22h, 14h,	22h, 12h, 21h, 23h, 12h
		.db  21h, 23h, 13h, 21h, 22h, 23h, 41h,	23h, 12h, 22h, 22h, 11h, 11h, 21h, 23h,	22h, 22h, 22h, 22h, 12h
		.db  21h, 23h, 32h, 22h, 32h, 12h, 22h,	12h, 23h, 12h, 21h, 22h, 31h, 22h, 22h,	21h, 32h, 22h, 22h, 11h
		.db  21h, 33h, 21h, 22h, 21h, 21h, 22h,	21h, 22h, 12h, 23h, 22h, 23h, 22h, 12h,	32h, 22h, 11h, 23h, 11h
		.db  31h, 22h, 22h, 32h, 22h, 23h, 32h,	21h, 22h, 22h, 22h, 23h, 22h, 32h, 12h,	22h, 22h, 22h, 22h, 11h
		.db  21h, 12h, 32h, 21h, 12h, 22h, 12h,	12h, 11h, 33h, 24h, 21h, 12h, 22h, 22h,	12h, 32h, 22h, 22h, 14h
		.db  21h, 13h, 21h, 22h, 23h, 23h, 21h,	32h, 22h, 22h, 23h, 21h, 32h, 22h, 31h,	22h, 22h, 32h, 22h, 12h
		.db  21h, 22h, 14h, 22h, 22h, 32h, 22h,	22h, 22h, 22h, 22h, 21h, 22h, 22h, 21h,	22h, 12h, 22h, 22h, 13h
		.db  11h, 11h, 11h, 11h, 11h, 11h, 11h,	11h, 11h, 11h, 11h, 11h, 11h, 11h, 11h,	11h, 11h, 11h, 11h, 11h
		.db  11h, 11h, 11h, 11h, 11h, 11h, 11h,	11h, 11h, 11h, 11h, 11h, 11h, 11h, 11h,	11h, 11h, 11h, 11h, 11h
		.db  21h, 22h, 22h, 22h, 22h, 22h, 22h,	22h, 22h, 22h, 22h, 22h, 22h, 22h, 22h,	22h, 22h, 22h, 22h, 12h
		.db  21h,   8,	 0,   0,   0,	0,   0,	70h,   0,   0,	 0,   2,   0,	0,   0,	  0,   0,   0,	 0, 12h
		.db  21h,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   2,   0,	0,   0,	  0,   0,   0,	 0, 12h
		.db  21h,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0, 12h
		.db  21h,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0, 12h
		.db  21h,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0, 12h
		.db  21h,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0, 20h,   0,	0,   0,	  0,   0,   0,	 0, 12h
		.db  21h,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0, 30h,   0,	0,   0,	  0,   0,   0,	 0, 12h
		.db  21h,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0, 12h
		.db  21h,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0, 12h
		.db  21h,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0, 12h
		.db  21h,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0, 12h
		.db  21h,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0, 12h
		.db  21h,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0, 12h
		.db  21h,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0, 12h
		.db  21h,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0, 12h
		.db  21h,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0, 12h
		.db  21h,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0, 12h
		.db  21h,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0,   0,   0,	0,   0,	  0,   0,   0,	 0, 12h
		.db  21h, 22h, 22h, 22h, 22h, 22h, 22h,	22h, 22h, 22h, 22h, 22h, 22h, 22h, 22h,	22h, 22h, 22h, 22h, 12h
		.db  11h, 11h, 11h, 11h, 11h, 11h, 11h,	11h, 11h, 11h, 11h, 11h, 11h, 11h, 11h,	11h, 11h, 11h, 11h, 11h
		.db  11h, 11h, 11h, 11h, 11h, 11h, 11h,	11h, 11h, 11h, 11h, 11h, 11h, 11h, 11h,	11h, 11h, 11h, 11h, 11h
		.db    1,   0,	 4,   0, 31h, 33h, 34h,	41h, 41h, 14h, 23h,   2, 21h, 22h, 30h,	32h, 22h, 32h, 22h, 12h
		.db    1, 11h, 11h,   1, 21h, 22h, 22h,	41h, 21h, 12h, 32h,   2, 23h, 31h, 22h,	32h,   2, 23h, 23h, 12h
		.db    1, 32h, 34h,   1, 41h, 33h, 32h,	41h, 21h, 12h, 22h, 11h, 11h, 11h, 11h,	11h, 11h, 11h, 31h, 12h
		.db    1, 31h, 32h,   2, 21h, 22h, 42h,	41h, 21h, 12h, 22h,   1,   0,	0,   0,	  0,   0,   0, 21h, 12h
		.db    1, 41h, 34h, 11h, 11h, 23h, 32h,	  1, 21h, 12h, 23h,   1, 22h, 22h, 22h,	22h, 22h, 22h, 21h, 12h
		.db    1, 12h, 12h,   1, 21h, 32h, 10h,	  1, 21h, 12h, 23h,   1, 12h, 11h, 11h,	11h, 11h, 22h, 21h, 13h
		.db    1, 33h, 24h,   2, 21h, 23h, 21h,	  2, 21h, 12h, 23h,   1, 12h,	0,   0,	  0, 13h, 22h, 21h, 12h
		.db    1, 11h, 31h,   3, 21h, 11h, 21h,	21h, 21h, 12h, 32h,   1, 12h, 20h, 22h,	  2, 10h, 22h, 21h, 12h
		.db    1,   0,	 0,   0, 21h, 22h, 22h,	43h, 21h, 12h, 32h,   1, 12h, 20h, 11h,	21h, 10h, 22h, 31h, 12h
		.db  11h, 12h, 11h, 11h, 11h, 11h, 21h,	31h, 20h, 12h, 32h,   1, 12h, 20h, 42h,	21h, 10h, 22h, 21h, 12h
		.db  11h, 32h,	 0,   0,   0, 40h, 34h,	12h, 31h, 12h, 33h,   1, 12h,	0, 70h,	21h, 10h, 22h, 21h, 12h
		.db    1, 10h,	 1,   0,   0,	0, 14h,	  0, 31h, 13h, 23h,   1, 12h, 11h, 11h,	21h, 30h, 22h, 21h, 13h
		.db    1, 10h,	 4,   0,   0,	0, 10h,	  0, 21h, 13h, 23h,   1, 22h, 22h, 22h,	22h, 10h, 22h, 21h, 12h
		.db    1, 10h,	 0,   0,   0,	0, 10h,	  0, 31h, 13h, 32h,   1,   0,	0,   0,	  0, 10h, 12h, 21h, 12h
		.db    1, 10h, 11h, 21h, 22h, 11h, 11h,	  0, 31h, 12h, 32h, 11h, 11h, 11h, 11h,	11h, 11h, 22h, 31h, 12h
		.db    1, 30h, 33h, 33h, 32h, 33h, 33h,	  0, 31h, 13h, 22h,   3,   0, 32h, 22h,	21h, 22h, 21h, 21h, 12h
		.db    1,   0, 43h, 34h, 32h, 44h,   3,	  0, 21h, 33h, 32h, 21h, 22h, 23h, 22h,	22h, 21h, 22h, 21h, 12h
		.db    1,   0, 30h, 34h, 32h, 34h,   0,	  0, 31h, 13h, 11h, 11h, 11h, 11h, 11h,	11h, 11h, 11h, 21h, 13h
		.db    1,   0,	 0, 33h, 32h,	3,   0,	  0, 31h, 23h, 22h, 32h, 31h, 23h, 22h,	13h, 32h, 22h, 23h, 12h
		.db    1,   0,	 0, 30h, 38h,	0,   0,	  0, 31h, 23h, 32h, 23h, 22h, 22h, 23h,	22h, 32h, 32h, 22h, 12h
		.db  11h, 11h, 11h, 11h, 11h, 11h, 11h,	11h, 11h, 11h, 11h, 11h, 11h, 11h, 11h,	11h, 11h, 11h, 11h, 11h
		.db  11h, 11h, 11h, 11h, 11h, 11h, 11h,	11h, 11h, 11h, 11h, 11h, 11h, 11h, 11h,	11h, 11h, 11h, 11h, 11h
		.db  81h, 21h, 22h, 22h, 22h, 22h, 22h,	12h, 22h, 22h, 22h, 22h, 21h, 22h, 22h,	22h, 22h, 22h, 22h, 12h
		.db    1, 21h, 22h, 22h, 22h, 22h, 12h,	12h, 22h, 21h, 11h, 21h, 12h, 12h, 23h,	11h,   1, 21h, 11h, 12h
		.db    1, 21h, 22h, 12h, 11h, 22h, 13h,	12h, 12h, 12h, 22h, 22h, 12h, 12h, 12h,	12h,   0, 11h, 22h, 12h
		.db    1, 10h, 22h, 71h, 70h, 21h, 21h,	22h, 12h, 22h, 11h, 11h, 21h, 22h, 21h,	21h,   1, 20h, 11h, 12h
		.db    1, 21h, 12h,   0,   0, 10h, 17h,	22h, 22h, 22h, 21h, 12h, 12h, 12h, 22h,	12h,   0, 10h, 22h, 12h
		.db    1, 21h, 12h,   0,   7, 10h, 10h,	31h, 12h, 21h, 22h, 22h,   1, 22h, 11h,	21h, 11h, 10h, 12h, 12h
		.db    1, 21h, 12h,   0,   0, 10h, 10h,	12h, 22h, 11h, 23h, 22h, 73h,	0,   0,	10h, 70h, 10h, 12h, 12h
		.db    1, 21h, 12h, 70h, 70h, 10h, 10h,	22h, 12h, 22h, 12h, 12h, 11h, 11h, 22h,	10h,   1, 10h, 12h, 12h
		.db    1, 31h, 12h,   0,   0, 10h, 10h,	32h, 21h, 22h, 12h, 22h, 22h, 12h, 12h,	10h, 10h, 10h, 12h, 12h
		.db    1, 21h, 12h,   7,   7, 17h, 20h,	11h, 12h, 21h, 12h, 12h, 21h, 11h, 21h,	12h, 10h, 22h, 11h, 12h
		.db    1, 21h, 12h,   0,   0, 10h, 10h,	22h, 22h, 12h, 21h, 22h, 22h, 12h, 22h,	12h, 20h, 13h,	 0, 12h
		.db    1, 21h, 12h, 70h, 70h, 10h, 20h,	21h, 12h, 22h, 13h, 13h, 11h, 21h, 12h,	22h,   1, 23h, 22h, 13h
		.db    1, 31h, 12h,   0,   0, 10h, 10h,	12h, 12h, 12h, 10h, 22h, 22h, 22h, 22h,	12h, 22h, 11h, 11h, 12h
		.db    1, 21h, 32h,   1,   7, 31h, 10h,	12h, 12h, 11h, 17h, 12h, 12h, 11h, 11h,	13h, 12h, 22h, 22h, 12h
		.db    1, 21h, 22h, 21h, 20h,	1, 10h,	22h, 22h, 12h, 10h, 12h, 12h, 12h, 12h,	12h, 12h, 12h, 12h, 13h
		.db    1, 31h, 22h, 31h, 30h,	1, 11h,	12h, 11h, 11h, 20h, 22h, 22h, 12h, 11h,	21h, 12h, 12h, 12h, 12h
		.db    1, 21h, 22h, 12h, 10h,	2, 23h,	22h,   1,   0, 30h, 22h, 21h, 21h, 21h,	22h, 11h, 12h, 12h, 17h
		.db  31h, 21h, 22h, 12h, 10h,	2, 21h,	21h, 12h, 21h, 21h, 21h, 12h, 12h, 22h,	11h, 21h, 22h, 12h, 10h
		.db  31h, 21h, 23h, 12h, 30h,	2, 23h,	11h, 12h, 12h, 12h, 12h, 13h, 22h, 12h,	12h, 12h, 12h, 13h, 10h
		.db  31h, 22h, 22h, 11h, 11h,	1, 10h,	20h, 22h, 22h, 22h, 22h, 23h, 12h,   1,	  0,   0,   0,	 0, 10h
		.db  11h, 11h, 11h, 11h, 11h, 11h, 11h,	11h, 11h, 11h, 11h, 11h, 11h, 11h, 11h,	11h, 11h, 11h, 11h, 11h
		.db  11h, 11h, 11h, 11h, 11h, 11h, 11h,	11h, 11h, 11h, 11h, 11h, 11h, 11h, 11h,	11h, 11h, 11h, 11h, 11h
		.db  41h, 22h, 22h, 22h, 22h, 22h, 22h,	24h, 31h, 23h, 24h, 22h, 22h, 33h, 44h,	22h, 22h, 22h, 22h, 18h
		.db  41h, 21h, 11h, 11h, 11h, 11h, 41h,	42h, 31h, 23h, 11h, 21h, 22h, 33h, 33h,	11h, 11h, 21h, 22h, 12h
		.db  41h, 21h, 41h, 22h, 22h, 30h, 22h,	24h, 31h, 23h, 22h, 21h, 22h, 23h, 33h,	14h, 42h, 21h, 22h, 12h
		.db  41h, 21h, 21h, 22h, 22h, 22h, 41h,	43h, 31h, 23h, 22h, 41h, 42h, 23h, 22h,	23h, 32h, 21h, 22h, 12h
		.db  41h, 21h, 31h, 11h, 11h, 11h, 11h,	11h, 31h, 23h, 22h, 31h, 32h, 23h, 22h,	12h, 11h, 21h, 12h, 11h
		.db  31h, 21h, 22h, 22h, 22h, 22h, 22h,	22h, 42h, 23h, 22h, 31h, 22h, 23h, 22h,	22h, 22h, 22h, 32h, 12h
		.db  11h, 11h, 11h, 11h, 11h, 11h, 11h,	11h, 11h, 22h, 22h, 11h, 11h, 11h, 11h,	11h, 11h, 11h, 11h, 14h
		.db  21h, 22h, 22h, 23h, 22h, 22h, 23h,	32h, 10h, 22h, 22h, 41h, 41h, 32h, 33h,	42h, 33h, 33h, 22h, 12h
		.db  21h, 22h, 22h, 22h, 22h, 22h, 22h,	22h, 10h, 22h, 22h,   1,   1, 22h, 32h,	22h, 22h, 22h, 22h, 12h
		.db  21h, 23h, 22h, 22h, 22h,	0,   3,	  0, 30h, 22h, 22h,   1,   1,	3, 23h,	34h, 22h, 32h, 42h, 12h
		.db  21h, 22h, 22h, 22h, 32h, 20h, 22h,	22h, 12h, 22h, 22h,   1,   0, 22h, 22h,	23h, 43h, 22h, 23h, 13h
		.db    1,   0,	 0,   0,   3, 20h, 23h,	22h, 12h, 22h, 22h,   4,   0, 23h, 23h,	23h, 33h, 22h, 33h, 13h
		.db  11h, 11h, 11h, 11h, 11h, 11h, 11h,	11h, 11h, 13h, 11h, 11h, 12h, 11h, 11h,	11h, 11h, 11h, 11h, 11h
		.db  31h, 32h, 32h, 32h, 32h, 32h, 32h,	23h, 12h, 13h, 22h, 22h, 24h, 22h,   0,	  0,   1,   0,	 0, 14h
		.db  31h, 32h, 22h, 32h, 32h, 22h, 22h,	32h, 12h, 14h, 22h, 12h, 23h, 22h,   0,	  0,   1,   0, 10h, 14h
		.db  31h, 32h, 22h, 32h, 33h, 22h, 22h,	32h, 12h, 14h, 22h, 12h, 23h, 22h,   0,	  0,   1,   0, 10h, 14h
		.db  31h, 32h, 22h, 32h, 32h, 22h, 22h,	23h, 12h, 14h, 22h, 12h, 23h, 22h,   0,	  0,   3,   0, 10h, 14h
		.db  31h, 32h, 22h, 42h, 32h, 22h, 22h,	42h, 12h, 14h, 22h, 12h, 33h, 23h,   0,	10h, 13h,   0, 10h, 14h
		.db  21h, 43h, 22h, 22h, 33h, 22h, 32h,	23h, 12h, 23h, 22h, 12h, 44h, 23h,   0,	41h, 43h,   1, 10h, 14h
		.db  21h, 22h, 22h, 22h, 22h, 22h, 22h,	22h, 22h, 23h, 22h, 12h, 33h, 23h, 10h,	44h, 43h, 14h, 10h, 13h
		.db  11h, 11h, 11h, 11h, 11h, 11h, 11h,	11h, 11h, 11h, 11h, 11h, 11h, 11h, 11h,	11h, 11h, 11h, 11h, 11h
		.db  11h, 11h, 11h, 11h, 11h, 11h, 11h,	11h, 11h, 11h, 11h, 11h, 11h, 11h, 11h,	11h, 11h, 11h, 11h, 11h
		.db    1,   0,	 7,   0, 22h, 22h, 23h,	22h,   0,   0,	 0,   0, 70h, 21h, 32h,	  2,   2, 42h, 22h, 12h
		.db  21h, 22h, 20h, 22h, 12h,	2, 31h,	32h, 22h, 12h, 12h, 22h, 12h, 21h, 32h,	32h, 22h, 32h, 32h, 12h
		.db  21h, 23h, 20h, 24h, 41h, 20h, 42h,	11h, 11h, 12h, 22h, 12h, 43h, 22h, 20h,	24h, 21h, 12h, 32h, 12h
		.db  31h, 34h, 30h, 44h, 22h, 32h, 22h,	20h, 23h, 24h, 32h, 22h,   1, 42h, 22h,	21h, 23h, 24h, 12h, 12h
		.db  21h, 22h, 22h, 22h,   1, 42h, 22h,	22h, 22h,   1, 22h, 22h, 32h, 22h, 23h,	22h, 24h, 20h, 22h, 12h
		.db  41h, 22h, 23h, 23h, 32h, 22h,   1,	12h,   0, 22h, 21h, 22h, 13h, 22h,   1,	22h, 22h, 22h, 13h, 12h
		.db    1, 12h, 11h, 42h, 13h, 32h, 22h,	22h, 12h, 20h, 22h, 22h, 22h, 22h, 22h,	22h,   1, 22h, 23h, 13h
		.db  21h, 22h, 22h, 20h, 21h, 10h,   2,	22h,   4, 22h, 20h, 42h, 22h, 22h, 22h,	22h, 20h, 22h, 22h, 12h
		.db  21h, 22h, 22h, 20h, 22h, 32h, 32h,	23h,   2, 23h,	 2, 22h, 22h, 22h, 32h,	22h, 22h, 22h, 42h, 10h
		.db  21h, 20h, 22h, 22h, 22h, 22h, 22h,	22h, 22h, 22h, 22h, 22h, 32h, 22h, 22h,	22h, 30h, 22h, 22h, 13h
		.db  21h, 24h, 32h, 22h, 22h, 22h, 20h,	42h, 23h, 22h, 22h, 32h, 32h, 22h,   1,	22h,   1, 22h,	 1, 11h
		.db  31h, 21h, 10h, 10h, 22h, 22h, 32h,	32h, 33h, 23h, 23h, 22h, 24h,	2, 22h,	24h, 22h, 22h, 23h, 12h
		.db    1, 32h, 22h, 20h, 22h, 22h, 22h,	22h, 42h, 20h, 23h, 22h, 23h,	2,   2,	22h, 22h, 22h, 22h, 14h
		.db  31h,   2,	 0,   7,   0, 23h, 22h,	22h, 42h, 22h, 33h, 22h, 22h, 22h, 42h,	20h, 22h,   2, 22h, 11h
		.db  21h,   1,	 0,   0,   0, 24h, 23h,	24h, 11h, 23h, 23h, 21h, 22h, 12h, 23h,	22h, 42h, 22h,	 7, 12h
		.db  21h,   2,	 0,   0,   0, 12h, 20h,	22h, 21h, 22h, 23h, 22h,   2, 32h, 32h,	22h, 22h, 22h,	 0, 10h
		.db    1, 22h, 22h, 20h, 22h, 22h, 11h,	42h, 22h, 22h, 23h, 23h,   3, 12h, 23h,	32h, 22h, 11h,	 0, 10h
		.db  31h,   0,	 0,   0,   0,	0, 70h,	22h,   2, 13h, 23h,   1, 22h, 24h, 22h,	32h, 32h, 32h,	 0, 10h
		.db  21h, 22h, 22h, 22h, 22h, 32h, 22h,	22h, 12h, 11h, 23h, 22h,   2, 12h, 23h,	42h, 20h,   2,	 0, 10h
		.db  11h, 22h,	 4, 23h,   2, 22h, 12h,	22h, 22h, 40h, 12h, 22h, 30h, 42h, 27h,	30h,   4,   2,	 1, 10h
		.db  11h, 11h, 11h, 11h, 11h, 11h, 11h,	11h, 11h, 11h, 11h, 11h, 11h, 11h, 11h,	11h, 11h, 11h, 11h, 11h
		.db  11h, 11h, 11h, 11h, 11h, 11h, 11h,	11h, 11h, 11h, 11h, 11h, 11h, 11h, 11h,	11h, 11h, 11h, 11h, 11h
		.db    1,   0,	 0,   0
