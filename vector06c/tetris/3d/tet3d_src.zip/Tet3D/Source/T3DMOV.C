#include "tet3d.h"

Rot(xv,yv,ax,ay,aXd,aYd,s) int s;char *ax,*ay,*aXd,*aYd,xv,yv;
{
int n,X,Y,xr,yr,t,sp,sm;
sp=s>0?0:1;sm=s<0?0:1;
for(X=Y=n=0;n<nblc;n+=3){
 t=fblc[n+yv];yr=fblc[n+yv]=s*fblc[n+xv]-sp;xr=fblc[n+xv]=-s*t-sm;
 xr=*ax+xr;yr=*ay+yr;
 if ( xr<0 ) X=max(X,-xr);  t=*aXd-1-xr; if ( t<0 ) X=min(X,t);
 if ( yr<0 ) Y=max(Y,-yr);  t=*aYd-1-yr; if ( t<0 ) Y=min(Y,t);
 }
*ax+=X;*ay+=Y;
if ( chkfig() ){
/* Okay */
 for(n=0;n<nver;n+=3){t=fver[n+yv];fver[n+yv]=s*fver[n+xv];fver[n+xv]=-s*t;}
 return 1;
 }
/* can't rotate , restore data */
*ax-=X;*ay-=Y;
for(n=0;n<nblc;n+=3)
{  t=fblc[n+yv];  fblc[n+yv]=-s*fblc[n+xv]-sm;  fblc[n+xv]=s*t-sp; }
return 0;
}

chkfig()
{
char xa,ya,za;
int n;
for(n=0;n<nblc;n+=3){
	xa=x+fblc[n]; ya=y+fblc[n+1]; za=z+fblc[n+2];
	if ( xa>=Xd || ya>=Yd || za>=Zd || Gls(xa,ya,za)) return 0;
 }
return 1;
}

initDIF()
{
int z,x,y,n,N;
N=2*Xd*Yd*Dif/3;
for(n=0;n<N;n++){
 x=rand()%Xd;
 z=Zd-1-rand()%Dif;
 y=rand()%Yd;
 Gls(x,y,z)=1;
 Zm=min(Zm,z);
 }
}

drGlass()
{
int x,y,z;
scolor(Dpal);
color(Cglass);
for(x=0;x<=Xd;x++)
{ plot3d(x,0,0);line3d(x,0,Zd); 
  plot3d(x,Yd,0);line3d(x,Yd,Zd); }
for(y=1;y<Yd;y++)
{ plot3d(0,y,0);line3d(0,y,Zd); 
  plot3d(Xd,y,0);line3d(Xd,y,Zd); }
for(z=0;z<=Zd;z++)
{ plot3d(0,0,z);line(Px(Xd,z),Py(Yd,z),B); }
for(x=1;x<Xd;x++){ plot3d(x,0,Zd);line3d(x,Yd,Zd); }
for(y=1;y<Yd;y++){ plot3d(0,y,Zd);line3d(Xd,y,Zd); }
initPANEL();
scolor(Gpal);
}

clrGlass(){setmem(_Gls,ZL*YL*XL,0);}

figure()
{
char set,*ver,dx,dy,dz;int n;
scolor(Fpal);
color(Cfig);
for(n=0;n<ncvz;n++){
	set=fcvz[n]&0x80;
	ver=fver+(fcvz[n]&0x7F)*3;
	dx=x+ver[0];dy=y+ver[1];dz=z+ver[2];
	if(set) plot3d(dx,dy,dz);
	else	line3d(dx,dy,dz);
}
scolor(Gpal);
}

plot3d(x,y,z) int x,y,z;
{plot(Px(x,z),Py(y,z),1);}
line3d(x,y,z) int x,y,z;
{line(Px(x,z),Py(y,z),0);}

#define PT 1

decout5(n) unsigned n;
{char s[10];sprintf(s,"%5u",n);spic(s);}

spektr()
{
int z,Z,tx,ty;
Z=Zd-Zm;
for(z=0;z<Z;z++){ color(z%7+1); plot(2,ty=z*14+10,1);line(10,ty+12,BF); }
}

initPANEL()
{
color(2);
plot(0,8,1);line(12,Zd*14+10,B);
color(2);
cur(35,PT);spic("O~ki");
cur(35,PT+3);spic("Kubiki");
cur(35,PT+6);spic("Temp");
cur(35,21);spic("Igra");
color(3);
cur(35,22);spic(Game);
cur(35,23);spic(bs[Bset]);
scoreout();
levelout();
cubout();
}


scoreout(){color(7);cur(35,PT+1);decout5(Score);}
cubout(){color(7);cur(35,PT+4);decout5(CubPl);}
levelout(){color(7);cur(35,PT+7);decout5(Level);}
