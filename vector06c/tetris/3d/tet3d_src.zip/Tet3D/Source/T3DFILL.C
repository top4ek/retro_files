#include "tet3d.h"


fillwing(x,y,z) char x,y,z;
{
char fd;
col=(Zd-1-z)%7+1;
x1=Px(x,z);y1=Py(y,z);
x2=Px(x+1,z);y2=Py(y+1,z);
xs1=Px(x,z+1);ys1=Py(y,z+1);
xs2=Px(x+1,z+1);ys2=Py(y+1,z+1);
color(col);fd=0;
if( sgn(x2-x1)==sgn(cx-x2) ) /*  Right Wing */ 
{if ( !Gls(x+1,y,z) )
    {f=x2;fs=xs2;fd=1;
	if (xs2-x2>1)ftrap(1,y1,y2,x2+1,ys1,ys2,xs2); }}
else
if( sgn(x1-x2)==sgn(cx-x1) ) /* Left Wing */ 
{if ( !Gls(x-1,y,z) )
    {f=x1;fs=xs1;fd=1;
	if (x1-xs1>1)ftrap(1,y1,y2,x1-1,ys1,ys2,xs1);}}
if(fd){
color(0);plot(fs,ys1,1);line(f,y1,0);line(f,y2,0);line(fs,ys2,0);
if(z+1==Zd) color(Cglass);	line(fs,ys1,0);}

color(col);fd=0;
if( sgn(y1-y2)==sgn(cy-y1) ) /* Bottom Wing */ 
{if ( !Gls(x,y-1,z) )
    {f=y1;fs=ys1;fd=1;
	if (y1-ys1>1)ftrap(0,x1,x2,y1-1,xs1,xs2,ys1);}}
else
if( sgn(y2-y1)==sgn(cy-y2) ) /* Top Wing */
{if ( !Gls(x,y+1,z) )
    {f=y2;fs=ys2;fd=1;
	if (ys2-y2>1)ftrap(0,x1,x2,y2+1,xs1,xs2,ys2);}}
if(fd){
color(0);plot(xs1,fs,1);line(x1,f,0);line(x2,f,1);line(xs2,fs,0);
if(z+1==Zd) color(Cglass);	line(xs1,fs,0);}

}

fillroof(x,y,z) char x,y,z;
{
col=(Zd-1-z)%7+1;
x1=Px(x,z);y1=Py(y,z);
x2=Px(x+1,z);y2=Py(y+1,z);
if( !z || !Gls(x,y,z-1) )
{color(col);plot(x1+1,y1+1,1);line(x2-1,y2-1,BF);
if(x==0) col=Cglass; else col=0;
color(col);plot(x1,y1,1);line(x1,y2,0);
if(y+1==Yd) col=Cglass; else col=0;
color(col);line(x2,y2,0);
if(x+1==Xd) col=Cglass; else col=0;
color(col);line(x2,y1,0);
if(y==0) col=Cglass; else col=0;
color(col);line(x1,y1,0); }
}

ftrap(orn,x1l,x1r,y1,x2l,x2r,y2)
 int orn,x1l,x1r,y1,x2l,x2r,y2;
/* ����������� �������� 
 ( orn=1 )
 x1l,x1r - x-������� ��� ���������� y1,
 x2l,x2r - x-������� ��� ���������� y2,
 ( ��� orn=1 ��� x ���������� �� y ) */ 
{
int tl,tr,el,er,d,dxl,dxr,dy,ixl,ixr,iy;
/*if( (dy=y2-y1)==0 ) return;*/
dy=y2-y1;
ixl=ixr=iy=1;
dxl=x2l-x1l;dxr=x2r-x1r;
if (dxl<0) {ixl=-1,dxl=-dxl;}
if (dxr<0) {ixr=-1,dxr=-dxr;}
if (dy<0) {iy=-1,dy=-dy;}
d=dy<<1;tl=dxl<<1;tr=dxr<<1;el=er=-dy;
while(dy-->0){
  if(orn){ plot(y1,x1l,1);line(y1,x1r,0); }
    else { plot(x1l,y1,1);line(x1r,y1,0); }
  y1+=iy;el+=tl;er+=tr;
  while(el>=0){ x1l+=ixl;el-=d; }
  while(er>=0){ x1r+=ixr;er-=d; }
 }
}


fillgls()
{
int x,y,z;
for(z=Zd-1;z>=Zm;z--){
 for(x=0;x<Xd;x++) for(y=0;y<Yd;y++)
	if ( Gls(x,y,z) ) fillwing(x,y,z);
 for(x=0;x<Xd;x++) for(y=0;y<Yd;y++)
	if ( Gls(x,y,z) ) fillroof(x,y,z);
 }
}

fillfig()
{
char n;
int xf,yf,zf,zi,zs,xh,yh,xo,yo;
int xi,xs,yi,ys;
xh=(Xd-1)/2;yh=(Yd-1)/2;
xo=(Xd-1)%2;yo=(Yd-1)%2;
splan(Sglass);
yi=Yd;xi=Xd;zi=Zd;zs=ys=xs=0;
for(n=0;n<nblc;n+=3){
	xf=x+fblc[n]; yf=y+fblc[n+1]; zf=z+fblc[n+2];
	Gls(xf,yf,zf)=1;
	zs=max(zf,zs); zi=min(zf,zi);
	ys=max(yf,ys); yi=min(yf,yi);
	xs=max(xf,xs); xi=min(xf,xi);
}
Zm=min(zi,Zm);
if ( xh+xo<xi ) xi=xh+xo;	if( xh>xs ) xs=xh;
if ( yh+yo<yi ) yi=yh+yo;	if( yh>ys ) ys=yh;
for(zf=zs;zf>=Zm;zf--){
 for(xf=xi;xf<=xs;xf++) for(yf=yi;yf<=ys;yf++)
	if ( Gls(xf,yf,zf) ) fillwing(xf,yf,zf); 
 for(xf=xi;xf<=xs;xf++) for(yf=yi;yf<=ys;yf++)
	if ( Gls(xf,yf,zf) ) fillroof(xf,yf,zf); 
 }
CubPl+=nblc/3; cubout();
if (CubPl>=(Level+1)*(Xd+Yd)*15){ Level++; levelout(); }
Sqz();
}

Sqz()	/* ��������� ���� */
{
int xf,yf,zf,ff;
ff=0;
for(zf=Zm;zf<Zd;zf++){
 for(xf=0;xf<Xd;xf++)
 for(yf=0;yf<Yd;yf++)
  if ( !Gls(xf,yf,zf) ) goto NAL;
	 for(ff=1;zf>=Zm;zf--)	/* ���������� */
	 for(xf=0;xf<Xd;xf++) for(yf=0;yf<Yd;yf++)
	  Gls(xf,yf,zf)=(zf==Zm)?0:Gls(xf,yf,zf-1);
	 Zm++;Psloj++;
NAL:;
 }
if (!ff) return;
splan(Sglass);
cls();
drGlass();
fillgls();
}
