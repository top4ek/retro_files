/* Tetris 3d */
#include "tet3d.h"

main(){
puts("Tetris 3D, ��������� 1996, ������������ ������\n");
rsvstk(128);
pal=loadf("t3dpal.dat");
fig=loadf("t3dfg.dat");
dat=loadf("t3dintr.dat");
initDAT();
initSC();
joindrv();
scolor(Gpal);
Xd=Yd=5;Zd=10;Bset=0;Spd=0;Dif=0;
initstr();
for(;;){
 splan(Sglass);
 cls();
 showmenu();
 editmenu();
 progrm();
 }
}

char timekey()
{
char c;
do{ rand(); if( time()>=Tc ) return 0xFF;
  }while((c=inkey())==0xFF);
return c;
}

zerotime(t) int t; {settime(0); Tc=t;}

progrm()
{
int dx,dy,m;
/*-----------------------------------*/
initPxy();
Level=Spd;Score=CubPl=0;
cls(); drGlass(); clrGlass(); Zm=Zd;
if ( Dif ){ initDIF(); spektr(); fillgls(); }
NFIG:
initFIG(); x=y=z=1; Hdn=Psloj=0;
if ( !chkfig() ){ gameover(); return; }
zerotime(SpDel[Level]);
for(;;){
splan(Sfig);cls();figure();
NEXEC:
	m=dx=dy=0;
	switch(toupper(timekey())){
		case 25 : m=dy= 1; break;  /* Up */
		case 26 : m=dy=-1; break;  /* Down */
		case 8  : m=dx=-1; break;  /* Left */
		case 24 : m=dx= 1; break;  /* Right */
		case 0xFF:
			z++; if ( chkfig() ){zerotime(SpDel[Level]); continue;}
			z--; cls();
			fillfig();
			ScoreInc();
			spektr();
			goto NFIG;
		case 'J' : m=Rot(1,2,&y,&z,&Yd,&Zd,-1); break;
		case 'C' : m=Rot(2,0,&z,&x,&Zd,&Xd,-1); break;
		case 'U' : m=Rot(0,1,&x,&y,&Xd,&Yd,1); break;
		case 'F' : m=Rot(1,2,&y,&z,&Yd,&Zd,1); break;
		case 'Y' : m=Rot(2,0,&z,&x,&Zd,&Xd,1); break;
		case 'W' : m=Rot(0,1,&x,&y,&Xd,&Yd,-1); break;
		case ' ' : do{ z++; Hdn++; }while(chkfig());
				{ --z; --Hdn; zerotime(20); continue; }
		case 27 : return;
		default  : goto NEXEC;
	}
if(!m) goto NEXEC;
x+=dx;y+=dy;
if ( chkfig()==0 ){ x-=dx;y-=dy; goto NEXEC; }
}
}


ScoreInc()
{
unsigned Lv,Pr,Em,dSc,ZB;
Lv=(Level+1)*(Level+17);
ZB=ScZd[Zd]*(1<<Bset);
Pr=((Xd+Yd)*Lv*Psloj+150)/10*Psloj*(ZB/5)/4;
Em=(Zm==Zd)?(Lv/2)*((Xd+Yd)*ZB/31):0;
dSc=Lv*(ScFig[cfig]/5)*((Hdn*12+Zd)/Zd)/Zd;
Score+=((Pr+Em+dSc)>>1)+1;
scoreout();
}

gameover()
{
splan(Sglass);
color(4);cur(35,11);spic("Konec");
	 cur(35,12);spic("Igry");
waitkey();
}
