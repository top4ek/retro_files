#include "tet3d.h"

initFIG()
{
char *next;int n;char c;
NFIG:
cfig=rand()%nbst;	/* ��������� ������������� ������ */
switch(figbnd){
 case 2 : if ( cfig==8 || cfig>=37 ) goto NFIG; 
 case 1 : if ( cfig==40 ) goto NFIG; 
} 
next=pfig[cfig];
nver=*(next++)*3;
 for(n=0;n<nver;n+=3,next++){
 c=*next;
 fver[n]=(c&0x7)-1;	
 fver[n+1]=((c>>3)&0x7)-1;
 fver[n+2]=(c>>6)-1;
 }
ncvz=*(next++);
fcvz=next;
next+=ncvz;
nblc=*(next++)*3;
 for(n=0;n<nblc;n+=3,next++){
  c=*next;
  fblc[n]=(c&0x7)-1;
  fblc[n+1]=((c>>3)&0x7)-1;
  fblc[n+2]=(c>>6)-1;
 }
}

initDAT()
{
char *n;int i;
Gpal=pal;Fpal=pal+0x10;Bpal=pal+0x20;Dpal=pal+0x30;
pfig=alloc(41*2);
if (!pfig){ puts("No Mem:pfig"); exit(); }
for(n=fig,i=0;i<41;i++){
  pfig[i]=n; n+=(*n)+1; n+=(*n)+1; n+=(*n)+1;
  }
nfig=i;
fver=alloc(25*3);
fblc=alloc(5*3*2);
_Px=alloc((ZL+1)*(XL+1));
_Py=alloc((ZL+1)*(YL+1));
_Gls=alloc(ZL*XL*YL);
if (!_Gls) { puts("No Mem:Gls"); exit(); }
}

initSC()
{
char n;
n=*dat;	ScFig=++dat; dat+=n;
n=*dat; ScZd=(++dat)-6;  dat+=n;
n=*dat; SpDel=++dat;
}

decout(c)int c;
{char strm[10];sprintf(strm,"%2d",c);spic(strm);}

initPxy()
{
int dx,dy,dz,Dx,Dy,Dz;
int x,y,z,XX2,YY2,mx;
int XX,YY,Eye;
XX=190;YY=240;
cx=110;cy=128;
Eye=180;
mx=min(Xd,Yd);
 if ( mx>=5 ) figbnd=0;
  else{ if ( mx>=4 ) figbnd=1; else figbnd=2; }
switch(Bset){
 case 0 : nbst=9; break;
 case 1 : nbst=12; break;
 case 2 : nbst=41; break;
}
sprintf(Game,"%dh%dh%d",Xd,Yd,Zd);
mx=max(Xd,Yd);	XX=(XX/mx)*Xd;YY=(YY/mx)*Yd;
dy=YY/Yd;	dx=XX/Xd;	dz=dx;
XX2=XX/2;	YY2=YY/2;
for(z=0;z<=Zd;z++){
 Dz=Eye+dz*z;
 for(x=0;x<=Xd;x++){ Dx=Eye*(dx*x-XX2); Px(x,z)=cx+Dx/Dz; }
 for(y=0;y<=Yd;y++){ Dy=Eye*(dy*y-YY2); Py(y,z)=cy+Dy/Dz; }
 }
}

char *loadf(fname) char *fname;
  {
   int rl,rp;char *grf;
   if((rp=open(fname,0))==-1)
      {printf("Can't open file %s",fname);exit(1);}
   printf("Loading...%s\n",fname);
   rl=cfsize(rp);	  /* ������ ����� � �������� */  
   grf=alloc(rl*SECSIZ);
   if(grf==0){puts("No Mem:load");exit(1);}
   read(rp,grf,rl);
   close(rp);
   return grf;
  }

