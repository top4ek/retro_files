#include "tet3d.h"

#define LM  11
#define TM  8
#define SH  14

initstr()
{
its[0]=" Na~alo igry ";
its[1]=" [irina    : ";
its[2]=" Wysota    : ";
its[3]=" Glubina   : ";
its[4]=" Figury      ";
its[5]=" Temp      : ";
its[6]=" Ruiny     : ";
its[7]=" Wyhod       ";

bs[0]="Plita ";
bs[1]="Osnowa";
bs[2]="Strah ";
}

#define ICOL 3
#define DCOL 2

char waitkey(){char c;while((c=inkey())==0xFF);return c;}

showmenu()
{
int i,tx,ty;char n;
color(7);
plot(54,84,1);
line(192,182,BF);

for(i=0;i<ITS;i++){
	color(0x70|ICOL);
	cur(LM,i+TM);
	spic(its[i]);
	color(0x70|DCOL);
	cur(LM+SH,i+TM);
	showitem(i);
  }
}

showitem(n) int n;
{	switch(n){
	  case 1 : decout(Xd); break;
	  case 2 : decout(Yd); break;
	  case 3 : decout(Zd); break;
	  case 4 : spic(bs[Bset]); break;
	  case 5 : decout(Spd); break;
	  case 6 : decout(Dif); break;
	}
}

editmenu()
{
int n,nn;
n=nn=0;
for(;;){
color(0x70|ICOL); cur(LM,n+TM); spic(its[n]);
color(0x40|ICOL);cur(LM,nn+TM); spic(its[nn]);
n=nn;
NMOV:
cur(LM+SH,TM+n);
color(0x70|DCOL);
	switch(waitkey()){
	  case 0 :
	  case 24 :
	    switch(n){	/* -> */
		case 1 : if (Xd<XL) Xd++;	break;
		case 2 : if (Yd<YL) Yd++;	break;
		case 3 : if (Zd<ZL) Zd++;	break;
		case 4 : if (Bset<2)Bset++;	break;
		case 5 : if (Spd<9) Spd++;	break;
		case 6 : if (Dif<Zd-2) Dif++;	break;
	     }; showitem(n); goto NMOV;
	  case 8 :
	    switch(n){	/* <- */
		case 1 : if (Xd>3) Xd--;	break;
		case 2 : if (Yd>3) Yd--;	break;
		case 3 : if (Zd>6&&Dif+2<Zd) Zd--; break;
		case 4 : if (Bset>0) Bset--;	break;
		case 5 : if (Spd>0) Spd--;	break;
		case 6 : if (Dif>0) Dif--;	break;
	     }; showitem(n); goto NMOV;
/* UP */  case 25 : if (n>0) nn=n-1; else nn=ITS-1; break;
/* DOWN */case 26 : if (n<ITS-1) nn=n+1; else nn=0; break;
	  case 13 :  switch(n){
			 case 0     : return;
			 case ITS-1 : splan(Sglass); exitdos();
			}; goto NMOV;
	}
 }
}

