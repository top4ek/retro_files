enum LanguageID
{
	MOk,
	MCancel,
	MHotCancel,
	MHotAll,
	MHotExtract,
	MErrClose,
	MErrRetry,
	MDelete,
	MHotDelete,
	MHotSkip,
	MHotCopy,
	MErrorSmile,

	MConfigTitle,
	MCfgLine,
	MPluginLine,
	MErrorLine,
	MExtractTitle,
	MCopyOnImage,
	MMoveTitle,
	MMoveOnImage,
	MCommandTitle,
	MSelectImage,
	MCopyOneFile,
	MCopySeveralFiles,
	MMoveOneFile,
	MMoveSeveralFiles,
	MExtractAllFiles,

	MSelf,	
	MSaveRO,
	MDecodeLine,

	MWrongFormat,
	MReadError,

	MImgFormat,

	MEmpty,

	MNewImage,
	MAddImage,
	MChangeFormat,

	MNewFileNameTitle,
	MNewName,

	MNotSupportTitle,
	MCopyFileError,
	MCopyFolderError,
	MFileCreateError,
	MFileDeleteError,
	MFolderDeleteError,
	MFileError,

	MDelTitle,
	MDelFileTitle,
	MDelFolderTitle,
	MDelFile,
	MDelFolder,
	MFilesCount,
	MDelNow,
	MDelFolderTxt,

	MUserNumber,
	MOnSystemTrack,
	MFromSystemTrack,

	MPluginError,
	MDiskFull,
	MNoDirectoryEntry,

	MHowManyFiles,
	MWait,
	MImgReading
};
