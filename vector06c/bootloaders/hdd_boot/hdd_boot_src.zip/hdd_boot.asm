        .org    $0000
;
L0000:  dcx     b
        di
        nop
        ora     c
        mov     a,b
        jnz     L0000
        lxi     h,$07FF
        mov     b,l
L000C:  mov     a,m
        add     b
        mov     b,a
        dcx     h
        mov     a,h
        cpi     $FF
        jnz     L000C
        inr     b
L0017:  jnz     L0017
L001A:  mvi     a,$80
        out     $00
        xra     a
        out     $01
        in      $01
        ana     a
        jnz     L009C
        mvi     a,$88
        out     $00
        mvi     a,$80
        out     $04
        in      $01
        rlc
        jc      L0091
        jmp     L003C
;
        .ORG    38H
        RZ
        JMP     L001A
;
L003C:  add     a
        jm      L0052
L0040:  out     $05
        out     $05
        jnc     L0040
L0047:  in      $01
        ani     $20
        rrc
        rrc
        out     $01
        jmp     L0047
;
L0052:  push    d
        push    d
        jnc     L0052
        lxi     h,$1000
L005A:  mvi     m,$FF
        inx     h
        mov     a,h
        ora     l
        jnz     L005A
        mov     b,a
L0063:  lxi     h,$1000
L0066:  mov     a,b
        out     $07
        dcr     a
        cmp     m
        mov     m,b
        jnz     L0078
        inr     a
        cmp     m
        jz      L007E
        mvi     a,$08
        out     $01
L0078:  in      $01
        rlc
        jc      L0078
L007E:  inx     h
        mov     a,l
        out     $05
        ani     $01
        out     $01
        mov     a,h
        out     $06
        ora     h
        jnz     L0066
        inr     b
        jmp     L0063
;
L0091:  add     a
        jm      L00B4
L0095:  in      $01
        in      $01
        jnc     L0095
L009C:  dcr     b
        mov     a,b
        out     $05
        rlc
        ani     $01
        out     $01
        in      $05
        cmp     b
        jz      L009C
L00AB:  in      $01
        rrc
        jc      L00AB
        jmp     L009C
;
L00B4:  pop     d
        pop     d
        jnc     L00B4
        mvi     a,$9B
        out     $04
        lxi     sp,$DCF0
        mvi     a,$A8
        lxi     b,L0040
L00C5:  out     $08
        sub     c
        jnc     L00C5
        mov     c,b
        lxi     b,L0000
        xra     a
        out     $01
        out     $10
; ���⪠ ���
L00D4:  stax    b
        inx     b
        stax    b
        inx     b
        cmp     c
        jnz     L00D4
        cmp     b
        jnz     L00D4
        lxi     d,$0009
; ���ᮢ�� ����㧮筮� ⠡����
L00E3:  mov     h,b
        call    L0715
        dcr     l
        mvi     m,$FF
        dad     d
        mvi     m,$FF
        inr     l
        mvi     m,$81
        inr     b
        jnz     L00E3
; ��㭮�
        lxi     d,$C4E9
        mvi     b,$07
        call    L0740           ; � �⥪ ����� ���� ��㭪�
; ��㭮�
       .DB $08,$F3,$DB,$DB,$DB,$F3,$DB,$DB,$F3,$DB,$1B,$1B,$1A,$9C,$1A,$1B
       .DB $DB,$18,$18,$18,$18,$18,$18,$5A,$7E,$73,$DB,$DB,$DB,$DB,$DB,$DB
       .DB $73,$00,$01,$C1,$6D,$6D,$61,$61,$C0,$E3,$B6,$B6,$B6,$B7,$B6,$B6
       .DB $E3,$83,$DF,$D6,$D6,$96,$16,$D6,$96,$21,$96,1,$E5,$FB,$76,$F3,6,$F
;
L013E:  mov     a,b
        out     $02
        ani     $02
        mvi     a,$2D
        jnz     L014A
        mvi     a,$80
L014A:
        out     $0C
        xthl
        out     $0C
        xthl
        out     $0C
        dcr     e
        dcr     b
        out     $0C
        jp      L013E
        mvi     a,$8A
        out     $00
        mvi     a,$FD
        out     $03
        in      $02
        push    psw
        mvi     a,$88
        out     $00
        xra     a
        out     $02
        dcr     a
        out     $03
        pop     psw
        add     a
        jnc     L0193
        add     a
        jnc     L0190
        add     a
        jnc     L018D
        add     a
        jnc     L018A
        add     a
        add     a
        jnc     L033F
        call    L01AE
        jz      L01E5
L018A:  call    L02AB           ; ࠡ�� � ������஬
L018D:  call    L034E		; �஢�ઠ ������ ��᪮����
L0190:  call    L0530		; �஢�ઠ ������ �����
L0193:  jmp     L058A
; BOOTOK - ����㧪� �����襭�
        mvi     a,$9B
        out     $04
        mvi     a,$03
L019C:  out     $00
        xra     a
        ei
        hlt
        inr     e
        mov     a,e
        ani     $08
        mvi     a,$07
        jnz     L019C
        dcr     a
        jmp     L019C
;
L01AE:  lxi     h,$FF00
        shld    $DED5
        xra     a
        inr     a
        sta     $DED4
        call    L0230
        rnz
        lxi     h,$0100
        shld    $DED5
        lxi     h,$FF00
L01C6:  lxi     d,L01D9
        mvi     c,$0C
L01CB:  ldax    d
        cmp     m
        rnz
        inx     d
        inx     h
        dcr     c
        jnz     L01CB
        lxi     d,$0004
        dad     d
        ret
; ��� 䠩�� - OS.COM
L01D9:  .DB     $00,$4F,$53,$20,$20,$20,$20,$20,$20,$43,$4F,$4D
;
L01E5:  call    L073B
; ��㭮�
        .DB     $8C,$0F,$FF,$80,$92,$80,$92,$80,$92,$80,$92,$80,$FF,$F0,$FF
        .DB     $01,$49,$01,$49,$01,$49,$01,$49,$01,$FF
;
L0201:  mvi     c,$10
L0203:  mov     a,m
        ora     a
        jz      L0227
        sta     $DED3
        mvi     a,$01
L020D:  sta     $DED4
        push    psw
        call    L0230
        rst     7
        pop     psw
        inr     a
        cpi     $09
        jnz     L020D
        inx     h
        dcr     c
        jnz     L0203
        call    L01C6
        jz      L0201
L0227:  lhld    $DED5
        mov     d,h
        mvi     h,$01
        jmp     L0580
;
L0230:  push    h
        push    b
        lxi     h,L0000
        dad     sp
        shld    $DED0
        lda     $DED4
        lxi     d,$FF80
        lxi     h,$0400
L0242:  dad     d
        dcr     a
        jnz     L0242
        xchg
        lda     $DED3
        cma
        cpi     $FC
        jnc     L0253
        sui     $10
L0253:  sui     $04
        mov     l,a
        rlc
        rlc
        ani     $FC
        mov     h,a
        mov     a,l
        mvi     l,$00
        dad     d
        sphl
        rlc
        rlc
        rlc
        rlc
        ani     $0C
        mov     c,a
        mvi     a,$10
        ora     c
        out     $10
        lhld    $DED5
        xra     a
        mvi     c,$40
L0272:  pop     d
        add     e
        add     d
        mov     m,e
        inx     h
        mov     m,d
        inx     h
        dcr     c
        jnz     L0272
        shld    $DED5
        mov     c,a
        lda     $DED3
        mov     l,a
        mvi     h,$00
        dad     h
        dad     h
        dad     h
        dad     h
        mvi     a,$F0
        add     h
        mov     h,a
        lda     $DED4
        dcr     a
        add     a
        add     l
        mov     l,a
        sphl
        mvi     a,$1C
        out     $10
        sphl
        pop     d
        xra     a
        out     $10
        lhld    $DED0
        sphl
        mov     a,c
        pop     b
        pop     h
        cmp     d
        rnz
        cmp     e
        ret
;---------------------------------------------------------------------- HDD -
; ࠡ�� � ������஬
L02AB:  out     $5F
        mvi     b,$FF
L02AF:  dcx     b
        mov     a,b
        ora     c
        rz
        in      $57
        cpi     $50
        jnz     L02AF
        pop     h
lllll:  call    L0730
; ��㭮� �������
        adc     c
        lxi     b,$01FF
        rst     7
        lxi     b,$01FF
        rst     7
        lxi     b,$FF80
        add     b
        rst     7
        add     b
        rst     7
        add     b
        rst     7
        add     b

        mvi     a,$01
        mvi     d,$E0
        call    L02E6
        call    L0325
        lda     $E404
        mvi     d,$0D
        call    L02E6
        jmp     L03DA
;
L02E6:  inr     a
        add     a
        mov     c,a
        mvi     e,$00
        mov     h,e
L02EC:  mvi     l,$00
L02EE:  inr     l
        mov     a,l
        out     $53
        mov     a,h
        out     $56
        xra     a
        out     $54
        out     $55
        inr     a
        out     $52
        mvi     a,$20
        out     $57
        push    h
        mvi     h,$58
        call    L0327
        pop     h
        mvi     b,$00
L030A:  in      $50
        stax    d
        inx     d
        in      $58
        stax    d
        inx     d
        dcr     b
        jnz     L030A
        dcr     c
        jz      L0325
        lda     $E080
        cmp     l
        jnz     L02EE
        inr     h
        jmp     L02EC
;
L0325:  mvi     h,$50
L0327:  push    b
        mvi     b,$20
L032A:  in      $57
        ani     $D9
        cmp     h
        jz      L033D
        dcr     l
        jnz     L032A
        dcx     b
        mov     a,b
        ora     c
        jnz     L032A
        rst     0
L033D:  pop     b
        ret
;---------------------------------------------------------------------- HDD -
;
L033F:  mvi     a,$1C
        sta     $DED1
        out     $1E
        mvi     a,$0B
        call    L04DA
        jmp     L035A
;
L034E:  mvi     a,$0B
        out     $19
        mov     c,a
        xthl
        xthl
        in      $19
        cmp     c
        rnz
        pop     psw
L035A:  call    L0730
; ��㭮�
        adc     d
        rst     7
        cpi     $FE
        rst     7
        cm      $FFFC                   ; ????
        add     c
        add     c
        rst     7
        rst     7
        mov     a,a
        mov     a,a
        rst     7
        cmc
        cmc
        rst     7
        cpi     $FF
        rst     7
        call    L0505
        mvi     a,$03
        call    L04DA
        call    L04D8
        call    L04D8
        mvi     a,$03
        call    L04DA
        lxi     d,$1100
        push    d
        call    L040C
        lxi     h,$111F
        mvi     a,$66
        sub     m
        dcr     l
L0393:  add     m
        dcr     l
        jnz     L0393
        add     m
        rst     7
        pop     d
L039B:  mvi     l,$05
L039D:  push    d
        call    L040C
        jz      L03AA
        pop     d
        dcr     l
        jnz     L039D
        rst     0
L03AA:  pop     psw
        lxi     h,$1104
        dcr     m
        jz      L03DA
        lxi     h,$DED3
        inr     m
        lda     $110C
        sub     m
        jnz     L039B
        mov     m,a
        lxi     h,$DED0
        mov     a,m
        xri     $FC
        mov     m,a
        jnz     L039B
        call    L04D8
        lda     $110E
        cpi     $28
        cz      L04D8
        lxi     h,$DED2
        inr     m
        jmp     L039B
; ��७�� ������ (��� ��᪮���� � �������)
L03DA:  lxi     b,$1180
        lhld    $1100
        xchg
        mov     a,e
        sub     c
        mov     a,d
        sbb     b
        xchg
        jnc     L03F7
L03E9:  ldax    b
        call    L0700
        inx     b
        inx     h
        mov     a,e
        sub     c
        mov     a,d
        sbb     b
        rc
        jmp     L03E9
;
L03F7:  dad     d
        mov     a,l
        sub     c
        mov     l,a
        mov     a,h
        sbb     b
        mov     h,a
L03FE:  ldax    d
        call    L0700
        mov     a,e
        sub     c
        mov     a,d
        sbb     b
        rc
        dcx     d
        dcx     h
        jmp     L03FE
; ��᪮���
L040C:  call    L0505
        inx     h
        mov     a,m
        ana     a
        inx     h
        mov     a,m
        inx     h
        jnz     L0478
        out     $1A
        mov     a,m
        inr     a
        out     $19
        mvi     a,$84
        mvi     h,$02
        out     $1B
L0424:  in      $1B
        rrc
        jnc     L0424
        lda     $110A
        dcr     a
        jz      L045F
        dcr     a
        jz      L0451
L0435:  in      $1B
        ana     h
        jz      L0435
        in      $18
        stax    d
        inr     e
        jnz     L0435
        inr     d
L0443:  in      $1B
        ana     h
        jz      L0443
        in      $18
        stax    d
        inr     e
        jnz     L0443
        inr     d
L0451:  in      $1B
        ana     h
        jz      L0451
        in      $18
        stax    d
        inr     e
        jnz     L0451
        inr     d
L045F:  in      $1B
        ana     h
        jz      L045F
        in      $18
        stax    d
        inr     e
        jnz     L045F
        inr     d
L046D:  in      $1B
        rrc
        jc      L046D
        in      $1B
        ani     $5C
        ret
; ��᪮���
L0478:  out     $DE
        mov     a,m
        inr     a
        out     $BE
        mvi     a,$84
        mvi     h,$02
        out     $FE
L0484:  in      $FE
        rrc
        jnc     L0484
        lda     $110A
        dcr     a
        jz      L04BF
        dcr     a
        jz      L04B1
L0495:  in      $FE
        ana     h
        jz      L0495
        in      $9E
        stax    d
        inr     e
        jnz     L0495
        inr     d
L04A3:  in      $FE
        ana     h
        jz      L04A3
        in      $9E
        stax    d
        inr     e
        jnz     L04A3
        inr     d
L04B1:  in      $FE
        ana     h
        jz      L04B1
        in      $9E
        stax    d
        inr     e
        jnz     L04B1
        inr     d
L04BF:  in      $FE
        ana     h
        jz      L04BF
        in      $9E
        stax    d
        inr     e
        jnz     L04BF
        inr     d
L04CD:  in      $FE
        rrc
        jc      L04CD
        in      $FE
        ani     $5C
        ret
;
L04D8:  mvi     a,$5B
L04DA:  lxi     h,$DED1
        inr     m
        dcr     m
        dcx     h
        jnz     L04F6
        out     $1B
        xra     a
L04E6:  dcr     a
        jnz     L04E6
L04EA:  mov     a,m
        adi     $34
        out     $1C
        in      $1B
        rrc
        jc      L04EA
        ret
;
L04F6:  out     $FE
        xra     a
L04F9:  dcr     a
        jnz     L04F9
L04FD:  call    L0522
        rrc
        jc      L04FD
        ret
;
L0505:  lxi     h,$DED1
        inr     m
        dcr     m
        dcx     h
        jnz     L051A
L050E:  mov     a,m
        adi     $34
        out     $1C
        in      $1B
        rlc
        rnc
        jmp     L050E
;
L051A:  call    L0522
        rlc
        rnc
        jmp     L051A
;
L0522:  mov     a,m
        ana     a
        mvi     a,$1C
        jz      L052B
        mvi     a,$0C
L052B:  out     $1E
        in      $FE
        ret
;---------------------------------------------------------------------------
; �஢�ઠ ������ �����
L0530:  mvi     a,$82
        out     $04
        mvi     h,$1F
L0536:  mov     a,h
        sui     $20
        rp
        mov     h,a
        out     $05
        mvi     a,$FE
        out     $07
        in      $06
        cpi     $55
        jnz     L0536
        mvi     a,$FF
        out     $07
        in      $06
        cpi     $AA
        jnz     L0536
        mvi     d,$81
        dad     d
        xthl
        call    L0730
; ��㭮� �����
        add     a
        mov     d,l
        rst     7
        rnz
        rst     0
        rnz
        rst     7
        mov     d,l
        mov     d,h
        rst     7
        inx     b
        adi     $03
        rst     7
        mov     d,h
        pop     d
;---------------------------------------------------------------------------
; ����㧪� �� �����
        lxi     h,$8000
        mov     b,l
        mov     c,l
L056F:  mov     a,l
        out     $07
        mov     a,h
        out     $05
        in      $06
        stax    d
        inx     h
        inx     b
        mov     a,b
        cmp     d
        jnz     L056F
        mov     h,c
; �뢮� ������ ��᫥ ����㧪� �� �����
L0580:  call    L0704          ;�뢮� �����
        inr     h
        mov     a,h
        cmp     d
        jnz     L0580
        ret
;---------------------------------------------------------------------------
;
L058A:  call    L0730
; ��㭮�
        dcr     c
        cmc
        xra     e
        cmp     a
        rnz
        rst     7
        rst     5
        cnz     $FFEC                   ; ???
        rst     7
        add     b
        rnz
        mov     a,a
        cm      $FDD5                   ; ???
        inx     b
        rst     7
        rst     6
        inx     h
        stc
        rst     7
        rst     7
;
        lxi     b,$FE03
        mvi     a,$11
        sta     $DEF6
        call    L0649
L05B0:  mov     d,a
        ora     a
        rar
        mov     e,a
        add     d
        mov     h,a
        call    L0649
        cmp     h
        jc      L05B0
        add     d
        sta     $DEF6
        mvi     e,$0C
L05C3:  mvi     a,$08
        call    L06B7
        cpi     $55
        jz      L05D2
        cpi     $AA
        jnz     L058A
L05D2:  dcr     e
        jnz     L05C3
L05D6:  call    L0693
        mov     e,a
        mov     a,m
        ana     a
        jnz     L05D6
        lxi     h,$DEF1
        mov     a,m
        dcx     h
        cmp     m
        jnz     L058A
        mov     d,a
        dcx     h
        mov     b,m
L05EB:  call    L0693
        push    psw
        mov     a,m
        ana     a
        jz      L0627
        add     a
        add     a
        add     a
        add     a
        add     a
        mov     c,a
        pop     psw
        inx     h
        mov     a,m
        cmp     e
        jnz     L05EB
        push    d
        push    b
        inx     h
        lxi     d,$207E
L0607:  mov     a,m
        stax    b
        ldax    b
        xra     m
        mov     m,a
        inx     h
        inr     c
        dcr     d
        jnz     L0607
        pop     b
        mov     l,c
        mov     h,b
        call    L0717
        mov     m,e
        pop     d
        call    L063A
        jz      L05EB
        mov     a,d
        cpi     $01
        jnz     L05EB
        ret
;
L0627:  pop     psw
        sub     e
        jz      L05EB
        inr     a
        rst     7
        call    L063A
        jz      L001A
        dcr     e
        inr     b
        dcr     d
        jmp     L05EB
;
L063A:  mov     h,b
        call    L0715
L063E:  mov     a,m
        ana     a
        rz
        inx     h
        cpi     $81
        jnz     L063E
        ana     a
        ret
;
L0649:  push    h
        push    d
L064B:  call    L0674
        mov     b,a
        ora     a
        rar
        mov     c,a
        lxi     h,L0000
        mvi     d,$20
L0657:  call    L0674
        push    d
        mvi     d,$00
        mov     e,a
        dad     d
        pop     d
        mov     e,a
        sub     b
        jnc     L0667
        mov     a,b
        sub     e
L0667:  cmp     c
        jnc     L064B
        dcr     d
        jnz     L0657
        dad     h
        mov     a,h
        pop     d
        pop     h
        ret
;
L0674:  push    d
        in      $01
        ani     $10
        mov     e,a
L067A:  in      $01
        ani     $10
        cmp     e
        jz      L067A
        mov     e,a
        mvi     d,$01
L0685:  in      $01
        ani     $10
        inr     d
        cmp     e
        jz      L0685
        mov     a,d
        add     a
        add     a
        pop     d
        ret
;
L0693:  push    b
        push    d
        lxi     h,$DED0
L0698:  push    h
        lxi     b,$0023
        mvi     a,$FF
L069E:  call    L06B7
        mov     m,a
        inx     h
        add     b
        mov     b,a
        mvi     a,$08
        dcr     c
        jnz     L069E
        dcx     h
        mov     a,b
        sub     m
        sub     m
        mov     a,m
        pop     h
        jnz     L0698
        pop     d
        pop     b
        ret
;
L06B7:  push    b
        push    d
        mvi     c,$00
        mov     d,a
L06BC:  in      $01
        ani     $10
        mov     e,a
L06C1:  in      $01
        ani     $10
        cmp     e
        jz      L06C1
        rlc
        rlc
        rlc
        rlc
        mov     a,c
        ral
        mov     c,a
        lda     $DEF6
L06D3:  dcr     a
        jnz     L06D3
        mov     a,d
        ora     a
        jp      L06F5
        mov     a,c
        cpi     $E6
        jnz     L06E9
        xra     a
        sta     $DEF4
        jmp     L06F3
;
L06E9:  cpi     $19
        jnz     L06BC
        mvi     a,$FF
        sta     $DEF4
L06F3:  mvi     d,$09
L06F5:  dcr     d
        jnz     L06BC
        lda     $DEF4
        xra     c
        pop     d
        pop     b
        ret
; ����ᥭ�� ���� �� ����� � ���ᮢ�� �����, �᫨ ���� �����
L0700:  mov     m,a
        mov     a,l
        ana     a
        rnz
; ���ᮢ�� ������ ����� � ⠡���
L0704:  push    h
        push    b
        call    L0715
        mvi     c,$08
L070B:  mvi     m,$7E
        inr     l
        dcr     c
        jnz     L070B
        pop     b
        pop     h
        ret
; ���᫥��� ���� � ⠡��� �� ॠ�쭮�� �����
L0715:  mvi     l,$00
L0717:  push    d
        mov     a,l
        rlc
        rlc
        rlc
        mov     l,a
        mov     a,h
        rar
        ani     $70
        mov     d,a
        rar
        add     d
        add     l
        adi     $18
        mov     l,a
        mov     a,h
        ani     $1F
        adi     $C0
        mov     h,a
        pop     d
        ret
;
L0730:  push    h
        lxi     h,$DED0
L0734:  mvi     m,$00
        inr     l
        jnz     L0734
        pop     h
L073B:  mvi     b,$02
        lxi     d,$D8E2
L0740:  xthl
        mov     a,m
        inx     h
        sta     $DCF7
L0746:  lda     $DCF7
        ani     $7F
        mov     c,a
        push    d
L074D:  mov     a,m
        stax    d
        inx     d
        lda     $DCF7
        ora     a
        jp      L075A
        mov     a,m
        stax    d
        inx     d
L075A:  inx     h
        dcr     c
        jnz     L074D
        pop     d
        inr     d
        dcr     b
        jnz     L0746
        xthl
        ret
        .END
