START:       MVI    A,9B
000002       OUT    04
000004       MVI    A,88
000006       OUT    00
000008       LXI    SP,DCF0
00000B       LXI    D,55AA
00000E       PUSH   D
00000F       POP    H
000010       MOV    A,L
000011       CMA
000012       CMP    H
000013       JNZ    000E
000016       MVI    A,A8
000018       LXI    B,0040
00001B       OUT    08
00001D       SUB    C
00001E       JNC    001B
000021       MOV    C,B
000022       MVI    A,06
000024       OUT    00
000026       XRA    A
000027       OUT    10
000029       STAX   B
00002A       INX    B
00002B       STAX   B
00002C       INX    B
00002D       CMP    C
00002E       JNZ    0029
000031       CMP    B
000032       JNZ    0029
000035       JMP    0039
000038       RET
000039       LXI    D,0009
00003C       MOV    H,B
00003D       MOV    L,D
00003E       CALL   0545
000041       DCR    L
000042       MVI    M,FF
000044       DAD    D
000045       MVI    M,FF
000047       INR    L
000048       MVI    M,81
00004A       INR    B
00004B       JNZ    003C
00004E       EI
00004F       HLT
000050       CALL   02A1
000053       LXI    H,0760
000056       LXI    D,C4E9
000059       MVI    A,08
00005B       MVI    B,07
00005D       CALL   06B7
000060       LXI    H,009F
000063       PUSH   H
000064       MVI    A,C3
000066       STA    DCF1
000069       STA    DCF4
00006C       JMP    06DA
00006F       CPI    F7
000071       JZ     044B
000074       CPI    EF
000076       JZ     0090
000079       CPI    E7
00007B       JZ     0084
00007E       CALL   055E
000081       JNZ    059D
000084       CALL   00D9
000087       JNZ    0148
00008A       CALL   0138
00008D       JNZ    02E7
000090       CALL   00D9
000093       JNZ    044B
000096       CALL   0107
000099       JNZ    0274
00009C       JMP    044B
00009F       MVI    A,9B
0000A1       OUT    04
0000A3       MVI    A,03
0000A5       OUT    00
0000A7       EI
0000A8       HLT
0000A9       CALL   02A1
0000AC       LDA    DEF7
0000AF       CPI    D7
0000B1       JNZ    00CA
0000B4       LXI    H,06DA
0000B7       LXI    D,C0DA
0000BA       MVI    A,0F
0000BC       MVI    B,02
0000BE       CALL   06B7
0000C1       MVI    E,DD
0000C3       MVI    A,08
0000C5       MVI    B,0D
0000C7       CALL   06B7
0000CA       INX    B
0000CB       MOV    A,C
0000CC       ANI    08
0000CE       MVI    A,07
0000D0       JNZ    00D4
0000D3       DCR    A
0000D4       OUT    00
0000D6       JMP    00A7
0000D9       MVI    B,04
0000DB       IN     07
0000DD       ORI    E0
0000DF       MOV    C,A
0000E0       MVI    A,8B
0000E2       OUT    04
0000E4       MOV    A,C
0000E5       OUT    07
0000E7       XTHL
0000E8       XTHL
0000E9       IN     05
0000EB       ANI    08
0000ED       JZ     0102
0000F0       MVI    A,7F
0000F2       ANA    C
0000F3       OUT    07
0000F5       IN     05
0000F7       CMA
0000F8       ANI    08
0000FA       JZ     0102
0000FD       DCR    B
0000FE       JNZ    00E4
000101       ORA    A
000102       MVI    A,9B
000104       OUT    04
000106       RET
000107       MVI    A,82
000109       OUT    04
00010B       MVI    B,FF
00010D       MOV    A,B
00010E       OUT    05
000110       MVI    A,FE
000112       OUT    07
000114       IN     06
000116       CPI    55
000118       JNZ    012E
00011B       MVI    A,FF
00011D       OUT    07
00011F       IN     06
000121       CPI    AA
000123       JNZ    012E
000126       MOV    A,B
000127       ANI    7F
000129       INR    A
00012A       MOV    D,A
00012B       JMP    0136
00012E       MOV    A,B
00012F       SUI    20
000131       MOV    B,A
000132       JM     010D
000135       XRA    A
000136       ORA    A
000137       RET
000138       MVI    A,0B
00013A       OUT    19
00013C       MOV    C,A
00013D       XTHL
00013E       XTHL
00013F       IN     19
000141       CMP    C
000142       JZ     0146
000145       XRA    A
000146       ORA    A
000147       RET
000148       LXI    H,07EC
00014B       MVI    A,8A
00014D       CALL   06B2
000150       LXI    H,021F
000153       SHLD   DCF2
000156       LXI    H,015C
000159       SHLD   DCF5
00015C       MVI    A,9B
00015E       OUT    04
000160       IN     07
000162       ANI    1F
000164       MOV    C,A
000165       MVI    B,0A
000167       IN     05
000169       ANI    70
00016B       CPI    40
00016D       JNZ    015C
000170       IN     06
000172       ANI    1F
000174       CMP    C
000175       JNZ    015C
000178       DCR    B
000179       JNZ    0167
00017C       IN     06
00017E       MOV    B,A
00017F       MVI    A,98
000181       OUT    04
000183       MOV    A,C
000184       OUT    06
000186       XRA    A
000187       OUT    05
000189       MVI    D,FA
00018B       DCR    D
00018C       JZ     015C
00018F       IN     05
000191       ANI    70
000193       CPI    70
000195       JNZ    018B
000198       MVI    A,9B
00019A       OUT    04
00019C       MOV    A,B
00019D       ANI    E0
00019F       JNZ    015C
0001A2       MVI    E,03
0001A4       MVI    A,08
0001A6       CALL   DCF1
0001A9       CPI    55
0001AB       JZ     01B3
0001AE       CPI    AA
0001B0       JNZ    DCF4
0001B3       DCR    E
0001B4       JNZ    01A4
0001B7       CALL   04D8
0001BA       MOV    E,A
0001BB       MOV    A,M
0001BC       CPI    00
0001BE       JNZ    01B7
0001C1       LXI    H,DEF1
0001C4       MOV    A,M
0001C5       DCX    H
0001C6       CMP    M
0001C7       JNZ    DCF4
0001CA       MOV    D,A
0001CB       DCX    H
0001CC       MOV    B,M
0001CD       CALL   04D8
0001D0       PUSH   PSW
0001D1       MOV    A,M
0001D2       CPI    00
0001D4       JZ     020A
0001D7       ADD    A
0001D8       ADD    A
0001D9       ADD    A
0001DA       ADD    A
0001DB       ADD    A
0001DC       MOV    C,A
0001DD       POP    PSW
0001DE       INX    H
0001DF       MOV    A,M
0001E0       CMP    E
0001E1       JNZ    01CD
0001E4       PUSH   D
0001E5       PUSH   B
0001E6       INX    H
0001E7       LXI    D,207E
0001EA       MOV    A,M
0001EB       STAX   B
0001EC       LDAX   B
0001ED       XRA    M
0001EE       MOV    M,A
0001EF       INX    H
0001F0       INR    C
0001F1       DCR    D
0001F2       JNZ    01EA
0001F5       POP    B
0001F6       MOV    L,C
0001F7       MOV    H,B
0001F8       CALL   0545
0001FB       MOV    M,E
0001FC       POP    D
0001FD       CALL   047D
000200       JZ     01CD
000203       MOV    A,D
000204       CPI    01
000206       JNZ    01CD
000209       RET
00020A       POP    PSW
00020B       SUB    E
00020C       JZ     01CD
00020F       INR    A
000210       JNZ    0000
000213       CALL   047D
000216       JZ     0000
000219       DCR    E
00021A       INR    B
00021B       DCR    D
00021C       JMP    01CD
00021F       PUSH   D
000220       MVI    D,70
000222       CPI    FF
000224       CZ     0255
000227       CALL   022C
00022A       POP    D
00022B       RET
00022C       MVI    E,60
00022E       IN     05
000230       ANA    D
000231       CPI    40
000233       JZ     0000
000236       CMP    E
000237       JNZ    022E
00023A       IN     06
00023C       PUSH   PSW
00023D       MVI    A,9A
00023F       OUT    04
000241       XRA    A
000242       OUT    05
000244       DCR    E
000245       JZ     024F
000248       IN     05
00024A       ANA    D
00024B       CMP    D
00024C       JNZ    0244
00024F       MVI    A,9B
000251       OUT    04
000253       POP    PSW
000254       RET
000255       CALL   022C
000258       CPI    E6
00025A       JNZ    0255
00025D       RET
00025E       MOV    M,H
00025F       MOV    H,L
000260       MOV    L,L
000261       MOV    L,C
000262       MOV    M,D
000263       MOV    H,C
000264       MOV    A,D
000265       MOV    L,A
000266       MOV    M,A
000267       2E64
00026A       MOV    M,E
00026B       MOV    L,A
00026C       MOV    L,E
00026D       MOV    L,A
00026E       MOV    L,H
00026F       MOV    L,A
000270       MOV    M,A
000271       2E61
000274       LXI    H,07DE
000277       MVI    A,87
000279       PUSH   D
00027A       CALL   06B2
00027D       POP    D
00027E       LXI    B,0000
000281       LXI    H,8000
000284       MOV    A,L
000285       OUT    07
000287       MOV    A,H
000288       OUT    05
00028A       IN     06
00028C       STAX   B
00028D       INX    H
00028E       INX    B
00028F       MOV    A,B
000290       CMP    D
000291       JNZ    0284
000294       LXI    H,0000
000297       CALL   03B5
00029A       INR    H
00029B       MOV    A,H
00029C       CMP    D
00029D       JNZ    0297
0002A0       RET
0002A1       LXI    H,02D7
0002A4       PUSH   PSW
0002A5       PUSH   B
0002A6       PUSH   H
0002A7       MVI    B,0F
0002A9       MOV    A,B
0002AA       OUT    02
0002AC       MOV    A,M
0002AD       OUT    0C
0002AF       INR    E
0002B0       OUT    0C
0002B2       INX    H
0002B3       OUT    0C
0002B5       DCR    E
0002B6       DCR    B
0002B7       OUT    0C
0002B9       JP     02A9
0002BC       MVI    A,8A
0002BE       OUT    00
0002C0       MVI    A,FD
0002C2       OUT    03
0002C4       IN     02
0002C6       STA    DEF7
0002C9       MVI    A,88
0002CB       OUT    00
0002CD       XRA    A
0002CE       OUT    02
0002D0       DCR    A
0002D1       OUT    03
0002D3       POP    H
0002D4       POP    B
0002D5       POP    PSW
0002D6       RET
0002D7       DCR    L
0002D8       DCR    L
0002D9       ADD    B
0002DA       ADD    B
0002DB       DCR    L
0002DC       DCR    L
0002DD       ADD    B
0002DE       ADD    B
0002DF       DCR    L
0002E0       DCR    L
0002E1       ADD    B
0002E2       ADD    B
0002E3       DCR    L
0002E4       DCR    L
0002E5       ADD    B
0002E6       ADD    B
; ࠡ�� � ��᪮�����
M02E7H:      MVI    A,C3
             STA    0000
             LXI    H,0100H
             SHLD   0001H
             LXI    H,07CAH
             MVI    A,8AH
             CALL   M06B2H      ;��㭮�
             MVI    A,34H
             STA    0DED0H
             CALL   M03A7H
             XRA    A
             OUT    1BH
             CALL   M039BH
             MVI    C,01
             LXI    H,0DFE0H
             CALL   M0374H
             JNZ    START
             LXI    H,0DFE0H
             LXI    D,0DEF1H
             MVI    C,1FH
             MVI    A,66H
M031DH:      ADD    M
             MOV    B,A
             MOV    A,M
             STAX   D
             INX    H
             DCX    D
             DCR    C
             MOV    A,B
             JNZ    M031DH
             SUB    M
             JNZ    START
             STAX   D
             LDA    0DFE4H
             MOV    B,A
             LXI    H,0080H
M0334H:      MVI    C,01
M0336H:      CALL   M0374H
             JNZ    START
             DCR    B
             JZ     M0362H
             INR    C
             MVI    A,06
             CMP    C
             JNZ    M0336H
             LDA    0DED0H
             XRI    04
             STA    0DED0H
             CALL   M03A7H
             MOV    A,D
             ANI    04
             JZ     M0334H
             MVI    A,58H
             OUT    1BH
             CALL   M039BH
             JMP    M0334H
M0362H:      LXI    H,0100H
             LDA    0DFE4H
             RLC
             RLC
             MOV    B,A
M036BH:      CALL   M03B5H
             INR    H
             DCR    B
             JNZ    M036BH
             RET
;----------
M0374H:      CALL   M039BH
             MOV    A,C
             OUT    19H
             LXI    D,0103H
             MVI    A,80H
             OUT    1BH
M0381H:      IN     1BH
             RRC
             JNC    M0381H
M0387H:      IN     1BH
             ANA    E
             SUB    D
             JZ     M0387H
             IN     18H
             MOV    M,A
             INX    H
             JP     M0387H
             DCX    H
             IN     1BH
             ANI    9CH
             RET
;---------
M039BH:      LDA    0DED0H
             OUT    1CH
             IN     1BH
             RRC
             JC     M039BH
             RET
;---------
M03A7H:      MOV    D,A
M03A8H:      OUT    1CH
             IN     1BH
             RLC
             MOV    A,D
             JC     M03A8H
             RET
;---------
0003B2       NOP
0003B3       NOP
0003B4       NOP
; �뢮� �����
M03B5H:      PUSH   H
0003B6       PUSH   B
0003B7       CALL   0545
0003BA       MVI    C,08
0003BC       MVI    M,7E
0003BE       INR    L
0003BF       DCR    C
0003C0       JNZ    03BC
0003C3       POP    B
0003C4       POP    H
0003C5       RET
0003C6       NOP
0003C7       NOP
0003C8       NOP
0003C9       NOP
0003CA       NOP
0003CB       NOP
0003CC       NOP
0003CD       NOP
0003CE       NOP
0003CF       NOP
0003D0       NOP
0003D1       NOP
0003D2       NOP
0003D3       NOP
0003D4       NOP
0003D5       NOP
0003D6       NOP
0003D7       NOP
0003D8       NOP
0003D9       NOP
0003DA       NOP
0003DB       NOP
0003DC       NOP
0003DD       NOP
0003DE       NOP
0003DF       NOP
0003E0       NOP
0003E1       NOP
0003E2       NOP
0003E3       NOP
0003E4       NOP
0003E5       NOP
0003E6       NOP
0003E7       NOP
0003E8       NOP
0003E9       NOP
0003EA       NOP
0003EB       NOP
0003EC       NOP
0003ED       NOP
0003EE       NOP
0003EF       NOP
0003F0       NOP
0003F1       NOP
0003F2       NOP
0003F3       NOP
0003F4       NOP
0003F5       NOP
0003F6       NOP
0003F7       NOP
0003F8       NOP
0003F9       NOP
0003FA       NOP
0003FB       NOP
0003FC       NOP
0003FD       NOP
0003FE       NOP
0003FF       NOP
000400       NOP
000401       NOP
000402       NOP
000403       NOP
000404       NOP
000405       NOP
000406       NOP
000407       NOP
000408       NOP
000409       NOP
00040A       NOP
00040B       NOP
00040C       NOP
00040D       NOP
00040E       NOP
00040F       NOP
000410       NOP
000411       NOP
000412       NOP
000413       NOP
000414       NOP
000415       NOP
000416       NOP
000417       NOP
000418       NOP
000419       NOP
00041A       NOP
00041B       NOP
00041C       NOP
00041D       NOP
00041E       NOP
00041F       NOP
000420       NOP
000421       NOP
000422       NOP
000423       NOP
000424       NOP
000425       NOP
000426       NOP
000427       NOP
000428       NOP
000429       NOP
00042A       NOP
00042B       NOP
00042C       NOP
00042D       NOP
00042E       NOP
00042F       NOP
000430       NOP
000431       NOP
000432       NOP
000433       NOP
000434       NOP
000435       NOP
000436       NOP
000437       NOP
000438       NOP
000439       NOP
00043A       NOP
00043B       NOP
00043C       NOP
00043D       NOP
00043E       NOP
00043F       NOP
000440       NOP
000441       NOP
000442       NOP
000443       NOP
000444       NOP
000445       NOP
000446       NOP
000447       NOP
000448       NOP
000449       NOP
00044A       NOP
00044B       LXI    H,0798
00044E       MVI    A,0D
000450       CALL   06B2
000453       MVI    A,11
000455       STA    DEF6
000458       LXI    H,04FC
00045B       SHLD   DCF2
00045E       LXI    H,044B
000461       SHLD   DCF5
000464       CALL   04AD
000467       MOV    D,A
000468       ORA    A
000469       RAR
00046A       MOV    E,A
00046B       ADD    D
00046C       MOV    H,A
00046D       CALL   04AD
000470       CMP    H
000471       JC     0467
000474       ADD    D
000475       STA    DEF6
000478       MVI    E,0C
00047A       JMP    01A4
00047D       MVI    L,00
00047F       MOV    H,B
000480       CALL   0545
000483       MOV    A,M
000484       ANA    A
000485       RZ
000486       INX    H
000487       CPI    81
000489       JNZ    0483
00048C       ANA    A
00048D       RET
00048E       PUSH   D
00048F       IN     01
000491       ANI    10
000493       MOV    E,A
000494       IN     01
000496       ANI    10
000498       CMP    E
000499       JZ     0494
00049C       MOV    E,A
00049D       MVI    D,01
00049F       IN     01
0004A1       ANI    10
0004A3       INR    D
0004A4       CMP    E
0004A5       JZ     049F
0004A8       MOV    A,D
0004A9       ADD    A
0004AA       ADD    A
0004AB       POP    D
0004AC       RET
0004AD       PUSH   H
0004AE       PUSH   D
0004AF       CALL   048E
0004B2       MOV    B,A
0004B3       ORA    A
0004B4       RAR
0004B5       MOV    C,A
0004B6       LXI    H,0000
0004B9       MVI    D,20
0004BB       CALL   048E
0004BE       PUSH   D
0004BF       MVI    D,00
0004C1       MOV    E,A
0004C2       DAD    D
0004C3       POP    D
0004C4       MOV    E,A
0004C5       SUB    B
0004C6       JNC    04CB
0004C9       MOV    A,B
0004CA       SUB    E
0004CB       CMP    C
0004CC       JNC    04AF
0004CF       DCR    D
0004D0       JNZ    04BB
0004D3       DAD    H
0004D4       MOV    A,H
0004D5       POP    D
0004D6       POP    H
0004D7       RET
0004D8       PUSH   B
0004D9       PUSH   D
0004DA       LXI    H,DED0
0004DD       PUSH   H
0004DE       LXI    B,0023
0004E1       MVI    A,FF
0004E3       CALL   DCF1
0004E6       MOV    M,A
0004E7       INX    H
0004E8       ADD    B
0004E9       MOV    B,A
0004EA       MVI    A,08
0004EC       DCR    C
0004ED       JNZ    04E3
0004F0       DCX    H
0004F1       MOV    A,B
0004F2       SUB    M
0004F3       SUB    M
0004F4       MOV    A,M
0004F5       POP    H
0004F6       JNZ    04DD
0004F9       POP    D
0004FA       POP    B
0004FB       RET
0004FC       PUSH   B
0004FD       PUSH   D
0004FE       MVI    C,00
000500       MOV    D,A
000501       IN     01
000503       ANI    10
000505       MOV    E,A
000506       IN     01
000508       ANI    10
00050A       CMP    E
00050B       JZ     0506
00050E       RLC
00050F       RLC
000510       RLC
000511       RLC
000512       MOV    A,C
000513       RAL
000514       MOV    C,A
000515       LDA    DEF6
000518       DCR    A
000519       JNZ    0518
00051C       MOV    A,D
00051D       ORA    A
00051E       JP     053A
000521       MOV    A,C
000522       CPI    E6
000524       JNZ    052E
000527       XRA    A
000528       STA    DEF4
00052B       JMP    0538
00052E       CPI    19
000530       JNZ    0501
000533       MVI    A,FF
000535       STA    DEF4
000538       MVI    D,09
00053A       DCR    D
00053B       JNZ    0501
00053E       LDA    DEF4
000541       XRA    C
000542       POP    D
000543       POP    B
000544       RET
000545       PUSH   D
000546       MOV    A,L
000547       RLC
000548       RLC
000549       RLC
00054A       MOV    L,A
00054B       MOV    A,H
00054C       RAR
00054D       ANI    70
00054F       MOV    D,A
000550       RAR
000551       ADD    D
000552       ADD    L
000553       ADI    18
000555       MOV    L,A
000556       MOV    A,H
000557       ANI    1F
000559       ADI    C0
00055B       MOV    H,A
00055C       POP    D
00055D       RET
00055E       LXI    H,FF00
000561       SHLD   DED5
000564       XRA    A
000565       STA    DED2
000568       STA    DED3
00056B       INR    A
00056C       STA    DED4
00056F       CALL   0607
000572       MVI    A,00
000574       JNZ    058F
000577       LXI    H,FF00
00057A       PUSH   H
00057B       LXI    D,0591
00057E       MVI    C,0C
000580       LDAX   D
000581       CMP    M
000582       MVI    A,00
000584       JNZ    058E
000587       INX    D
000588       INX    H
000589       DCR    C
00058A       JNZ    0580
00058D       DCR    A
00058E       POP    H
00058F       ORA    A
000590       RET
000591       NOP
000592       MOV    C,A
000593       MOV    D,E
000594       2020
000597       2020
00059A       MOV    B,E
00059B       MOV    C,A
00059C       MOV    C,L
00059D       LXI    H,07B2
0005A0       MVI    A,8C
0005A2       CALL   06B2
0005A5       LXI    H,0100
0005A8       SHLD   DED5
0005AB       MOV    B,H
0005AC       LXI    H,FF10
0005AF       MVI    C,10
0005B1       MOV    A,M
0005B2       ORA    A
0005B3       JZ     05D6
0005B6       CALL   05DD
0005B9       MOV    A,B
0005BA       ADI    04
0005BC       MOV    B,A
0005BD       LDA    DED2
0005C0       ORA    A
0005C1       JNZ    0000
0005C4       INX    H
0005C5       DCR    C
0005C6       JNZ    05B1
0005C9       CALL   057A
0005CC       JZ     05D6
0005CF       LXI    D,0010
0005D2       DAD    D
0005D3       JMP    05AF
0005D6       MOV    D,B
0005D7       LXI    H,0100
0005DA       JMP    0297
0005DD       PUSH   PSW
0005DE       PUSH   H
0005DF       STA    DED3
0005E2       MVI    A,01
0005E4       STA    DED4
0005E7       PUSH   PSW
0005E8       CALL   0607
0005EB       JZ     05F3
0005EE       MVI    A,FF
0005F0       STA    DED2
0005F3       POP    PSW
0005F4       LHLD   DED5
0005F7       LXI    D,0080
0005FA       DAD    D
0005FB       SHLD   DED5
0005FE       INR    A
0005FF       CPI    09
000601       JNZ    05E4
000604       POP    H
000605       POP    PSW
000606       RET
000607       PUSH   B
000608       PUSH   D
000609       LXI    H,0000
00060C       DAD    SP
00060D       SHLD   DED0
000610       CALL   0641
000613       DI
000614       OUT    10
000616       SPHL
000617       LHLD   DED5
00061A       MVI    A,00
00061C       MVI    C,20
00061E       POP    D
00061F       ADD    E
000620       ADD    D
000621       MOV    M,E
000622       INX    H
000623       MOV    M,D
000624       INX    H
000625       POP    D
000626       ADD    E
000627       ADD    D
000628       MOV    M,E
000629       INX    H
00062A       MOV    M,D
00062B       INX    H
00062C       DCR    C
00062D       JNZ    061E
000630       MOV    C,A
000631       MVI    A,00
000633       OUT    10
000635       LHLD   DED0
000638       SPHL
000639       EI
00063A       MOV    A,C
00063B       CALL   068C
00063E       POP    D
00063F       POP    B
000640       RET
000641       LDA    DED4
000644       LXI    D,FF80
000647       LXI    H,0400
00064A       DAD    D
00064B       DCR    A
00064C       JNZ    064A
00064F       XCHG
000650       LDA    DED3
000653       CMA
000654       CPI    FC
000656       JNC    065B
000659       SUI    10
00065B       SUI    04
00065D       MOV    L,A
00065E       RLC
00065F       RLC
000660       ANI    FC
000662       MOV    H,A
000663       MOV    A,L
000664       MVI    L,00
000666       DAD    D
000667       RLC
000668       RLC
000669       RLC
00066A       RLC
00066B       ANI    0C
00066D       PUSH   B
00066E       MOV    C,A
00066F       MVI    A,10
000671       ORA    C
000672       POP    B
000673       RET
000674       LDA    DED3
000677       MOV    L,A
000678       MVI    H,00
00067A       DAD    H
00067B       DAD    H
00067C       DAD    H
00067D       DAD    H
00067E       MVI    A,F0
000680       ADD    H
000681       MOV    H,A
000682       LDA    DED4
000685       DCR    A
000686       ADD    A
000687       ADD    L
000688       MOV    L,A
000689       MVI    A,1C
00068B       RET
00068C       PUSH   PSW
00068D       PUSH   D
00068E       LXI    H,0000
000691       DAD    SP
000692       SHLD   DED0
000695       CALL   0674
000698       DI
000699       OUT    10
00069B       SPHL
00069C       POP    D
00069D       MVI    A,00
00069F       OUT    10
0006A1       LHLD   DED0
0006A4       SPHL
0006A5       EI
0006A6       XCHG
0006A7       POP    D
0006A8       POP    PSW
0006A9       CMP    H
0006AA       JNZ    06AF
0006AD       SUB    L
0006AE       RZ
0006AF       MVI    A,FF
0006B1       RET
0006B2       MVI    B,02
0006B4       LXI    D,D8E2
0006B7       STA    DCF7
0006BA       LDA    DCF7
0006BD       ANI    7F
0006BF       MOV    C,A
0006C0       PUSH   D
0006C1       MOV    A,M
0006C2       STAX   D
0006C3       INX    D
0006C4       LDA    DCF7
0006C7       ORA    A
0006C8       JP     06CE
0006CB       MOV    A,M
0006CC       STAX   D
0006CD       INX    D
0006CE       INX    H
0006CF       DCR    C
0006D0       JNZ    06C1
0006D3       POP    D
0006D4       INR    D
0006D5       DCR    B
0006D6       JNZ    06BA
0006D9       RET
0006DA       LDA    DEF7
0006DD       CPI    7F
0006DF       JNZ    006F
0006E2       LXI    H,0800
0006E5       LXI    D,0100
0006E8       LXI    B,2200
0006EB       MOV    A,M
0006EC       STAX   D
0006ED       INX    H
0006EE       INX    D
0006EF       DCX    B
0006F0       MOV    A,B
0006F1       ORA    C
0006F2       JNZ    06EB
0006F5       MVI    D,22
0006F7       JMP    05D7
0006FA       ADC    H
0006FB       ADC    A
0006FC       ADC    L
0006FD       ADC    L
0006FE       ANA    A
0006FF       RPO
000700       MVI    M,B6
000702       MVI    M,BE
000704       CMP    M
000705       ORA    M
000706       SHLD   CD00
000709       CALL   FDED
00070C       CDCD
00070F       NOP
000710       ADD    E
000711       ADD    M
000712       ANI    B6
000714       ORA    M
000715       ORA    M
000716       XTHL
000717       NOP
000718       ANA    A
000719       C3E1
00071C       POP    B
00071D       00A7
000720       INR    E
000721       ORA    M
000722       ORA    M
000723       MVI    M,B6
000725       ORA    M
000726       INR    E
000727       NOP
000728       POP    PSW
000729       IN     DB
00072B       POP    PSW
00072C       RC
00072D       00F1
000730       CPE    3599
000733       MOV    L,L
000734       POP    B
000735       ANA    C
000736       MOV    H,C
000737       RNZ
000738       XTHL
000739       ORA    M
00073A       ORA    M
00073B       ADD    M
00073C       ADD    M
00073D       ORA    M
00073E       ORA    E
00073F       RPO
000740       SBB    C
000741       IN     DE
000743       CC     DEDC
000746       SBB    E
000747       NOP
000748       CMP    E
000749       MOV    L,L
00074A       MOV    L,L
00074B       MOV    L,L
00074C       MOV    L,L
00074D       MOV    L,H
00074E       B300
000751       ORA    M
000752       ORA    M
000753       ORA    M
000754       ORA    M
000755       ORA    M
000756       MOV    M,E
000757       NOP
000758       SBB    M
000759       IN     DB
00075B       SBI    DB
00075D       IN     9E
00075F       NOP
000760       DI
000761       IN     DB
000763       IN     F3
000765       IN     DB
000767       DI
000768       IN     1B
00076A       DCX    D
00076B       LDAX   D
00076C       SBB    H
00076D       LDAX   D
00076E       DCX    D
00076F       IN     18
000771       1818
000774       5A18
000777       MOV    A,M
000778       MOV    M,E
000779       IN     DB
00077B       IN     DB
00077D       IN     DB
00077F       MOV    M,E
000780       NOP
000781       LXI    B,6DC1
000784       MOV    L,L
000785       MOV    H,C
000786       MOV    H,C
000787       RNZ
000788       XTHL
000789       ORA    M
00078A       ORA    M
00078B       ORA    M
00078C       ORA    A
00078D       ORA    M
00078E       ORA    M
00078F       XTHL
000790       ADD    E
000791       RST    3
000792       SUI    D6
000794       SUB    M
000795       MVI    D,D6
000797       SUB    M
000798       CMC
000799       XRA    E
00079A       CMP    A
00079B       RNZ
00079C       RST    7
00079D       RST    5
00079E       CNZ    FFEC
0007A1       RST    7
0007A2       ADD    B
0007A3       RNZ
0007A4       MOV    A,A
0007A5       CM     FDD5
0007A8       INX    B
0007A9       RST    7
0007AA       RST    6
0007AB       INX    H
0007AC       STC
0007AD       RST    7
0007AE       RST    7
0007AF       LXI    B,FE03
0007B2       RRC
0007B3       RST    7
0007B4       ADD    B
0007B5       SUB    D
0007B6       ADD    B
0007B7       SUB    D
0007B8       ADD    B
0007B9       SUB    D
0007BA       ADD    B
0007BB       SUB    D
0007BC       ADD    B
0007BD       RST    7
0007BE       RP
0007BF       RST    7
0007C0       LXI    B,0149
0007C3       MOV    C,C
0007C4       LXI    B,0149
0007C7       MOV    C,C
0007C8       LXI    B,FFFF
0007CB       CPI    FE
0007CD       RST    7
0007CE       CM     FFFC
0007D1       ADD    C
0007D2       ADD    C
0007D3       RST    7
0007D4       RST    7
0007D5       MOV    A,A
0007D6       MOV    A,A
0007D7       RST    7
0007D8       CMC
0007D9       CMC
0007DA       RST    7
0007DB       CPI    FF
0007DD       RST    7
0007DE       MOV    D,L
0007DF       RST    7
0007E0       RNZ
0007E1       RST    0
0007E2       RNZ
0007E3       RST    7
0007E4       MOV    D,L
0007E5       MOV    D,H
0007E6       RST    7
0007E7       INX    B
0007E8       ADI    03
0007EA       RST    7
0007EB       MOV    D,H
0007EC       POP    B
0007ED       010F
0007F0       RLC
0007F1       CPO    0704
0007F4       83C1
0007F7       INR    B
0007F8       RP
0007F9       ADD    B
0007FA       RPO
0007FB       DAA
0007FC       04E0
0007FF       ADD    E
000800       NOP
