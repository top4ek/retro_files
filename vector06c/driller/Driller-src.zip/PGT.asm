		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db  38h, 7Ch, 7Ch, 38h, 10h,	0, 10h,	  0
		.db  77h, 77h, 22h,   0,   0,	0,   0,	  0
		.db  14h, 16h, 1Ch, 36h, 1Ch, 34h, 14h,	  0
		.db  3Ch, 5Eh, 9Fh,0BFh,0BFh,0FFh, 7Eh,	3Ch
		.db  18h, 3Ch, 7Eh,0FFh, 18h, 18h, 18h,	  0
		.db  18h, 18h, 18h,0FFh, 7Eh, 3Ch, 18h,	  0
		.db  38h, 38h, 10h,   0,   0,	0,   0,	  0
		.db    8, 0Ch, 0Eh, 7Fh, 7Fh, 0Eh, 0Ch,	  8
		.db  10h, 30h, 70h,0FEh,0FEh, 70h, 30h,	10h
		.db  3Ch, 42h, 99h,0A1h,0A1h, 99h, 42h,	3Ch
		.db    0, 10h, 10h, 7Ch, 10h, 10h,   0,	  0
		.db    0,   0,	 0, 30h, 30h, 10h, 20h,	  0
		.db    0,   0,	 0, 7Ch,   0,	0,   0,	  0
		.db    0,   0,	 0, 30h, 78h, 78h, 30h,	  0
		.db    0, 10h,	 0, 7Ch,   0, 10h,   0,	  0
		.db  1Ch, 26h, 63h, 63h, 63h, 32h, 1Ch,	  0
		.db  0Ch, 1Ch, 0Ch, 0Ch, 0Ch, 0Ch, 3Fh,	  0
		.db  3Eh, 63h,	 7, 1Eh, 3Ch, 70h, 7Fh,	  0
		.db  3Fh,   6, 0Ch, 1Eh,   3, 63h, 3Eh,	  0
		.db  0Eh, 1Eh, 36h, 66h, 7Fh,	6,   6,	  0
		.db  7Eh, 60h, 7Eh,   3,   3, 63h, 3Eh,	  0
		.db  1Eh, 30h, 60h, 7Eh, 63h, 63h, 3Eh,	  0
		.db  7Fh, 63h,	 6, 0Ch, 18h, 18h, 18h,	  0
		.db  3Ch, 62h, 72h, 3Ch, 47h, 43h, 3Eh,	  0
		.db  3Eh, 63h, 63h, 3Fh,   3,	6, 3Ch,	  0
		.db    0, 30h, 30h,   0, 30h, 30h,   0,	  0
		.db    0, 30h, 30h,   0, 30h, 10h, 20h,	  0
		.db    6, 18h, 60h, 18h,   6, 7Eh,   0,	7Eh
		.db    0,   0, 7Eh,   0, 7Eh,	0,   0,	  0
		.db  60h, 18h,	 6, 18h, 60h, 7Eh,   0,	7Eh
		.db  3Ch, 66h, 66h, 0Ch, 10h,	0, 10h,	  0
		.db    8, 6Bh, 3Eh, 3Eh, 1Ch,	8, 6Bh,	1Ch
		.db  1Ch, 36h, 63h, 63h, 7Fh, 63h, 63h,	  0
		.db  7Eh, 63h, 63h, 7Eh, 63h, 63h, 7Eh,	  0
		.db  1Eh, 33h, 60h, 60h, 60h, 33h, 1Eh,	  0
		.db  7Ch, 66h, 63h, 63h, 63h, 66h, 7Ch,	  0
		.db  7Fh, 60h, 60h, 7Eh, 60h, 60h, 7Fh,	  0
		.db  7Fh, 60h, 60h, 7Eh, 60h, 60h, 60h,	  0
		.db  1Fh, 30h, 60h, 6Fh, 63h, 33h, 1Fh,	  0
		.db  63h, 63h, 63h, 7Fh, 63h, 63h, 63h,	  0
		.db  3Fh, 0Ch, 0Ch, 0Ch, 0Ch, 0Ch, 3Fh,	  0
		.db    3,   3,	 3,   3, 63h, 63h, 3Eh,	  0
		.db  63h, 66h, 6Ch, 78h, 7Ch, 6Eh, 67h,	  0
		.db  30h, 30h, 30h, 30h, 30h, 30h, 3Fh,	  0
		.db  63h, 77h, 7Fh, 7Fh, 6Bh, 63h, 63h,	  0
		.db  63h, 73h, 7Bh, 7Fh, 6Fh, 67h, 63h,	  0
		.db  3Eh, 63h, 63h, 63h, 63h, 63h, 3Eh,	  0
		.db  7Eh, 63h, 63h, 63h, 7Eh, 60h, 60h,	  0
		.db  3Eh, 63h, 63h, 63h, 6Fh, 72h, 3Dh,	  0
		.db  7Eh, 63h, 63h, 67h, 7Ch, 6Eh, 67h,	  0
		.db  3Ch, 66h, 60h, 3Eh,   3, 63h, 3Eh,	  0
		.db  3Fh, 0Ch, 0Ch, 0Ch, 0Ch, 0Ch, 0Ch,	  0
		.db  63h, 63h, 63h, 63h, 63h, 63h, 3Eh,	  0
		.db  63h, 63h, 63h, 77h, 3Eh, 1Ch,   8,	  0
		.db  63h, 63h, 6Bh, 7Fh, 7Fh, 77h, 63h,	  0
		.db  63h, 77h, 3Eh, 1Ch, 3Eh, 77h, 63h,	  0
		.db  33h, 33h, 33h, 1Eh, 0Ch, 0Ch, 0Ch,	  0
		.db  7Fh,   7, 0Eh, 1Ch, 38h, 70h, 7Fh,	  0
		.db  0Eh, 0Ch, 0Ch, 0Ch, 0Ch, 0Ch, 0Eh,	  0
		.db  42h, 24h, 7Eh, 18h, 7Eh, 18h, 18h,	  0
		.db  70h, 30h, 30h, 30h, 30h, 30h, 70h,	  0
		.db 0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh
		.db 0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh,0FFh
		.db    1,   3,	 3,   3,   3,	1,   1,	  1
		.db  80h,0C0h,0C0h,0C0h,0C0h, 80h, 80h,	80h
		.db    0,   0,	 0,   0,   0,	0,   4,	  4
		.db    0,   0,	 0,   1,   7, 1Fh, 3Fh,	7Fh
		.db  80h, 80h, 80h,0C0h,0F0h,0FCh,0FEh,0FFh
		.db    0,   0,	 0,   0,   0,	0, 10h,	10h
		.db    0,   1,	 1,   1,   1,	0,   0,	  0
		.db 0C0h,0E0h,0E0h,0E0h,0E0h,0C0h,0C0h,0C0h
		.db    7,   7,	 7,   7,   7,	7,   7,	  7
		.db 0E3h,0E3h,0E3h,0E3h,0E3h,0E3h,0E3h,0E3h
		.db  2Ah, 2Ah, 3Fh,0FFh,0F9h, 70h, 30h,	3Fh
		.db 0A4h,0A7h,0A7h,0AFh,0AFh,0AEh,0AEh,0AFh
		.db  9Ah,0EAh,0F2h,0FAh, 7Ah, 3Ah, 3Ah,0FAh
		.db 0AAh,0AAh,0FEh,0FFh,0CFh, 86h, 86h,0FEh
		.db  63h, 63h, 63h,0E3h,0E3h,0E3h, 63h,	63h
		.db 0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h,0F0h
		.db    3,   3,	 3,   3,   3,	3,   3,	  3
		.db 0C0h,0C0h,0C0h,0C0h,0C0h,0C0h,0C0h,0C0h
		.db  0Eh, 3Fh, 7Fh, 3Fh, 3Fh, 3Fh, 3Fh,	2Ah
		.db  7Fh,0FFh,0FFh,0BFh,0BFh,0A0h,0A5h,0A5h
		.db 0FFh,0FFh,0FFh,0FEh,0FEh,	2, 5Ah,	5Ah
		.db  38h,0FEh,0FFh,0FEh,0FEh,0FEh,0FEh,0AAh
		.db    1,   1,	 1,   1,   1,	1,   1,	  1
		.db 0E0h,0E0h,0E0h,0E0h,0E0h,0E0h,0E0h,0E0h
		.db  0Fh, 0Fh, 0Fh, 0Fh, 0Fh, 0Fh, 0Fh,	0Fh
		.db 0F3h,0F3h,0F3h,0F3h,0F3h,0F3h,0F3h,0F3h
		.db 0FFh,0FFh, 79h, 30h, 30h, 30h, 30h,	30h
		.db 0AFh,0AFh,0AFh,0AFh,0AFh,0AEh,0AEh,0AEh
		.db 0FAh,0FAh,0FAh,0FAh, 7Ah, 3Ah, 3Ah,	3Ah
		.db 0FFh,0FFh,0CEh, 86h, 86h, 86h, 86h,	86h
		.db 0E7h,0E7h,0E7h, 67h, 67h, 67h, 67h,	67h
		.db 0F8h,0F8h,0F8h,0F8h,0F8h,0F8h,0F8h,0F8h
		.db    0,   1,	 3,   5,   7,	5, 0Dh,	35h
		.db    0,0C1h, 23h, 33h,0FFh,0FFh, 1Fh,	41h
		.db    0,   1,	 3,   5,   7,	5, 0Dh,	35h
		.db    0,0C1h, 23h, 33h,0FFh,0FFh, 1Fh,	41h
		.db    0, 83h,0C4h,0CCh,0FFh,0FFh,0F8h,	82h
		.db    0, 80h,0C0h,0A0h,0E0h,0A0h,0B0h,0ACh
		.db    0, 83h,0C4h,0CCh,0FFh,0FFh,0F8h,	82h
		.db    0, 80h,0C0h,0A0h,0E0h,0A0h,0B0h,0ACh
		.db  7Fh, 3Eh, 0Eh, 0Eh, 1Eh, 3Ch, 4Dh,	4Ch
		.db 0ECh, 3Ah,0B1h,0BBh, 3Fh, 95h,0DBh,	95h
		.db  7Fh, 3Eh, 0Eh, 0Eh, 1Eh, 3Ch, 4Dh,	4Ch
		.db 0ECh, 36h,0BBh,0B5h, 3Fh, 9Bh,0D1h,	9Bh
		.db    0,   0,	 1,   1,   2, 1Fh, 28h,	7Fh
		.db  80h, 80h, 40h, 8Ch,0DAh, 71h, 1Bh,0FFh
		.db    0,   0,	 1,   1,   2, 1Fh, 28h,	7Fh
		.db  80h, 80h, 40h, 8Ch,0D6h, 7Bh, 15h,0FFh
		.db 0D9h, 2Dh,	 5, 0Fh, 1Bh, 11h, 0Bh,	  7
		.db 0EDh, 41h, 1Fh,0FEh, 5Bh,0B1h, 5Ah,0FCh
		.db 0D9h, 2Dh,	 5, 0Fh, 15h, 1Bh, 0Dh,	  7
		.db 0EDh, 41h, 1Fh,0FEh,0B5h, 1Bh,0B6h,0FCh
		.db 0B7h, 82h,0F8h, 7Fh,0DAh, 8Dh, 5Ah,	3Fh
		.db  9Bh,0B4h,0A0h,0F0h,0D8h, 88h,0D0h,0E0h
		.db 0B7h, 82h,0F8h, 7Fh,0ADh,0D8h, 6Dh,	3Fh
		.db  9Bh,0B4h,0A0h,0F0h,0A8h,0D8h,0B0h,0E0h
		.db  7Fh, 28h, 1Fh,   2,   1,	1,   0,	  0
		.db 0FFh, 1Bh, 71h,0DAh, 8Ch, 40h, 80h,	80h
		.db  7Fh, 28h, 1Fh,   2,   1,	1,   0,	  0
		.db 0FFh, 15h, 7Bh,0D6h, 8Ch, 40h, 80h,	80h
		.db  4Ch, 4Dh, 3Ch, 1Eh, 0Eh, 0Eh, 3Eh,	7Fh
		.db  95h,0DBh, 95h, 3Fh,0BBh,0B1h, 3Ah,0ECh
		.db  4Ch, 4Dh, 3Ch, 1Eh, 0Eh, 0Eh, 3Eh,	7Fh
		.db  9Bh,0D1h, 9Bh, 3Fh,0B5h,0BBh, 36h,0ECh
		.db  0Fh, 1Fh, 20h, 6Eh,0C0h,0FFh,0AFh,	29h
		.db 0C0h,0D8h, 1Ch, 3Eh, 7Eh,0FEh,0FEh,0FEh
		.db  0Fh, 11h, 2Eh, 70h, 5Fh, 57h,   5,	  0
		.db 0C0h,0D8h, 1Ch, 3Eh,0FEh,0FEh,0FEh,	7Eh
		.db    3, 1Bh, 38h, 7Ch, 7Eh, 7Fh, 7Fh,	7Fh
		.db 0F0h,0F8h,	 4, 76h,   3,0FFh,0F5h,	94h
		.db    3, 1Bh, 38h, 7Ch, 7Fh, 7Fh, 7Fh,	7Eh
		.db 0F0h, 88h, 74h, 0Eh,0FAh,0EAh,0A0h,	  0
		.db    0, 0Ah, 37h, 1Bh, 2Fh, 2Bh, 1Ch,	78h
		.db    0,   0, 20h, 68h,0FCh, 58h, 0Eh,	  3
		.db    0, 8Eh, 77h, 3Fh, 73h, 38h, 98h,	70h
		.db  80h, 50h, 68h,0ECh, 3Ch,	8,   6,	  1
		.db    0,   0,	 4, 16h, 3Fh, 1Ah, 70h,0C0h
		.db    0, 50h,0ECh,0D8h,0F4h,0D4h, 38h,	1Eh
		.db    1, 0Ah, 16h, 37h, 3Ch, 10h, 60h,	80h
		.db    0, 71h,0EEh,0FCh,0CEh, 1Ch, 19h,	0Eh
		.db  53h, 5Fh, 7Fh, 1Fh,0CFh, 3Fh, 0Fh,	  7
		.db 0FEh,0FEh,0FEh,0FCh,0F1h,0F2h,0FFh,0FEh
		.db  53h, 5Fh, 7Fh, 1Fh, 4Fh, 3Fh, 0Fh,	  7
		.db 0FEh,0FEh,0FEh,0FCh,0F0h,0EEh,0FDh,0FAh
		.db  7Fh, 7Fh, 7Fh, 3Fh, 8Fh, 4Fh,0FFh,	7Fh
		.db 0CAh,0FAh,0FEh,0F8h,0F3h,0FCh,0F0h,0E0h
		.db  7Fh, 7Fh, 7Fh, 3Fh, 0Fh, 77h,0BFh,	5Fh
		.db 0CAh,0FAh,0FEh,0F8h,0F2h,0FCh,0F0h,0E0h
		.db  3Eh, 4Dh, 1Bh, 2Fh,   7, 0Eh,   8,	  0
		.db  2Eh, 3Ch, 74h,0E4h, 48h,0C0h,   0,	  0
		.db  78h,0D8h, 31h, 37h, 7Fh, 6Eh, 98h,	  0
		.db    6, 1Ch, 3Ch, 6Ch,0C4h,0C8h, 80h,	  0
		.db  74h, 3Ch, 2Eh, 27h, 12h,	3,   0,	  0
		.db  7Ch,0B2h,0D8h,0F4h,0E0h, 70h, 10h,	  0
		.db  60h, 38h, 3Ch, 36h, 23h, 13h,   1,	  0
		.db  1Eh, 1Bh, 8Ch,0ECh,0FEh, 76h, 19h,	  0
		.db  0Fh, 1Fh, 20h, 6Eh,0C0h,0FFh,0AFh,	29h
		.db 0C0h,0D8h, 1Ch, 3Eh, 7Eh,0FEh,0FEh,0FEh
		.db  0Fh, 16h, 29h, 70h,0B6h,0D9h,0ABh,	29h
		.db  40h,0D8h, 90h, 6Ch,0B2h, 76h, 68h,	1Eh
		.db    0,   0,	 0,   0,   6, 19h, 3Bh,	3Dh
		.db    0,   0,	 0,   0,0B0h, 58h, 68h,	54h
		.db    3, 1Bh, 38h, 7Ch, 7Eh, 7Fh, 7Fh,	7Fh
		.db 0F0h,0F8h,	 4, 76h,   3,0FFh,0F5h,	94h
		.db    2, 1Bh,	 9, 36h, 4Dh, 6Eh, 16h,	78h
		.db 0F0h, 68h, 94h, 0Eh, 6Dh, 9Bh,0D5h,	94h
		.db    0,   0,	 0,   0, 0Dh, 1Ah, 16h,	2Ah
		.db    0,   0,	 0,   0, 60h, 98h,0DCh,0BCh
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	60h
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db  53h, 5Fh, 7Fh, 1Fh,0CFh, 3Fh, 6Fh,	  7
		.db 0FEh,0FEh,0FEh,0FCh,0F1h,0E2h,0FFh,0FEh
		.db  52h, 57h, 7Bh, 15h,0CAh, 35h, 6Ah,	  7
		.db 0E6h, 56h,0B8h, 4Ch, 71h,0A2h,0DBh,	5Ch
		.db  12h, 37h, 7Bh, 15h, 6Eh,0F7h, 5Ah,	  7
		.db 0EEh, 56h,0BAh, 48h, 76h,0A6h,0DBh,	5Ch
		.db  7Fh, 7Fh, 7Fh, 3Fh, 8Fh, 47h,0FFh,	7Fh
		.db 0CAh,0FAh,0FEh,0F8h,0F3h,0FCh,0F6h,0E0h
		.db  67h, 6Ah, 1Dh, 32h, 8Eh, 45h,0DBh,	3Ah
		.db  4Ah,0EAh,0DEh,0A8h, 53h,0ACh, 56h,0E0h
		.db  77h, 6Ah, 5Dh, 12h, 6Eh, 65h,0DBh,	3Ah
		.db  48h,0ECh,0DEh,0A8h, 76h,0EFh, 5Ah,0E0h
		.db  0Eh, 35h, 7Bh, 55h, 2Eh,0F7h,0DAh,	67h
		.db 0F0h, 54h,0BAh, 5Eh, 78h,0B6h,0FBh,	5Ch
		.db    0,   0,	 0,   3, 2Eh, 65h,0DBh,0ADh
		.db    0,   0,	 0, 80h, 58h,0B2h,0AEh,	5Bh
		.db    2,   4,	 8,   8,   4,	2,   1,	  7
		.db  40h, 20h, 10h, 10h, 20h, 40h, 80h,0E0h
		.db    8, 10h, 20h, 30h, 0Ch,	2, 81h,	47h
		.db  10h,   8,	 4, 0Ch, 30h, 40h, 81h,0E2h
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0, 40h, 90h, 24h, 49h, 92h, 24h,	49h
		.db    0,   0,	 0,   0,   0, 40h, 90h,	24h
		.db    0,   0,	 0,   0,   0,	2,   9,	24h
		.db    0,   2,	 9, 24h, 92h, 49h, 24h,	92h
		.db    0,   0,	 1,   0,   2,	1,   4,	  2
		.db  80h,   0, 40h, 80h, 20h, 40h, 90h,	20h
		.db  24h, 49h, 12h, 24h,   9, 12h,   4,	  9
		.db  92h, 49h, 24h, 92h, 48h, 24h, 90h,	48h
		.db  3Bh, 4Dh,0BAh, 4Dh,0BAh, 4Dh, 86h,	  1
		.db 0DCh,0B2h, 5Dh,0B2h, 5Dh,0B2h, 61h,	80h
		.db 0BEh, 49h,0BEh, 49h, 3Eh,	9,   7,	  1
		.db  7Dh, 92h, 7Dh, 92h, 7Ch, 90h,0E0h,	80h
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db  92h, 49h, 24h, 92h, 49h, 24h, 90h,	40h
		.db  49h, 24h, 90h, 40h,   0,	0,   0,	  0
		.db  92h, 24h,	 9,   2,   0,	0,   0,	  0
		.db  49h, 92h, 24h, 49h, 92h, 24h,   9,	  2
		.db    9,   4, 12h,   9, 24h, 12h, 49h,	24h
		.db  48h, 90h, 24h, 48h, 92h, 24h, 49h,	92h
		.db    2,   4,	 1,   2,   0,	1,   0,	  0
		.db  20h, 90h, 40h, 20h, 80h, 40h,   0,	80h
