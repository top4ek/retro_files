;(�) ���� ����������, ��� 2008


		mvi	b,160
LDIRVM_PNT:
		xchg
		push	h
LDIRVMpntLop:
		ldax	d
		cmp	m
		jz	SkpLVP0
;0
		mov	m,a
		push	d
		push	h
		rlc
		rlc
		rlc
		mov	d,a
		mvi	e,11111000b
		ana	e
		mov	e,a
		mvi	a,00000111b
		ana	d
		adi	PGThi
		mov	d,a
		mvi	a,00000011b
		ana	h
		push	psw
		mvi	a,00011111b
		ana	l		;
		adi	0C0h		;C000h-DFFFh
		mov	h,a		;
		mvi	a,11100000b
		ana	l
		mov	l,a
		pop	psw
		ora	l
		rrc
		rrc			;Y=Y*8
		adi	DwnShift
		cma			;Y=255-Y
		mov	l,a
		Mov8BytesHD
		pop	h
		pop	d
SkpLVP0:
		inx	h
		inx	d
		ldax	d
		cmp	m
		jz	SkpLVP1
;1
		mov	m,a
		push	d
		push	h
		rlc
		rlc
		rlc
		mov	d,a
		mvi	e,11111000b
		ana	e
		mov	e,a
		mvi	a,00000111b
		ana	d
		adi	PGThi
		mov	d,a
		mvi	a,00000011b
		ana	h
		push	psw
		mvi	a,00011111b
		ana	l		;
		adi	0C0h		;C000h-DFFFh
		mov	h,a		;
		mvi	a,11100000b
		ana	l
		mov	l,a
		pop	psw
		ora	l
		rrc
		rrc			;Y=Y*8
		adi	DwnShift
		cma			;Y=255-Y
		mov	l,a
		Mov8BytesHD
		pop	h
		pop	d
SkpLVP1:
		inx	h
		inx	d
		ldax	d
		cmp	m
		jz	SkpLVP2
;2
		mov	m,a
		push	d
		push	h
		rlc
		rlc
		rlc
		mov	d,a
		mvi	e,11111000b
		ana	e
		mov	e,a
		mvi	a,00000111b
		ana	d
		adi	PGThi
		mov	d,a
		mvi	a,00000011b
		ana	h
		push	psw
		mvi	a,00011111b
		ana	l		;
		adi	0C0h		;C000h-DFFFh
		mov	h,a		;
		mvi	a,11100000b
		ana	l
		mov	l,a
		pop	psw
		ora	l
		rrc
		rrc			;Y=Y*8
		adi	DwnShift
		cma			;Y=255-Y
		mov	l,a
		Mov8BytesHD
		pop	h
		pop	d
SkpLVP2:
		inx	h
		inx	d
		ldax	d
		cmp	m
		jz	SkpLVP3
;3
		mov	m,a
		push	d
		push	h
		rlc
		rlc
		rlc
		mov	d,a
		mvi	e,11111000b
		ana	e
		mov	e,a
		mvi	a,00000111b
		ana	d
		adi	PGThi
		mov	d,a
		mvi	a,00000011b
		ana	h
		push	psw
		mvi	a,00011111b
		ana	l		;
		adi	0C0h		;C000h-DFFFh
		mov	h,a		;
		mvi	a,11100000b
		ana	l
		mov	l,a
		pop	psw
		ora	l
		rrc
		rrc			;Y=Y*8
		adi	DwnShift
		cma			;Y=255-Y
		mov	l,a
		Mov8BytesHD
		pop	h
		pop	d
SkpLVP3:
		inx	h
		inx	d
		dcr	b
		jnz	LDIRVMpntLop
		pop	h
