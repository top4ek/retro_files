@echo off
if exist saturcod0.bin del saturcod0.bin
if exist saturcod0.inc del saturcod0.inc
if exist saturcod0.lst del saturcod0.lst
if exist saturcod1.bin del saturcod1.bin
if exist saturcod1.lst del saturcod1.lst

rem Define ESCchar to use in ANSI escape sequences
rem https://stackoverflow.com/questions/2048509/how-to-echo-with-different-colors-in-the-windows-command-line
for /F "delims=#" %%E in ('"prompt #$E# & for %%E in (1) do rem"') do set "ESCchar=%%E"

echo Compiling code0...
tools\sjasmplus --nologo --msg=err --i8080 -DLZSIZES=%lzsizes% -DLZSIZE1=12345 saturcod0.asm --lst=saturcod0.lst --exp=saturcod0.inc
if errorlevel 1 goto Failed

echo Compiling code1...
tools\sjasmplus --nologo --msg=err saturcod1.asm --lst=saturcod1.lst
if errorlevel 1 goto Failed

dir /-c saturcod?.bin|findstr /R /C:"saturcod"

copy /b saturcod0.bin+saturcod1.bin saturn.rom >nul
@if errorlevel 1 goto Failed
dir /-c saturn.rom|findstr /R /C:"saturn.rom"

echo %ESCchar%[92mSUCCESS%ESCchar%[0m
exit

:Failed
@echo off
echo %ESCchar%[91mFAILED%ESCchar%[0m
exit /b
