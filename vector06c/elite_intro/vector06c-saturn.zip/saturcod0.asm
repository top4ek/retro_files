;----------------------------------------------------------------------------

	EXPORT SATURCOD0_END

	OUTPUT "saturcod0.bin"
	ORG	100h

;----------------------------------------------------------------------------

	di
	xor a
	out (10h),a		; turn off the quasi-disk
	ld sp,0100h
	ld hl,0C3F3h
	ld (0),hl
	ld a,h
	ld hl,RestartInt
	ld (2),hl
	ld (38h),a
	ld hl,KEYINT		; interrupt handler address
	ld (38h+1),hl

	call SetPaletteGame
	di

RestartInt:
	ld sp,100h
	ld a,88h
	out (4),a		; initialize R-Sound 2

	ld h,$C0 ;LD HL,$C000	; screen pixels start address
	ld c,32			; 32 columns: $C0..$DF
.clear0:
	xor a
	ld L,A
.clear1:
	dec l
	LD (HL),a		; clear pixels
	jp nz,.clear1
	inc h
	dec C
	jp nz,.clear0

; Start SATURCOD1
	jp SATURCOD0_END

; Set game palette
SetPaletteGame:
	ld hl,PaletteGame+15
; Programming the Palette
SetPalette:
	ei
	halt
	ld de,100Fh
PaletLoop:
	ld a,e
	out (2),a
	ld a,(hl)
	out (0Ch),a
	out (0Ch),a
	out (0Ch),a
	out (0Ch),a
	out (0Ch),a
	dec hl
	out (0Ch),a
	dec e
	out (0Ch),a
	dec d
	out (0Ch),a
	jp nz,PaletLoop
	ret

;----------------------------------------------------------------------------

KEYINT:
	push af
;	push hl
	; ld a,8Ah
	; out (0),a
; Keyboard scan
	; in A,(1)
	; or 00011111b
	; ld (KeyLineEx),a
	; ld a,0FEh
	; out (3),a
	; in A,(2)
	; ld (KeyLine0),a
	; ld a,0FBh
	; out (3),a
	; in A,(2)
	; ld (KeyLine2),a
	; ld a,07Fh
	; out (3),A
	; in A,(2)
	; ld (KeyLine7),A

; Scrolling, screen mode, border
	ld a,88h
	out (0),A
	ld a,2
	out (1),A
	ld a,0FFh
	out (3),A		; scrolling
	xor A
	out (2),A		; screen mode and border
;
;	pop hl
	pop af
	ei
	ret

;----------------------------------------------------------------------------

ColorNone equ 00000000b    ; Color for empty bits  - black
ColorE000 equ 00000000b    ; Color for $E000-$FFFF - black
ColorC000 equ 11111111b    ; Color for $C000-$DFFF - white
ColorBoth equ 11111111b    ; Color for both planes - white
PaletteGame:
	db	ColorNone, ColorE000, ColorC000, ColorBoth	; 0..3
	db	ColorNone, ColorE000, ColorC000, ColorBoth	; 4..7
	db	ColorNone, ColorE000, ColorC000, ColorBoth	; 8..11
	db	ColorNone, ColorE000, ColorC000, ColorBoth	; 12..15

;----------------------------------------------------------------------------

SATURCOD0_END
	OUTEND
	END