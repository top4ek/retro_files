	INCLUDE "saturcod0.inc"

  OUTPUT "saturcod1.bin"
  ORG SATURCOD0_END

; -----------------------------------------------------------

SEED EQU 222

; -----------------------------------------------------------
; i8080 port notes:
;  - No relative jumps (JR) or DJNZ  -> all replaced with JP / dec+JP nz
;  - No register-targeted shifts (SRL/SLA/SRA/RL/RR on r != A)
;       -> emulated via accumulator: OR A clears carry, RRA/RLA rotate,
;          ADD A,A doubles (= SLA A)
;  - No NEG                          -> replaced with CPL / INC A
;  - No LDIR                          -> replaced with explicit copy loop
;  - No 16-bit SBC HL,rr              -> replaced with byte-wise
;                                         SUB / SBC A,r on L/H
;  - EX DE,HL, ADD HL,rr, INC/DEC rr, PUSH/POP, CALL/RET, conditional
;    jumps (incl. M/P on sign flag) all map 1:1 to native i8080 opcodes.
; -----------------------------------------------------------

; Start the main code
  di
  ;ld sp,$5FB4
  ;ei
;
.loop:
  call Draw_Saturn	; draw
;
  ei
  ld B,75		; long pause
.wait1:
  halt
  dec b
  jp  nz, .wait1
  di
;
  call Draw_Saturn	; un-draw
;
  ei
  ld B,25		; short pause
.wait2:
  halt
  dec b
  jp  nz, .wait2
  di
;
  jp .loop

Draw_Saturn:
  ld HL,SEED
  ld (PRNG_SEED),HL	; reset PRNG seed
  ld BC,464
.loop1:
  push BC
  call Draw_Disk_Iter
  call Draw_Rings_Iter
  call Draw_Stars_Iter
  call Draw_Disk_Iter
  call Draw_Rings_Iter
  pop BC
  dec BC
  ld A,B
  or C
  jp nz,.loop1
  ret

; ===========================================================
; Saved values for stage calculations
; ===========================================================
Disk_r2:
  DB 0                  ; Stage 1: signed r2
Stars_x:
  DB 0                  ; Stage 2: signed x
Stars_y:
  DB 0                  ; Stage 2: signed y
Ring_r5:
  DB 0                  ; Stage 3: signed r5 (occlusion sign check)
Ring_r6:
  DB 0                  ; Stage 3: signed r6 = y
Ring_x:
  DB 0                  ; Stage 3: signed x = r6 + r5/4 (byte, wrap OK for ring values)
Ring_x_abs:
  DB 0                  ; Stage 3: |x|
Ring_y_abs:
  DB 0                  ; Stage 3: |y| = |r6|
Ring_P_neg:
  DB 0                  ; Stage 3: $80 if x*y < 0, else 0
Ring_S:
  DW 0                  ; Stage 3: S = x^2 + y^2 (occlusion check)

; ===========================================================
; Draw_Saturn stages
; ===========================================================

  ; ------- Stage 1: planet disk -------
  ;   r1, r2 = signed random bytes (-128..127)
  ;   filter: r1^2 + r2^2 < 16384
  ;   x  = sqrt(16384 - r1^2 - r2^2)
  ;   screen_x = x/2 + 128  (light from right)
  ;   screen_y = (r2/2) * 4/3 + 128  (PAR correction, 256x256 on 4:3 screen)
Draw_Disk_Iter:

Disk_Loop:
  ; r1: get signed byte, abs before squaring
  call xorshift_rnd
  jp  p, Disk_r1_pos
  cpl
  inc a
Disk_r1_pos:
  call Sq8              ; HL = r1^2
  push hl               ; save r1^2

  ; r2: get signed byte, save for screen_y, abs before squaring
  call xorshift_rnd
  ld  (Disk_r2), a      ; save signed r2 (-128..127)
  jp  p, Disk_r2_pos
  cpl
  inc a
Disk_r2_pos:
  call Sq8              ; HL = r2^2

  pop de
  add hl, de            ; HL = r1^2 + r2^2

  ; reject if sum >= 16384 (outside unit disc): H >= 64
  ld  a, h
  cp  64
  jp  nc, Disk_Loop

  ; x = sqrt(16384 - sum)
  push hl
  ld  hl, 16384
  pop de
  ld  a, l              ; HL -= DE  (16384 - sum), byte-wise (no SBC HL,rr on i8080)
  sub e
  ld  l, a
  ld  a, h
  sbc a, d
  ld  h, a
  call IsqrtHL          ; HL = x (0..128), H=0

  ; screen_x = x/2 + 128
  ld  a, l              ; A = x (0..128, unsigned)
  or  a                 ; clear carry (SRL A)
  rra                   ; A = x/2  (0..64)
  add a, 128
  ld  c, a              ; C = screen_x (128..192)
  push bc                ; save screen_x: ScaleY43/Mul8 below clobber B and C

  ; screen_y = (r2/2) * 4/3 + 128  (PAR correction; always in range, no clip needed)
  ld  a, (Disk_r2)
  or  a
  jp  p, Disk_y_abs_pos
  cpl
  inc a
Disk_y_abs_pos:
  ; A = |r2| (0..128)
  or  a
  rra                    ; A = |r2|/2 (0..64), logical shift (unsigned now)
  call ScaleY43           ; A = scaled |r2|/2 * 4/3 (0..85)
  ld  l, a
  ld  h, 0
  ld  a, (Disk_r2)        ; reload original sign (memory untouched by ScaleY43)
  or  a
  jp  p, Disk_y_sign_pos
  ld  a, l                ; negate HL (two's complement)
  cpl
  ld  l, a
  ld  a, h
  cpl
  ld  h, a
  inc hl
Disk_y_sign_pos:
  ld  de, 128
  add hl, de              ; HL = screen_y (43..213, always in range)
  ld  a, l               ; A = screen_y
  pop bc                  ; restore screen_x into C
  ld  b, a               ; B = screen_y

  call PlotPixel

  ret

  ; ------- Stage 2: background stars -------
  ;   x, y = signed random bytes (-128..127)
  ;   filter: x^2 + y^2 > 4352  (outside planet + atmospheric gap)
  ;   screen_x = x + 128         (always 0..255, no clip needed)
  ;   screen_y = y * 4/3 + 128   (PAR correction, clip 0..255; off-screen not counted)
Draw_Stars_Iter:

Stars_Loop:
  ; x: save signed, abs for squaring
  call xorshift_rnd
  ld  (Stars_x), a
  jp  p, Stars_x_pos
  cpl
  inc a
Stars_x_pos:
  call Sq8              ; HL = x^2
  push hl

  ; y: save signed, abs for squaring
  call xorshift_rnd
  ld  (Stars_y), a
  jp  p, Stars_y_pos
  cpl
  inc a
Stars_y_pos:
  call Sq8              ; HL = y^2

  pop de
  add hl, de            ; HL = x^2 + y^2

  ; reject if inside planet gap (x^2+y^2 <= 4352, i.e. < 4353)
  ld  de, 4353
  ld  a, l
  sub e
  ld  l, a
  ld  a, h
  sbc a, d
  ld  h, a
  jp  c, Stars_Loop     ; inside gap: retry, don't count

  ; screen_y = y * 4/3 + 128  (PAR correction), clip 0..255
  ld  a, (Stars_y)
  or  a
  jp  p, Stars_y_abs_pos
  cpl
  inc a
Stars_y_abs_pos:
  call ScaleY43           ; A = scaled |y| * 4/3 (0..170)
  ld  l, a
  ld  h, 0
  ld  a, (Stars_y)        ; reload original sign (memory untouched by ScaleY43)
  or  a
  jp  p, Stars_y_sign_pos
  ld  a, l                ; negate HL (two's complement)
  cpl
  ld  l, a
  ld  a, h
  cpl
  ld  h, a
  inc hl
Stars_y_sign_pos:
  ld  de, 128
  add hl, de              ; HL = scaled_y + 128 (signed 16-bit)
  ld  a, h
  or  a
  jp  m, Stars_Loop        ; negative: off top, retry
  jp  nz, Stars_Loop       ; >= 256: off bottom, retry
  ld  b, l               ; B = screen_y (0..255)

  ; screen_x = x + 128 (result always 0..255, all valid)
  ld  a, (Stars_x)
  add a, 128
  ld  c, a              ; C = screen_x

  call PlotPixel

  ret

  ; ------- Stage 3: rings -------
  ;   r7 = r5>>2,  x = r6+r7,  y = r6
  ;   S = x^2+y^2
  ;   T1 = 17*S/256  (= S>>4 + S>>8, within 2 of exact)
  ;   VAL = T1 - x*y/8;  ring filter: 32 <= VAL < 80
  ;   Occlusion: S >= 4096 -> always plot
  ;               S <  4096 -> only if r5 < 0  (front-facing arc)
  ;   screen_x = x+128           (clip 0..255)
  ;   screen_y = y*4/3+128       (PAR correction, clip 0..255)
Draw_Rings_Iter:

Ring_Loop:
  call xorshift_rnd
  ld   (Ring_r5), a

  call xorshift_rnd
  ld   (Ring_r6), a     ; r6 = y

  ; r7 = r5 >> 2 (arithmetic, two chained SRA emulations)
  ld   a, (Ring_r5)
  ld   d, a
  and  $80
  ld   e, a
  ld   a, d
  or   a
  rra
  or   e                ; A = r5>>1 (arithmetic)
  ld   d, a
  and  $80
  ld   e, a
  ld   a, d
  or   a
  rra
  or   e                ; A = r5>>2 (arithmetic) = r7

  ; x = r6 + r7  (byte; wrap harmless for values that pass ring filter)
  ld   b, a
  ld   a, (Ring_r6)
  add  a, b
  ld   (Ring_x), a

  ; sign of x*y: XOR of sign bits
  ld   c, a
  ld   a, (Ring_r6)
  xor  c
  and  $80
  ld   (Ring_P_neg), a  ; $80 if x*y < 0, else 0

  ; |x|
  ld   a, c
  or   a                ; materialise sign flag (ld does not set flags)
  jp   p, Ring_x_pos
  cpl
  inc  a
Ring_x_pos:
  ld   (Ring_x_abs), a
  call Sq8              ; HL = x^2
  push hl

  ; |y|
  ld   a, (Ring_r6)
  or   a                ; materialise sign flag
  jp   p, Ring_y_pos
  cpl
  inc  a
Ring_y_pos:
  ld   (Ring_y_abs), a
  call Sq8              ; HL = y^2

  pop  de
  add  hl, de           ; HL = S = x^2 + y^2
  ld   (Ring_S), hl

  ; T1 = S>>4 + S>>8
  ld   a, h             ; save S>>8
  ld   d, 0
  ld   e, a             ; DE = S>>8
  ld   a, h             ; HL >>= 4 (logical, 4x SRL H / RR L)
  or   a
  rra
  ld   h, a
  ld   a, l
  rra
  ld   l, a
  ld   a, h
  or   a
  rra
  ld   h, a
  ld   a, l
  rra
  ld   l, a
  ld   a, h
  or   a
  rra
  ld   h, a
  ld   a, l
  rra
  ld   l, a
  ld   a, h
  or   a
  rra
  ld   h, a
  ld   a, l
  rra
  ld   l, a             ; HL = S>>4
  add  hl, de           ; HL = T1
  push hl               ; save T1

  ; |P/8| = |x*y| >> 3
  ld   a, (Ring_x_abs)
  ld   b, a
  ld   a, (Ring_y_abs)
  ld   c, a
  call Mul8             ; HL = |x*y|
  ld   a, h             ; HL >>= 3 (logical, 3x SRL H / RR L)
  or   a
  rra
  ld   h, a
  ld   a, l
  rra
  ld   l, a
  ld   a, h
  or   a
  rra
  ld   h, a
  ld   a, l
  rra
  ld   l, a
  ld   a, h
  or   a
  rra
  ld   h, a
  ld   a, l
  rra
  ld   l, a             ; HL = |P/8|

  ; apply sign to get signed P/8
  ld   a, (Ring_P_neg)
  or   a
  jp   z, Ring_P_pos
  ld   a, l
  cpl
  ld   l, a
  ld   a, h
  cpl
  ld   h, a
  inc  hl               ; two's complement negation
Ring_P_pos:
  ; VAL = T1 - signed_P/8
  ex   de, hl           ; DE = signed P/8
  pop  hl               ; HL = T1
  ld   a, l             ; HL -= DE, byte-wise
  sub  e
  ld   l, a
  ld   a, h
  sbc  a, d
  ld   h, a             ; HL = VAL

  ; ring filter: 32 <= VAL < 80
  ld   a, h
  or   a
  jp   m, Ring_Loop     ; VAL negative (bit 7 of h set)
  jp   nz, Ring_Loop    ; VAL >= 256
  ld   a, l
  cp   32
  jp   c,  Ring_Loop    ; VAL < 32
  cp   80
  jp   nc, Ring_Loop    ; VAL >= 80

  ; occlusion
  ld   hl, (Ring_S)
  ld   de, 4096
  ld   a, l             ; HL -= DE, byte-wise
  sub  e
  ld   l, a
  ld   a, h
  sbc  a, d
  ld   h, a
  jp   nc, Ring_Plot    ; S >= 4096: outside disc, always plot

  ld   a, (Ring_r5)
  or   a
  jp   p, Ring_Loop     ; r5 >= 0: back of planet, skip

Ring_Plot:
  ; screen_y = y * 4/3 + 128  (PAR correction), clip 0..255
  ld   a, (Ring_r6)
  or   a
  jp   p, Ring_y_abs_pos
  cpl
  inc  a
Ring_y_abs_pos:
  call ScaleY43           ; A = scaled |y| * 4/3 (0..170)
  ld   l, a
  ld   h, 0
  ld   a, (Ring_r6)       ; reload original sign (memory untouched by ScaleY43)
  or   a
  jp   p, Ring_y_sign_pos
  ld   a, l               ; negate HL (two's complement)
  cpl
  ld   l, a
  ld   a, h
  cpl
  ld   h, a
  inc  hl
Ring_y_sign_pos:
  ld   de, 128
  add  hl, de             ; HL = scaled_y + 128 (signed 16-bit)
  ld   a, h
  or   a
  jp   m, Ring_Loop        ; negative: off top, retry
  jp   nz, Ring_Loop       ; >= 256: off bottom, retry
  ld   b, l              ; B = screen_y (0..255)

  ; screen_x = x + 128
  ld   a, (Ring_x)
  add  a, 128
  ld   c, a

  call PlotPixel

  ret

; ===========================================================
; In:	BC = coords X/Y
PlotPixel:
	;ld	a, b
	call	L22B1
	ld	d, a
	inc	d
	ld	a, 1
loc_E16C:
	rrca
	dec	d
	jp	nz, loc_E16C
	xor	(hl)
	ld	(hl), a
	ret

; In:	BC = coords X/Y  (B=Y 0..255, C=X 0..255)
; Out:	HL = screen address
;	A = shift 0..7  (bit position within byte, 0=leftmost/MSB, matches
;	    the RRCA-based mask built by PlotPixel)
;
; Vector-06C screen: column-oriented, 32 columns of 256 bytes each.
;   column = X>>3 selects high byte: H = $C0 + column ($C0..$DF)
;   row byte (low byte) counts bottom-to-top: $00=bottom, $FF=top,
;   so for a top-down Y (Y=0 at top, increasing downward): L = 255-Y
;
; Clobbers: A, D, E
L22B1:
	ld	a, c		; A = X
	and	$07
	ld	e, a		; E = shift = X & 7 (0..7)

	ld	a, c		; A = X
	rrca
	rrca
	rrca			; circular rotate right x3: low 3 bits -> top,
	and	$1F		;   mask off the wrapped bits -> A = X>>3 (0..31)
	add	a, $C0
	ld	h, a		; H = $C0 + column

	ld	a, b		; A = Y
	cpl			; A = 255 - Y  (bottom-to-top row byte)
	ld	l, a

	ld	a, e		; A = shift (0..7)
	ret

; ===========================================================
; xorshift_rnd -- 16-bit XORshift PRNG
; Out: A = pseudo-random byte
; Clobbers: A, HL
; Period: 65535
; ===========================================================
xorshift_rnd:
.smc_state:
  ld  hl, 1             ; state (self-modifying, must not be 0)
  ld  a, h
  rra
  ld  a, l
  rra
  xor h
  ld  h, a
  ld  a, l
  rra
  ld  a, h
  rra
  xor l
  ld  l, a
  xor h
  ld  h, a
  ld  (.smc_state+1), hl
  ret
PRNG_SEED EQU .smc_state+1

; ===========================================================
; Sq8 -- unsigned 8x8 -> 16 multiply (used for squaring)
; In:  A = value (0..128)
; Out: HL = A*A (0..16384)
; Clobbers: A, B, C, D, E, H, L
; ===========================================================
Sq8:
  ld  c, a              ; C = multiplier (consumed bit by bit)
  ld  d, 0
  ld  e, a              ; DE = multiplicand (shifts left each step)
  ld  hl, 0             ; HL = accumulator
  ld  b, 8
Sq8_Loop:
  ld  a, c              ; SRL C: LSB of multiplier -> carry (0-fill top)
  or  a
  rra
  ld  c, a
  jp  nc, Sq8_Skip
  add hl, de
Sq8_Skip:
  ld  a, e              ; SLA E / RL D: DE <<= 1
  add a, a
  ld  e, a
  ld  a, d
  rla
  ld  d, a
  dec b
  jp  nz, Sq8_Loop
  ret

; ===========================================================
; IsqrtHL -- digit-by-digit integer square root
; In:  HL = value (0..16384)
; Out: HL = floor(sqrt(value)) (0..128)
; Clobbers: A, B, C, D, E, H, L
; ===========================================================
IsqrtHL:
  ld  de, 0             ; DE = result
  ld  bc, 16384         ; BC = bit, starts at 2^14
Isqrt_Loop:
  ld  a, b
  or  c
  jp  z, Isqrt_Done
  push de               ; save result across T computation
  ld  a, e
  add a, c
  ld  e, a
  ld  a, d
  adc a, b
  ld  d, a              ; DE = result + bit  (= T)
  ld  a, l              ; HL -= DE, byte-wise
  sub e
  ld  l, a
  ld  a, h
  sbc a, d
  ld  h, a
  jp  c, Isqrt_Skip     ; HL < T: skip
  ; HL >= T: update remainder, result = old_result/2 + bit
  pop de
  ld  a, d              ; SRL D / RR E: DE = old_result >> 1
  or  a
  rra
  ld  d, a
  ld  a, e
  rra
  ld  e, a
  ld  a, e
  add a, c
  ld  e, a
  ld  a, d
  adc a, b
  ld  d, a              ; DE = old_result/2 + bit
  jp  Isqrt_Next
Isqrt_Skip:
  add hl, de            ; restore remainder
  pop de
  ld  a, d              ; SRL D / RR E: DE = old_result >> 1
  or  a
  rra
  ld  d, a
  ld  a, e
  rra
  ld  e, a
Isqrt_Next:
  ld  a, b              ; SRL B / RR C, twice: BC >>= 2
  or  a
  rra
  ld  b, a
  ld  a, c
  rra
  ld  c, a
  ld  a, b
  or  a
  rra
  ld  b, a
  ld  a, c
  rra
  ld  c, a
  jp  Isqrt_Loop
Isqrt_Done:
  ld  h, d
  ld  l, e
  ret

; ===========================================================
; ScaleY43 -- multiply unsigned byte by 4/3 (PAR correction)
;   Vector-06C is 256x256 on a 4:3 screen -> PAR = 4/3 (pixels wider
;   than tall), so the Y component must be stretched by 4/3 to look
;   round on screen.
;   Approximation: value*4/3 =~ value*341/256 (341 = 256 + 85, and
;   dividing a 16-bit product by 256 is just taking the high byte).
; In:  A = value (0..128)
; Out: A = floor(value*4/3) approx (0..170)
; Clobbers: A, B, C, D, E, H, L
; ===========================================================
ScaleY43:
  ld  b, a              ; B = value (factor1 for Mul8)
  ld  c, 85             ; C = 85  (341 = 256 + 85)
  push bc                ; save value: Mul8 shifts B down to 0 internally
  call Mul8             ; HL = value*85
  pop bc                  ; B = value restored
  ld  d, b               ; D = value, E = 0 -> DE = value*256
  ld  e, 0
  add hl, de             ; HL = value*341
  ld  a, h               ; A = (value*341) >> 8  = floor(value*4/3) approx
  ret

; ===========================================================
; Mul8 -- unsigned 8x8 -> 16 multiply
; In:  B = factor1, C = factor2 (both 0..255)
; Out: HL = B*C
; Clobbers: A, B, C, D, E, H, L
; ===========================================================
Mul8:
  ld  d, 0
  ld  e, c              ; DE = C (shifts left each step)
  ld  hl, 0             ; accumulator
  ld  c, 8               ; C = loop counter (safe: original C already in E)
Mul8_Loop:
  ld  a, b              ; SRL B: LSB of B -> carry
  or  a
  rra
  ld  b, a
  jp  nc, Mul8_Skip
  add hl, de
Mul8_Skip:
  ld  a, e              ; SLA E / RL D: DE <<= 1
  add a, a
  ld  e, a
  ld  a, d
  rla
  ld  d, a
  dec c
  jp  nz, Mul8_Loop
  ret
