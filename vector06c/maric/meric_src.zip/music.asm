Play:				; CODE XREF: RAM:0162j
		push	hl
		push	de
		push	bc
		push	af
		push	hl
		push	de
		push	bc
		pop	hl
		ld	de, 0
		call	compare_HL_DE
		ld	de, buffer_ch0 ;1B5Eh

;channel 0
		ld	c, 1
		di
		call	nz, play_channel	;0
		pop	hl
		ld	de, 0
		call	compare_HL_DE
		ld	de, buffer_ch1 ;1BDEh
;channel 1
		ld	c, 2
		call	nz, play_channel	;1
		pop	hl
		ld	de, 0
		call	compare_HL_DE
		ld	de, buffer_ch2 ;1C5Eh
;channel 2
		ld	c, 4
		call	nz, play_channel	;2
		ei
		pop	af
		pop	bc
		pop	de
		pop	hl
		ret

; =============== S U B	R O U T	I N E =======================================


play_channel:				
; HL - ABC data, C - channel, DE - buffer 
		ld	a, (music_status)
		or	c
		ld	(music_status), a
		push	hl
		ld	hl, base_buffer
		dec	c
		jp	nz, loc_4C1
		ld	(hl), 0

loc_4C1:				; CODE XREF: play_channel+Cj
		inc	hl
		dec	c
		jp	nz, loc_4C8
		ld	(hl), 0

loc_4C8:				; CODE XREF: play_channel+13j
		inc	hl
		dec	c
		dec	c
		jp	nz, music_loop_init
		ld	(hl), 0

music_loop_init:				; CODE XREF: play_channel+1Bj
		pop	hl
		ld	c, 80h ; buffer size max value = 128 bytes

music_loop:				; CODE XREF: play_channel+2Aj play_channel+31j
		ld	a, (hl)
		cp	20h ; ' '
		jp	nz, music_loop_next
		inc	hl
		jp	music_loop
; ---------------------------------------------------------------------------

music_loop_next:				; CODE XREF: play_channel+26j
		ld	(de), a
		inc	hl
		inc	de
		dec	c
		jp	nz, music_loop
		ret
; End of function play_channel

; ---------------------------------------------------------------------------

loc_4E5:				; CODE XREF: RAM:0159j
		ld	(byte_C1D), a
		ret






; =============== S U B	R O U T	I N E =======================================


play_in_interrupt:

		ld	hl, E45 ;591Eh
		add	hl, bc
		dec	(hl)
		ret	nz
		ld	hl, base_buffer ;5255h
		add	hl, bc
		ld	a, (hl)	; if < 80n
		cp	80h ; '�'
		jp	c, loc_EBA


; =============== S U B	R O U T	I N E =======================================


sub_E8C:				; CODE XREF: RAM:0E71p	play_in_interrupt+56j
		ld	(hl), 0
		ld	hl, E48
		add	hl, bc
		ld	(hl), 5
		ld	hl, E42
		add	hl, bc
		ld	(hl), 4
		push	bc
		ld	a, 7Fh ; ''

loc_E9D:				; CODE XREF: sub_E8C+13j
		rlca
		dec	c
		jp	p, loc_E9D
		ld	hl, music_status
		and	(hl)
		ld	(hl), a
		pop	bc

loc_EA8:				; CODE XREF: play_in_interrupt+CDj play_in_interrupt+D2j
		ld	hl, E45
		add	hl, bc
		ld	(hl), 1

loc_EAE:				; CODE XREF: play_in_interrupt:loc_F51p
		ld	a, c
		inc	a
		cpl
		rrca
		rrca
		and	0C0h ; '�'
		or	30h ; '0'
		out	(8), a
		ret
; End of function sub_E8C

; ---------------------------------------------------------------------------
; START	OF FUNCTION CHUNK FOR play_in_interrupt

loc_EBA:
;base_buffer base_buffer+1 base_buffer+2 offset for byte with note counter
		push	hl	;5257h
		push	hl
		ld	a, c	
;begin loop
		ld	de, 80h	; add 80h up to 3 times
		ld	hl, base_buffer	;5254

loc_EC3:				
		add	hl, de ; add offset for n channel 
		dec	a
		jp	p, loc_EC3
;end loop
		pop	de
		ld	a, (de)
		ld	e, a
		ld	d, 0
		
		add	hl, de
		
		;HL - current addres of music buffer - current note!
		ld	a, (hl)
		or	a
		ex	de, hl
		pop	hl
		jp	z, sub_E8C
		cp	4Ch ; 'L'n
		jp	nz, loc_EF7
		inc	(hl)
		inc	de
		ld	a, (de)
		cp	30h ; '0'
		jp	c, loc_EED
		cp	3Ah ; ':'
		jp	nc, loc_EED
		call	sub_FE0
		jp	loc_EEF
; ---------------------------------------------------------------------------

loc_EED:				; CODE XREF: play_in_interrupt+63j play_in_interrupt+68j
		ld	a, 4

loc_EEF:				; CODE XREF: play_in_interrupt+6Ej
		push	hl
		ld	hl, E42
		add	hl, bc
		ld	(hl), a
		pop	hl
		ld	a, (de)

loc_EF7:				; CODE XREF: play_in_interrupt+5Bj
		cp	4Fh ; 'O'
		jp	nz, loc_F15
		inc	(hl)
		inc	de
		ld	a, (de)
		cp	30h ; '0'
		jp	c, loc_F15
		cp	39h ; '9'
		jp	nc, loc_F15
		push	hl
		ld	hl, E48
		add	hl, bc
		sub	2Fh ; '/'
		ld	(hl), a
		pop	hl
		inc	(hl)
		inc	de
		ld	a, (de)

loc_F15:				; CODE XREF: play_in_interrupt+7Dj play_in_interrupt+85j ...
		inc	(hl)
		inc	de
		push	hl
		push	de
		;in HL address to routine to play music - by ret 
		ld	hl, Play_it
		push	hl
		ld	hl, E4D
		ld	de, 4
		cp	43h ; 'C'
		ret	z
		add	hl, de
		cp	44h ; 'D'
		ret	z
		add	hl, de
		cp	45h ; 'E'
		ret	z
		inc	hl
		inc	hl
		cp	46h ; 'F'
		ret	z
		add	hl, de
		cp	47h ; 'G'
		ret	z
		add	hl, de
		cp	41h ; 'A'
		ret	z
		add	hl, de
		cp	42h ; 'B'
		ret	z
		pop	hl
		pop	de
		pop	hl
		cp	50h ; 'P'
		jp	z, loc_F51
		cp	52h ; 'R'
		jp	nz, loc_EA8
		ld	(hl), 0
		jp	loc_EA8
; ---------------------------------------------------------------------------

loc_F51:				; CODE XREF: play_in_interrupt+C8j
		call	loc_EAE
		jp	loc_F94
; END OF FUNCTION CHUNK	FOR play_in_interrupt
; ---------------------------------------------------------------------------
Play_it:
		pop	de
		ld	a, (de)
		cp	23h ; '#'
		inc	hl
		inc	hl
		jp	z, loc_F6E
		cp	2Bh ; '+'
		jp	z, loc_F6E
		cp	2Dh ; '-'
		dec	hl
		dec	hl
		jp	nz, loc_F72
		dec	hl
		dec	hl

loc_F6E:
		ex	(sp), hl
		inc	(hl)
		ex	(sp), hl
		inc	de

loc_F72:
		ld	(loc_F75+1), hl

loc_F75:
		ld	hl, (E5B)
		push	hl
		ld	hl, E48
		add	hl, bc
		ld	a, (hl)
		pop	hl
		push	bc
		ld	c, a

loc_F81:
		dec	c
		jp	z, loc_F8F
		ld	a, h
		or	a
		rra
		ld	h, a
		ld	a, l
		rra
		ld	l, a
		jp	loc_F81
; ---------------------------------------------------------------------------

loc_F8F:
		pop	bc
		call	loc_FC3
		pop	hl
; START	OF FUNCTION CHUNK FOR play_in_interrupt

loc_F94:				; CODE XREF: play_in_interrupt+D8j
		ld	a, (de)
		cp	30h ; '0'
		jp	c, loc_FA5
		cp	3Ah ; ':'
		jp	nc, loc_FA5
		call	sub_FE0
		jp	loc_FAC
; ---------------------------------------------------------------------------

loc_FA5:				; CODE XREF: play_in_interrupt+11Bj play_in_interrupt+120j
		push	hl
		ld	hl, E42
		add	hl, bc
		ld	a, (hl)
		pop	hl

loc_FAC:				; CODE XREF: play_in_interrupt+126j
		push	hl
		ld	hl, E45
		add	hl, bc
		ld	(hl), a
		ld	a, (de)
		cp	2Eh ; '.'
		ld	a, (hl)
		jp	nz, loc_FC1
		add	a, a
		add	a, (hl)
		or	a
		rra
		ld	(hl), a
		pop	hl
		inc	(hl)
		ret
; ---------------------------------------------------------------------------

loc_FC1:				; CODE XREF: play_in_interrupt+13Aj
		pop	hl
		ret
; END OF FUNCTION CHUNK	FOR play_in_interrupt
; ---------------------------------------------------------------------------

loc_FC3:
		push	af
		ld	a, 9
		add	a, c
		ld	(loc_FD9+1), a
		ld	(loc_FDC+1), a
		ld	a, c
		inc	a
		cpl
		rrca
		rrca
		and	0C0h ; '�'
		or	36h ; '6'
		out	(8), a
		ld	a, l

loc_FD9:
		out	(9), a
		ld	a, h

loc_FDC:
		out	(9), a
		pop	af
		ret

sub_FE0:				; CODE XREF: play_in_interrupt+6Bp play_in_interrupt+123p
		sub	30h ; '0'
		inc	(hl)
		inc	de
		push	bc
		ld	c, a
		ld	a, (de)
		cp	30h ; '0'
		jp	c, loc_FFD
		cp	3Ah ; ':'
		jp	nc, loc_FFD
		sub	30h ; '0'
		ld	b, a
		ld	a, c
		add	a, a
		add	a, a
		add	a, c
		add	a, a
		add	a, b
		ld	c, a
		inc	de
		inc	(hl)

loc_FFD:				; CODE XREF: sub_FE0+9j sub_FE0+Ej
		ld	a, c
		or	1
		rlca
		ld	b, a
		ld	a, 80h ; '�'

loc_1004:				; CODE XREF: sub_FE0+2Aj
		rlca
		ld	c, a
		ld	a, b
		rlca
		ld	b, a
		ld	a, c
		jp	nc, loc_1004
		pop	bc
		ret

compare_HL_DE:
; Compare HL & DE result 0 if equal <> 0 else (in A)
		ld	a, h
		sub	d
		ret	nz
		ld	a, l
		sub	e
		ret
		
		
stop_music:				; CODE XREF: sub_168j
		push	af
		push	bc
		push	hl
		ld	bc, 2

loc_E6D:				; CODE XREF: stop_music+Ej
		ld	hl, base_buffer
		add	hl, bc
		call	sub_E8C
		dec	c
		jp	p, loc_E6D
		pop	hl
		pop	bc
		pop	af
		ret
check_play_status:
		ld	a, (music_status)
		ret
		

byte_C1D:	db 40h			; DATA XREF: RAM:loc_4E5w
		db  80h	; �
		db  20h
		db 0D0h	; �
		db    6
		db  86h	; �
		db  16h
		db  36h	; 6
		db    0
		db 0C5h	; �
		db  22h	; "
		db 0C0h	; �
		db    2
		db  98h	; �
		db  52h	; R
		db 0ADh	; �
;current_time:	defw 0
music_status:	defb    %00000111
base_buffer:	
defb 0,0,0,0
defw 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
defw 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
buffer_ch0:		
defw 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
defw 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
buffer_ch1:		
defw 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
defw 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
buffer_ch2:		
defw 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
defw 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0

byte_F57:		defb 0d1h,01ah
E42:		defw    0808h
E44:		defb    4
E45:		defw    0202h
E47:		defb    1
E48:		defw    0505h
E4A:		defb    5
E4B:
defb 0BDh ; +
E4C:
defb 0D2h ; -
E4D:
defb  2Bh ; +
defb 0B3h ; �
defb  1Ch
defb 0A9h ; �
defb  9Eh ; P
defb  9Fh ; �
defb 0A9h ; �
defb  96h ; �
defb  34h ; 4
defb  8Eh ; �
defb  39h ; 9
defb  86h ; �
defb 0B0h ; �
defb  7Eh ; ~

E5B:		
defw  07794h 
db 0DEh ; �
db  70h ; p
db  88h ; �
db  6Ah ; j
db  8Eh ; �
db  64h ; d
db 0E9h ; T
db  5Eh ; ^
db  95h ; �
db  59h ; Y



