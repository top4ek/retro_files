; Constants used by sprite
debug equ 0

; Direction
stationary    equ 0
horizontal    equ 1
vertical      equ 2

        org 00100h                ; Start at 32768
strint:
        di
        ld a,0c3h
        ld (00000h),a
        ld (00038h),a
        ld hl,strint
        ld (00001h),hl
        ld hl,init
        ld (00039h),hl
        xor a
        out (10h),a
        ld sp,07080h
        call cls


        ei
        halt


        ld hl,sheep               ;copy mirror from
        ld de,sheep + 0400h       ;to
        call spritemirror
        ld hl,sheep + 0100h               ;copy mirror from
        ld de,sheep + 0500h       ;to

        ld hl,mariobig0L0
        ld de,mariobig0L0 + 0400h
        call spritemirror
        ld hl,mariobig0L0 + 0100h
        ld de,mariobig0L0 + 0500h
        call spritemirror
        ld hl,mariobig0L1
        ld de,mariobig0L1 + 0400h
        call spritemirror
        ld hl,mariobig0L1 + 0100h
        ld de,mariobig0L1 + 0500h
        call spritemirror
        ld hl,mario               ;copy mirror from
        ld de,mario + 0400h       ;to
        call spritemirror
        ld hl,mario + 0100h               ;copy mirror from
        ld de,mario + 0500h       ;to
        call spritemirror        
        call intro
        


        ld a,(level)
        ld b,a
        call draw_level
        call message1
        


        ;call redefine
        ;   Draw all sprites to the screen (Needed for XOR to work when removing)





        ;call draw_all_sprites

        ;   Initial setup to determine if more than 4 sprites
        call setup_sprite_counters
        
        ld hl,player
        ld a,(playersprite_small)
        ld (playersprite),a
        ld (player + 10),a
        ld a,0
        ld (player + 9),a
        jp play_music_from_beginning
        
        
intro:
        call setup_sprite_counters
        ld b,0
        call draw_level
        call message3

intro_next:
        ld a,(keycode+1)
        cp JUMPK
        ret z
        
        halt
        halt
        ld hl,player_intro
        ld a,1
        call move_and_animate_sprites

        ld a,(total_sprites_a)

        ld hl,player_intro
        call process_sprites
        
        jp intro_next

        ;    *********************
        ;    THE MAIN LOOP
        ;    *********************
        org 0200h
play_music_from_beginning:
        ;mus_data:
        ld hl,mus_data
        ld a,l
        ld (mus_current),a
        ld a,h
        ld (mus_current+1),a
        ld a,11
        ld (mus_fragment),a

play_next_music_fragment:
        ld a, (mus_current)
        ld l,a
        ld a, (mus_current+1)
        ld h,a
        ld a,(mus_fragment)
        dec a
        ld (mus_fragment),a
        and a
        jp z,play_music_from_beginning
        ld e,(hl)
        inc hl
        ld d,(hl)
        inc hl
        push de
        ld c,(hl)
        inc hl
        ld b,(hl)
        inc hl
        ld e,(hl)
        inc hl
        ld d,(hl)
        inc hl
        ld a,l
        ld (mus_current),a
        ld a,h
        ld (mus_current+1),a
        pop hl
        call Play



main1:
        ; Clear collision flag
        xor a
        ld (collision),a

        ; Process up to the first 4 sprites

        ; This means, remove sprite, get new position and draw sprite

        xor a
        ld (current_sprite),a

        ld hl,get_screen_address+1
        ld (hl),080h
        ld hl,sprites

        ld a,(total_sprites_a)

;wait for interrupt
        halt

;************************************************************************;
;crazy logic with delays to make sprites not flashing
        ld a,(player+1)
        cp 148
        jp nc, exit_delay

        push de
        ld de, 0520h
        call delay
        pop de

exit_delay:
        ld a,(bigsmall)
        and 1
        jp nz,exit_delay_small


exit_delay_big:

        ld a,(total_sprites_a)
        call process_sprites
        ld a,(player+1)
        cp 148
        jp c, exit_delay2

        push de
        ld de, 0180h
        call delay
        pop de

exit_delay2:
        jp delay_exit


exit_delay_small:

        ld a,(total_sprites_a)
        call process_sprites
        ld a,(player+1)
        cp 148
        jp c, exit_delay3

        push de
        ld de, 00400h
        call delay
        pop de
        jp delay_exit

exit_delay3:
        push de
        ld de, 00280h
        call delay
        pop de

delay_exit:

        ld a,(collision)
        and a          ; Player
        jp z,no_collision


        ld a,(jump)
        and a
        jp nz,no_collision

        ld a,(firsttime)
        and a
        jp z,appear_to_die
        dec a
        ld (firsttime),a
        jp no_collision


appear_to_die:
        ld a,(bigsmall)
        and 1
        jp nz,mario_die         ;if he was small he suppose to die
        
        ld a,1                  ;else he is big - make him small
        ld (switch),a

        ld a,3                  ;and let him chanse to go away from enemy
        ld (firsttime),a
        xor a
        ld (collision),a


no_collision:
        ld hl,player
        ld a,0
        ld (switch_bigsmall),a

        ; Want to jump
        ld a,(jump)
        and a
        jp nz,jumping

        ld a,(switch)
        and a
        jp nz,switch_it

        ld a,(keycode)
        cp TABK
        jp nz,no_key

switch_it:
        ld a,0
        ld (switch),a
        ld a,(bigsmall)
        and 1
        jp nz,big
small:
        call switch_small

        jp no_key

big:
        call switch_big

no_key:
        ld hl,player
        ;no key pressed wait with default sprite and turn head
        ld a,(keycode)
        cp 0ffh
        jp nz,kc_next

        xor a
        ld (player + 12),a

        ld a,(CounterINT)
        cp 128
        jp c, mirrorstay

        ld a,(playersprite)
        ld (player + 10),a
        ;call message1
        jp kc_next

mirrorstay:
        ld a,(playersprite)
        add a,4
        ld (player + 10),a
        ;call message2

kc_next:

        ld a,(keycode+1)
        cp JUMPK
        jp nz,kc_left
        
        ld a,(allowjump)
        and a
        jp z,kc_left

        ld a,(playersprite)
        ld (player + 10),a

        ld a,1
        ld (jump),a
        xor a
        ld (jumpcounter),a

jumping:
        ld a,(bigsmall)
        and 1
        jp z,jump_big

jump_small:
        ld a,(playersprite_jump_small)
        ld (player + 10),a

        jp jump_next

jump_big:
        ld a,(playersprite_jump_big)
        ld (player + 10),a

jump_next:

        ld a,(player + 12)
        inc a
        and 3
        ld (player + 12),a

        ld a,(jumpcounter)
        inc a
        ld (jumpcounter),a
        cp 15
        jp nz,jumping2


        xor a
        ld (jumpcounter),a
        ld (jump),a
        jp kc_left

jumping2:                         ;jump scroll
        cp 8
        jp nc,jumping3
        push af
        ld hl,jumpscroll
        ld e,a
        ld d,0
        add hl,de
        ld a,(hl)
        ld (SCROLL),a
        pop af

jumping3:
        ld hl,jumppattern         ;jump pattern
        ld e,a
        push af
        ld d,0
        add hl,de
        ld a,(hl)
        ld e,a
        ld hl,player

        
        ld a,(player + 1)
        add a,e
        ld (player + 1),a
        
        pop af
        ;a - 0 no tile collision
        call check_tile_jump
        and a
        jp z,kc_left

        ;rollback if tile collision
        ld a,(player+1)
        sub e
        ld (player + 1),a

        xor a
        ld (SCROLL),a
        ld (allowjump),a
        ld (jump),a
        ld (jumpcounter),a
        jp wrap_player

        ;jp kc_left

kc_left:
        ld a,(keycode)
        cp LEFTK
        jp nz,kc_right
        
        ld a,(jump)
        and a
        jp nz,left_next

        ld a,(playersprite)
        ld (player + 10),a

left_next:
        
        ld a,(player + 12)
        dec a
        and 3
        ld (player + 12),a

        ld a,(player)
        sub 4
        ld (player),a
        
        ;a - 0 no tile collision
        call check_tile_left
        and a
        jp z,kc_right
        
        ;rollback if tile collision
        ld a,(player)
        add a,4
        ld (player),a


kc_right:
        ld a,(keycode)
        cp RIGHTK
        jp nz,wrap_player
        
        ld a,(jump)
        and a
        jp nz,right_next

        ld a,(playersprite)
        add a,4
        ld (player + 10),a
        jp right_next2

right_next:

        ld a,(bigsmall)
        and 1
        jp z,right_big

right_small:
        ld a,(playersprite_jump_small)
        add a,4
        ld (player + 10),a

        jp right_next2

right_big:
        ld a,(playersprite_jump_big)
        add a,4
        ld (player + 10),a
        

right_next2:
        ld a,(player + 12)
        inc a
        and 3
        ld (player + 12),a


        ld a,(player)
        add a,4
        ld (player),a
        
        ;a - 0 no tile collision
        call check_tile_right
        and a
        jp z,wrap_player
        
        ;rollback if tile collision
        ld a,(player)
        sub 4
        ld (player),a


        cp 240
        jp nz,wrap_player

        ld a,0
        ld (player),a


wrap_player:
        ld a,(jump)
        and a
        jp nz,move_sprites

        ld a,(player + 1)
        add a,8
        ld (player + 1),a
        
        ;a - 0 no tile collision
        call check_tile_down
        and a
        jp z,move_sprites
        
        ;rollback if tile collision
        ld a,(player + 1)
        sub 8
        ld (player + 1),a
        
        ;
        ld a,1
        ld (allowjump),a


move_sprites:
        ;  Then Do ALL movement and animation of sprites
        ld hl,sprites_not_player
        ld a,(total_sprites)
        dec a
        call move_and_animate_sprites

        ;halt

        ;push de
        ;ld de, 0400h
        ;call delay
        ;pop de

        ;   If there are more than 4 sprites, draw 2nd group of sprites
        xor a
        ld (collision),a        

        ld a,(switch_bigsmall)
        push af
        ld a,0
        ld (switch_bigsmall),a
        ld a,(total_sprites_b)
        and a
        jp z,main2


        ld hl,get_screen_address+1
        ld (hl),0a0h

        ld hl,sprites2
        call process_sprites

        ;    **************

        ;    FILL THIS WITH
        ;    PROGRAM CODE

        ;    **************

main2:
         pop af
         ld (switch_bigsmall),a
bebebe:
         call check_play_status
         and a
         jp z,play_next_music_fragment
         jp main1
         
mario_die:
         call stop_music                 ;stop main music to play die effect
         ld bc,music_die
         ld de,music_die
         ld hl,music_die
         call Play
         call mario_die_sub

         jp play_music_from_beginning    ;start level from beginning

mario_die_sub:
         ld hl,get_screen_address+1      ;set base address to 8000h
         ld (hl),080h
         ld a,128
die_loop:
         ld (player+1),a                 ;die animation
         ld a,die/256
         ld (player + 10),a
         ld hl,sprites
         ld a,(total_sprites_a)
         call process_sprites
         halt
         ld a,(player+1)
         add a,4
         cp 240
         jp nz,die_loop
         ld a,0
         ld (player),a
         ld a,208
         ld (player+1),a
         xor a
         ld (collision),a
         ld a,1
         ld (firsttime),a
         ret

DEFB 'WRAP'
wrap:
     defb 1
total_sprites:
              defb 3
total_sprites_a:
              defb 0
total_sprites_b:
              defb 0

;       *************************************
;       On Entry:
;       a = loop counter
;       ix = sprites
;       *************************************

move_and_animate_sprites:
ms1:
        push af
        push hl

        push hl
        inc hl
        inc hl
        ld a,(hl);(ix+2) Direction
        and a
        pop hl
        jp z,ms2         ; If Stationary (0), go to next sprite

        inc hl
        inc hl

        ld a,(hl);(ix+2)
        ; Is Sprite a horizontal one?
        and horizontal
        jp z, ms_vert    ; If not it is vertical

        dec hl
        dec hl

        ld a,(hl);(ix+0) Add speed to x
        inc hl
        inc hl
        inc hl
        add a,(hl);(ix+3)
        dec hl
        dec hl
        dec hl
        ld (hl),a ;(ix+0)

        jp check_max
        inc hl
        inc hl

ms_vert:
        dec hl
        ld a,(hl);(ix+1) Add speed to y
        inc hl
        inc hl
        add a,(hl);(ix+3)
        dec hl
        dec hl
        ld (hl),a ;(ix+1)
        dec hl
check_max:
        push hl
        ld de,14 ;(ix+14)
        add hl,de
        cp (hl) ;  max?
        pop hl
        jp nz,check_min


         push hl
         ld de,3 ;(ix+3)
         add hl,de
         ld b,(hl)
         ld a,0
         sub b
         ld (hl),a
         ld de,7 ;(ix+3)
         add hl,de
         ld a,(hl)
         add a,-4
         ld (hl),a
         pop hl
         jp ms2

check_min:
        push hl
        ld de,15 ;(ix+15)
        add hl,de
        cp (hl) ; min?
        pop hl
        jp nz,ms2

         ; Reverse speed
neg_speed:
         push hl
         ld de,3 ;(ix+3)
         add hl,de
         ld b,(hl)
         ld a,0
         sub b
         ld (hl),a
         ld de,7 ;(ix+3)
         add hl,de
         ld a,(hl)
         add a,4
         ld (hl),a
         pop hl
ms2:
         ; Animate
         ld de,13 ;(ix+13)
         add hl,de
         ld a,(hl)           ; increase animation counter (0-15)
         inc a
         and 15
         ld (hl),a


         dec hl
         dec hl
         cp (hl) ;(ix+11) animation
         jp nz,ms3
         inc hl
         inc hl
         xor a                  ; reset counter to 0
         ld (hl),a ;(ix+13)
         dec hl
         ld a,(hl) ;(ix+12) Increase animation frame
         inc a
         and 3
         ld (hl),a

ms3:
         pop hl
         ld de,16
         add hl,de
         pop af
         dec a
         and a
         jp nz,ms1
         ret

check_tile_jump:
         push af
         ld a,(player)
         ld b,a
         ld a,(player+1)
         ld c,a

         pop af
         cp 8
         jp nc,check_tile_down

         call get_screen_address
         push hl
         ld a,h
         sub 080h               ;base video address
         rra                    ;divide 2 now in a horizontal index (0-15)
         ld b,a
         
         ld a,l
         and %11110000          ;now in a vertical index
         or b                   ;now first 4 bits horizontal, second vertical
         ld hl,(current_level)
         ld b,0
         ld c,a
         add hl,bc
         ld a,(hl)
         cp 11
         call z,create_mushroom

         pop hl
         push af


         ld a,(shift)
         and a
         jp nz,check_tile_up_shifted
         ld a,h
         sub 080h               ;base video address
         inc a
         rra                    ;divide 2 now in a horizontal index (0-15)
         ld b,a
         
         ld a,l

         and %11110000          ;now in a vertical index
         or b                   ;now first 4 bits horizontal, second vertical
         ld hl,(current_level)
         ld b,0
         ld c,a
         add hl,bc
         pop af
         or (hl)
         ;cp 11
         ;call z,create_mushroom

         ret

check_tile_up_shifted:

         ld a,h
         sub 080h               ;base video address
         inc a
         inc a
         rra                    ;divide 2 now in a horizontal index (0-15)
         ld b,a

         ld a,l

         and %11110000          ;now in a vertical index
         or b                   ;now first 4 bits horizontal, second vertical
         ld hl,(current_level)
         ld b,0
         ld c,a
         add hl,bc
         pop af
         or (hl)

         ret

check_tile_down:
         ld a,(player)
         ld b,a
         ld a,(player+1)
         ld c,a

         call get_screen_address
         ld (shift),a
         push hl

         ld a,h
         sub 080h               ;base video address
         rra                    ;divide 2 now in a horizontal index (0-15)
         ld b,a
         
         ld a,l
tile_down_1:                    ;we will update that for 32*16 sprite
         sub 8
         and %11110000          ;now in a vertical index
         or b                   ;now right 4 bits horizontal, left vertical
         ld hl,(current_level)
         ld b,0
         ld c,a
         add hl,bc
         ld a,(hl)


         pop hl
         push af

         ld a,(shift)
         and a
         jp nz,check_tile_down_shifted
         ld a,h
         sub 080h               ;base video address
         inc a
         rra                    ;divide 2 now in a horizontal index (0-15)
         ld b,a
         
         ld a,l
tile_down_2:                    ;we will update that for 32*16 sprite
         sub 8
         and %11110000          ;now in a vertical index
         or b                   ;now first 4 bits horizontal, second vertical
         ld hl,(current_level)
         ld b,0
         ld c,a
         add hl,bc
         pop af
         or (hl)
         cp 17
         call z,remove_mushroom

         ret

check_tile_down_shifted:

         ld a,h
         sub 080h               ;base video address
         inc a
         inc a
         rra                    ;divide 2 now in a horizontal index (0-15)
         ld b,a

         ld a,l
tile_down_3:                    ;we will update that for 32*16 sprite
         sub 8
         and %11110000          ;now in a vertical index
         or b                   ;now first 4 bits horizontal, second vertical
         ld hl,(current_level)
         ld b,0
         ld c,a
         add hl,bc
         pop af
         or (hl)

         ret




check_tile_left:
         ld a,(player)
         ld b,a
         ld a,(player+1)
         ld c,a

         call get_screen_address
         and a
         ret z
         push hl

         ld a,h
         sub 080h               ;base video address
         rra                    ;divide 2 now in a horizontal index (0-15)
         ld b,a

         ld a,l
         and %11110000          ;now in a vertical index
         or b                   ;now first 4 bits hizontal, second vertical
         ld hl,(current_level)
         ld b,0
         ld c,a
         add hl,bc
         ld a,(hl)
         cp 17
         call z,remove_mushroom
         pop hl
         push af

         ld a,(bigsmall)
         and a
         jp nz,check_left
  
         ld a,h
         sub 080h               ;base video address
         rra                    ;divide 2 now in a horizontal index (0-15)
         ld b,a

         ld a,l
         sub 24
         and %11110000          ;now in a vertical index
         or b                   ;now first 4 bits hizontal, second vertical
         ld hl,(current_level)
         ld b,0
         ld c,a
         add hl,bc
         pop af
         or (hl)
         push af


check_left:
         pop af
         ret


check_tile_right:
         ld a,(player)
         ld b,a
         ld a,(player+1)
         ld c,a

         call get_screen_address
         and a
         ret z
         push hl

         ld a,h
         sub 080h               ;base video address
         rra                    ;divide 2 now in a horizontal index (0-15)
         inc a
         and %00001111
         ld b,a

         ld a,l
         and %11110000          ;now in a vertical index
         or b                   ;now first 4 bits hizontal, second vertical
         ld hl,(current_level)
         ld b,0
         ld c,a
         add hl,bc
         ld a,(hl)
         cp 17
         call z,remove_mushroom
         pop hl
         push af

         ld a,(bigsmall)
         and a
         jp nz,check_right

         ld a,h
         sub 080h               ;base video address
         rra                    ;divide 2 now in a horizontal index (0-15)
         inc a
         and %00001111
         ld b,a

         ld a,l
         sub 24
         and %11110000          ;now in a vertical index
         or b                   ;now first 4 bits hizontal, second vertical
         ld hl,(current_level)
         ld b,0
         ld c,a
         add hl,bc
         pop af
         or (hl)
         push af


check_right:
         pop af
         ret


;       *************************************
;       On Entry:
;       a = loop counter
;       ix = sprites
;       *************************************
process_sprites:

aa2:

        push af
        push hl
        push af
        push hl
        ld de,9
        add hl,de
        ld a,(hl)
        and a
        pop hl
        jp nz,sprite1632

        pop af
        inc a

        ld (current_sprite),a


        ld a,(switch_bigsmall)
        and a
        jp nz,rem16
pla16:
        call remove_shifted_sprite
rem16:

        ;    Draw new sprite
        ;push ix
        ;pop hl
        ld b,(hl)
        inc hl
        ld c,(hl)
        call get_screen_address
        push hl
        pop bc

        pop hl

        call draw_shifted_sprite

        ld de,16
        add hl,de
        pop af
        dec a
        and a
        jp nz,aa2
        ret

sprite1632:
        pop af
        inc a
        ld (current_sprite),a

        ld a,(switch_bigsmall)
        and a
        jp nz,rem32
        call remove_shifted_sprite32
rem32:

        ;    Draw new sprite
        ld b,(hl)
        inc hl
        ld c,(hl)
        call get_screen_address
        push hl
        pop bc

        pop hl
        call draw_shifted_sprite32

        ld de,16
        add hl,de
        pop af
        dec a
        and a
        jp nz,aa2



        ret




;       ***********************************
;       PROC: draw_shifted_Sprite(16x16)
;       DESC: Draw a sprite by looking up a pre-shifted
;             table thus avoiding the need to store lots
;             of frames for each pixel column

;       ENTRY:
;             a = 0 to 7 representing offset (Done by Get Screen Address)
;             hl = SCREEN ADDRESS
;             de = SPRITE GRAPHIC ADDRESS


draw_shifted_sprite32:
         ;    Store old address
         ;push hl
         ;pop bc
         ;push ix
         ;pop hl
         ;push de
         ;ld de,16
         ;add hl,de
         ;pop de
         push hl

         inc hl
         inc hl
         inc hl
         inc hl

         ld (hl),c
         inc hl
         ld (hl),b
         inc hl
         ld (hl),a
         
         ;    Draw in new position
         inc hl
         inc hl
         inc hl
         inc hl
         
         ld d,(hl)
         inc hl
         inc hl
         ld e,(hl)

         dec hl
         dec hl
         dec hl
         dec hl
         dec hl
         
         push af
         ld a,e
         rla
         rla
         rla
         rla
         rla
         rla
         ld e,a
         pop af
         
         ld (hl),e
         inc hl
         ld (hl),d
         push bc
         pop hl

         call draw_layer32
         push af
         ld a,010h
         add a,d
         ld d,a

         ld a,h
         add a,020h
         ld h,a
         pop af
         call draw_layer32
         pop hl
         ret


draw_layer32:
         push hl
         push de
         push af
         rla                      ; Multiply a by 2 to allow for 512 byte
                                  ; groups for left and right sides of
                                  ; shifted bytes

         ld b,BYTETAB/256         ; Point B to beginning of 4k Shifted Bytes
         add a,b                  ; Point B to the correct 512 byte block
         ld b,a

         ld a,32                   ; No of Sprite lines to draw
dss132:
         push af                ; Store counter

         ld a,(de)                ; Get Graphic byte
         ld c,a                   ; C = offset for this byte
         ld a,(bc)                ; Get LEFT Shifted Byte
         xor (hl)                 ; XOR with screen
         ld (hl),a                ; Put on screen
         inc h                    ; next Screen column along
         inc b                    ; Point to right bytes
         ld a,(bc)                ; Get RIGHT Shifted byte
         xor (hl)                 ; XOR with screen
         ld (hl),a                ; Put on screen
         dec b                    ; Restore B to correct 512k block
         inc de                   ; Move to next graphic char

         ld a,(de)                ; Get Graphic byte
         ld c,a                   ; C = offset for this byte
         ld a,(bc)                ; Get LEFT Shifted Byte
         xor (hl)                 ; XOR with screen
         ld (hl),a                ; Put on screen
         inc h                    ; next Screen column along
         inc b                    ; Point to right bytes
         ld a,(bc)                ; Get RIGHT Shifted byte
         xor (hl)                 ; XOR with screen
         ld (hl),a                ; Put on screen
         dec b                    ; Restore B to correct 512k block
         inc de                   ; Move to next graphic char


         dec h                    ; Go back to Left Column
         dec h
         ;   Next screen line
         dec l

dss232:
         pop af                ; Get counter back
         dec a                    ; decrease and loop if more lines to draw
         jp nz,dss132

         pop af
         pop de
         pop hl
         ret

         
         
draw_shifted_sprite:
         ;    Store old address
         ;push hl
         ;pop bc
         ;push ix
         ;pop hl
         push hl

         inc hl
         inc hl
         inc hl
         inc hl

         ld (hl),c
         inc hl
         ld (hl),b
         inc hl
         ld (hl),a
         
         ;    Draw in new position
         inc hl
         inc hl
         inc hl
         inc hl

         ld d,(hl)
         inc hl
         inc hl
         ld e,(hl)
         
         dec hl
         dec hl
         dec hl
         dec hl
         dec hl
         
         push af
         ld a,e
         rla
         rla
         rla
         rla
         rla
         rla
         ld e,a
         pop af


         ld (hl),e
         inc hl
         ld (hl),d
         push bc
         pop hl
        

         call draw_layer
         push af
         ld a,32
         add a,e
         ld e,a

         ld a,h
         add a,020h
         ld h,a
         pop af
         call draw_layer
         pop hl
         ret


draw_layer:
         push hl
         push de
         push af
         rla                      ; Multiply a by 2 to allow for 512 byte
                                  ; groups for left and right sides of
                                  ; shifted bytes

         ld b,BYTETAB/256         ; Point B to beginning of 4k Shifted Bytes
         add a,b                  ; Point B to the correct 512 byte block
         ld b,a

         ld a,16                   ; No of Sprite lines to draw
dss1:
         push af                ; Store counter

         ld a,(de)                ; Get Graphic byte
         ld c,a                   ; C = offset for this byte
         ld a,(bc)                ; Get LEFT Shifted Byte
         xor (hl)                 ; XOR with screen
         ld (hl),a                ; Put on screen
         inc h                    ; next Screen column along
         inc b                    ; Point to right bytes
         ld a,(bc)                ; Get RIGHT Shifted byte
         xor (hl)                 ; XOR with screen
         ld (hl),a                ; Put on screen
         dec b                    ; Restore B to correct 512k block
         inc de                   ; Move to next graphic char

         ld a,(de)                ; Get Graphic byte
         ld c,a                   ; C = offset for this byte
         ld a,(bc)                ; Get LEFT Shifted Byte
         xor (hl)                 ; XOR with screen
         ld (hl),a                ; Put on screen
         inc h                    ; next Screen column along
         inc b                    ; Point to right bytes
         ld a,(bc)                ; Get RIGHT Shifted byte
         xor (hl)                 ; XOR with screen
         ld (hl),a                ; Put on screen
         dec b                    ; Restore B to correct 512k block
         inc de                   ; Move to next graphic char


         dec h                    ; Go back to Left Column
         dec h
         ;   Next screen line
         dec l

dss2:
         pop af                ; Get counter back
         dec a                    ; decrease and loop if more lines to draw
         jp nz,dss1

         pop af
         pop de
         pop hl
         ret

;       *************************************
;       On Entry:
;       a = loop counter
;       ix = sprites
;       *************************************

remove_shifted_sprite:

        ;push ix
        ;pop hl
        push hl
        inc hl
        inc hl
        inc hl
        inc hl
        
        ld c, (hl)
        inc hl
        ld b,(hl)
        inc hl
        ld a,(hl)
        inc hl
        ld e,(hl)
        inc hl
        ld d,(hl)
        push bc
        pop hl

         call remove_layer
         push af
         ld a,32
         add a,e
         ld e,a

         ld a,h
         add a,020h
         ld h,a
         pop af
         call remove_layer
         pop hl
         ret
         

remove_layer:
         push hl
         push de
         push af
         rla                      ; Multiply a by 2 to allow for 512 byte
                                  ; groups for left and right sides of
                                  ; shifted bytes

         ld b,BYTETAB/256         ; Point B to beginning of 4k Shifted Bytes
         add a,b                  ; Point B to the correct 512 byte block
         ld b,a

         ld a,16                   ; No of Sprite lines to draw
rss1:
         push af                ; Store counter

         ld a,(de)                ; Get Graphic byte
         ld c,a                   ; C = offset for this byte
         ld a,(bc)                ; Get LEFT Shifted Byte
         xor (hl)                 ; XOR with screen
         ld (hl),a                ; Put on screen

         ; Collison
         ld a,(bc)                ; Get graphic byte
         and (hl)                 ; and it with the part of byte that the graphic overlaps
         jp z,rss1a               ; if zero, no collision.  This allows for pixel perfect

         ld a,(current_sprite)
         ld (collision),a
rss1a
         inc h                    ; next Screen column along
         inc b                    ; Point to right bytes
         ld a,(bc)                ; Get RIGHT Shifted byte
         xor (hl)                 ; XOR with screen
         ld (hl),a                ; Put on screen

rss1b:
         dec b                    ; Restore B to correct 512k block
         inc de                   ; Move to next graphic char

         ld a,(de)                ; Get Graphic byte
         ld c,a                   ; C = offset for this byte
         ld a,(bc)                ; Get LEFT Shifted Byte
         xor (hl)                 ; XOR with screen
         ld (hl),a                ; Put on screen

         ld a,(bc)
         and (hl)
         jp z,rss1c

         ld a,(current_sprite)
         ld (collision),a

rss1c:
         inc h                    ; next Screen column along
         inc b                    ; Point to right bytes

         ld a,(bc)                ; Get RIGHT Shifted byte
         xor (hl)                 ; XOR with screen
         ld (hl),a                ; Put on screen

rss1d:
         dec b       
         
         
                      ; Restore B to correct 512k block
         inc de                   ; Move to next graphic char


         dec h                    ; Go back to Left Column
         dec h

         ;   Next screen line
         dec l

rss2:
         pop af                ; Get counter back
         dec a                    ; decrease and loop if more lines to draw
         jp nz,rss1

         pop af
         pop de
         pop hl
         ret

         

remove_shifted_sprite32:
        ;push ix
        ;pop hl
        push hl
        inc hl
        inc hl
        inc hl
        inc hl

        ld c, (hl)
        inc hl
        ld b,(hl)
        inc hl
        ld a,(hl)
        inc hl
        ld e,(hl)
        inc hl
        ld d,(hl)
        push bc
        pop hl
         call remove_layer32
         push af
         ld a,10h
         add a,d
         ld d,a

         ld a,h
         add a,020h
         ld h,a
         pop af
         call remove_layer32
         pop hl
         ret
         

remove_layer32:
         push hl
         push de
         push af
         rla                      ; Multiply a by 2 to allow for 512 byte
                                  ; groups for left and right sides of
                                  ; shifted bytes

         ld b,BYTETAB/256         ; Point B to beginning of 4k Shifted Bytes
         add a,b                  ; Point B to the correct 512 byte block
         ld b,a

         ld a,32                   ; No of Sprite lines to draw
rss132:
         push af                ; Store counter

         ld a,(de)                ; Get Graphic byte
         ld c,a                   ; C = offset for this byte
         ld a,(bc)                ; Get LEFT Shifted Byte
         xor (hl)                 ; XOR with screen
         ld (hl),a                ; Put on screen

         ; Collison
         ld a,(bc)                ; Get graphic byte
         and (hl)                 ; and it with the part of byte that the graphic overlaps
         jp z,rss1a32               ; if zero, no collision.  This allows for pixel perfect

         ld a,(current_sprite)
         ld (collision),a
rss1a32
         inc h                    ; next Screen column along
         inc b                    ; Point to right bytes
         ld a,(bc)                ; Get RIGHT Shifted byte
         xor (hl)                 ; XOR with screen
         ld (hl),a                ; Put on screen

rss1b32:
         dec b                    ; Restore B to correct 512k block
         inc de                   ; Move to next graphic char

         ld a,(de)                ; Get Graphic byte
         ld c,a                   ; C = offset for this byte
         ld a,(bc)                ; Get LEFT Shifted Byte
         xor (hl)                 ; XOR with screen
         ld (hl),a                ; Put on screen

         ld a,(bc)
         and (hl)
         jp z,rss1c32

         ld a,(current_sprite)
         ld (collision),a

rss1c32:
         inc h                    ; next Screen column along
         inc b                    ; Point to right bytes

         ld a,(bc)                ; Get RIGHT Shifted byte
         xor (hl)                 ; XOR with screen
         ld (hl),a                ; Put on screen

rss1d32:
         dec b

         
                      ; Restore B to correct 512k block
         inc de                   ; Move to next graphic char


         dec h                    ; Go back to Left Column
         dec h

         ;   Next screen line
         dec l

rss232:
         pop af                ; Get counter back
         dec a                    ; decrease and loop if more lines to draw
         jp nz,rss132
         
         pop af
         pop de
         pop hl
         ret




get_screen_address:

          ld h,080H
          ld a,255
          sub c
          ld l,a

          ;ld l,c
          ld a,b

          rra                                 ;div 8
          rra
          rra
          and %00011111

          add a,h
          ld h,a
          ld a,b                              ; a = xpos
          and 7                               ; get the offset (0-7)
          ret

cls:

        ; Fill Screen with 0

        ld hl,08000h
cls_next:
        ld (hl),0
        inc hl
        ld a,h
        and a
        jp nz,cls_next



        ret

setup_sprite_counters:


                ;    IF total_sprites <= 4
        ld a,(total_sprites)
        sub 2
        jp nc,more_than_4

        ;    THEN

        ;    total_sprites_a = total_sprites and total_sprites_b = 0
        ld a,(total_sprites)
        ld (total_sprites_a),a
        xor a
        ld (total_sprites_b),a

        ret

        ;    ELSE

more_than_4:

        ;    a currently equals total_sprites - 5, so add one back and store 4 in a

        ;    e.g:
        ;    if total_sprites = 6 then total_sprites_a=4 and total_sprites_b=2

        inc a
        ld (total_sprites_b),a
        ld a,1
        ld (total_sprites_a),a

        ret

;routine to draw lavel
;b - level number (0-255)
draw_level:
        ld l,0
        ld h,b
        ld de,Lelel0     ;beginning of levels map table
        add hl,de        ;address of level element
        ld de,0          ;d-x position, e-y position
        ld c,16
        ld b,16
        ;store address of current level
        ld (current_level),hl

next_level_element:
        push bc
        ld a,(hl)
        ld b,d
        ld c,e
        call draw_tile
        inc d
        inc hl

        pop bc
        dec c
        jp nz,next_level_element
        ld c,16
        ld d,0
        inc e
        dec b
        jp nz,next_level_element
        ret

;Drow tile routine
;b - x (0-15)
;c - y (0-15)
;a - tile No (0-255)
draw_tile:
          push hl
          push de
          push bc
          ld e,a

          ld hl, 08000h       ;base address of video memory
          ld a,b
          add a,a
          add a,h
          ld h,a
          ld a,c
          rla                  ;* 16
          rla
          rla
          rla
          and %11110000
          ld l,a
          push hl

          ;now in HL video address
          ld h,0
          ld l,e
          add hl,hl             ;* 128
          add hl,hl
          add hl,hl
          add hl,hl
          add hl,hl
          add hl,hl
          add hl,hl
          ld de,M00L0
          add hl,de
          ex de,hl
          pop hl                ;now hl - video, de - tiles

          ld b,16
          ld c,4

next_tile_byte:


          ex de,hl              ;first byte
          ld a,(hl)
          ex de,hl
          ld (hl),a
          inc de
          inc h
          ex de,hl              ;second byte
          ld a,(hl)
          ex de,hl
          ld (hl),a
          inc de
          dec h


          inc l                 ;next byte in column
          dec b
          jp nz,next_tile_byte

          ld b,16
          push de
          ld de, 02000h - 16         ;next video layer offset
          add hl,de
          pop de
          dec c
          jp nz,next_tile_byte
          pop bc
          pop de
          pop hl
          ret

;b - x (0-15)
;c - y (0-15)
;a - tile No (0-255)
;c - left 4 bits y right x
create_mushroom:
           push af
           push de
           ld (hl),10                ;save new tile(bricks) to map
           ld de,16
           add hl,de
           ld (hl),17                ;save mushroom to map
           pop de
           ld hl,(current_level)
           ld a,c
           and %00001111
           ld b,a
           ld a,c
           and %11110000
           rra
           rra
           rra
           rra
           ld c,a
           ld a,10                   ;10 - bricks
           call draw_tile
           inc c
           ld a,17                   ;17 - mushroom
           call draw_tile
           pop af
           ret

remove_mushroom:
           push af
           push hl
           push de
           push bc
           ld (hl),0
           ld hl,(current_level)
           ld a,c
           and %00001111
           ld b,a
           ld a,c
           and %11110000
           rra
           rra
           rra
           rra
           ld c,a
           ld a,0                   ;17 - mushroom
           call draw_tile
           ld a,1
           ld (switch),a
           pop bc
           pop de
           pop hl
           pop af
           ret

switch_big:
            ld a,1
            ld (current_sprite),a
            call remove_shifted_sprite
            ld a,(playersprite_big)
            ld (playersprite),a
            ld (player + 10),a
            ld a,1
            ld (player + 9),a
            ld a,0
            ld (bigsmall),a
            ld a,1
            ld (switch_bigsmall),a
            ld a,(player + 1)
            add a,-16
            ld (player + 1),a
            ld a,24
            ld (tile_down_1+1),a
            ld (tile_down_2+1),a
            ld (tile_down_3+1),a
            ret

switch_small:
            ld a,1
            ld (current_sprite),a
            call remove_shifted_sprite32
            ld a,(playersprite_small)
            ld (playersprite),a
            ld (player + 10),a
            ld a,0
            ld (player + 9),a
            ld a,1
            ld (bigsmall),a
            ld a,1
            ld (switch_bigsmall),a
            ld a,(player + 1)
            add a,16
            ld (player + 1),a
            ld a,8
            ld (tile_down_1+1),a
            ld (tile_down_2+1),a
            ld (tile_down_3+1),a
            ret

DEFB 'COLLISION'
collision:
          defb 0

defb 'CURRENT_SPRITE'

current_sprite:
          defb 0

spstore:
          defw 0000







init:
	push hl
	push de
	push bc
	push af
	ld a,(WRPAL)
	or a
	jp z,NWRPAL
	ld a,088h
	out (00H),a
	ld hl,COLR15
	ld de,0100fh
INIT1:	ld a,e
	out (02h),a
	ld A,(hl)
	out (0CH),a
	out (0CH),a
	out (0CH),a
	out (0CH),a
	out (0CH),a
	dec hl
	out (0CH),a
	dec e
	out (0CH),a
	dec d
	out (0CH),a
	jp nz,INIT1
NWRPAL:	ld a,8AH
	out (00),a
	xor a
	out (03),a
	in a,(2)
	ld (status),a
	ld a,%11111110 ;0FEH
	out (03),a
	in a,(02)
	ld (keycode),a
	ld a,%01111111 ;0FEH
	out (03),a
	in a,(02)
	ld (keycode+1),a
	ld a,88H
	out (00),a
	ld a,(BORDER)
	and 0FH
	out (02),a
	ld a,(SCROLL)
	out (03),a
	xor a
	ld (WRPAL),a
	ld a,(CounterINT)
	inc a
	ld (CounterINT),a
	ld	hl, (current_time)
	inc	hl
	ld	(current_time), hl
	;this is to play music from buffer
	ld	a, (music_status)
	rrca
	rrca
	rrca
	ld	bc, 2
Music_loop:
	rlca
	push	af
	call	c, play_in_interrupt
	pop	af
	dec	c
	jp	p, Music_loop  ; channels 0,1,2   
	pop af
	pop bc
	pop de
	pop hl
	ei
	ret

status:	   defb 0FFH
keycode:   defb 0FFH,0FFH
SCROLL:	   defb 0FFH
WRPAL:	   defb 01H
DOWNK:	   EQU 7FH
JUMPK:	   EQU 7FH
UPK:	   EQU 0DFH
LEFTK:	   EQU 0EFH
RIGHTK:	   EQU 0BFH
TABK:	   EQU 0FEH
LFK:	   EQU 0FDH
DELK:	   EQU 0F7H
CRK:	   EQU 0FBH
CounterINT:	defb 0H
current_time:	defw 0

;Colors   00   000   000
;         blue green red
BORDER:	defb 00H
COLOR:	defb %11011011

COLR1:  defb %00011000    ;E000-FFFF dark green
COLR2:  defb %00111000    ;C000-DFFF green
COLR3:  defb %11111111    ;E000-FFFF & C000-DFFF white
COLR4:  defb %00000111    ;A000-BFFF red
COLR5:  defb %00000111    ;A000-BFFF & E000-FFFF red
COLR6:  defb %11111111    ;A000-BFFF & C000-DFFF red
COLR7:  defb %00000111    ;A000-BFFF,C000-DFFF,E000-FFFF
COLR8:  defb %11000000    ;8000-9FFF green
COLR9:  defb %11000000    ;8000-9FFF & E000-FFFF green
COLR10: defb %11000000    ;8000-9FFF ? C000-DFFF green
COLR11: defb %11000000    ;8000-9FFF,C000-DFFF,E000-FFFF green
COLR12: defb %00111111    ;8000-9FFF,A000-BFFFF yellow
COLR13: defb %00111111    ;8000-9FFF,A000-BFFF,E000-FFFF
COLR14: defb %00111111    ;8000-9FFF,A000-BFFF,C000-DFFF
COLR15: defb %00111111    ;8000-9FFF,A000-9FFF,C000-DFFF,E000-FFFF


;delay de - counter
delay:
             dec de
             ld a,d
             and a
             jp nz,delay
             ret

spritemirror:
             ld a,1
             ld (eo),a
bnext:
             ld b,(hl)
             ld c,0

             ld a,b
             and %10000000
             jp z,b6
             ld a,c
             or %00000001
             ld c,a

b6:
             ld a,b
             and %01000000
             jp z,b5
             ld a,c
             or %00000010
             ld c,a
             
b5:
             ld a,b
             and %00100000
             jp z,b4
             ld a,c
             or %00000100
             ld c,a
             
b4:
             ld a,b
             and %00010000
             jp z,b3
             ld a,c
             or %00001000
             ld c,a
             
b3:
             ld a,b
             and %00001000
             jp z,b2
             ld a,c
             or %00010000
             ld c,a
             
b2:
             ld a,b
             and %00000100
             jp z,b1
             ld a,c
             or %00100000
             ld c,a

b1:
             ld a,b
             and %00000010
             jp z,b0
             ld a,c
             or %01000000
             ld c,a
             
b0:
             ld a,b
             and %00000001
             jp z,bend
             ld a,c
             or %10000000
             ld c,a
bend:
             ld a,(eo)
             and 1
             jp nz,hbyte
lbyte:
             dec e
             ld a,c
             ld (de),a
             inc e
             inc e

             ld a,1
             ld (eo),a
             jp ebyte


hbyte:
             inc e
             ld a,c
             ld (de),a

             ld a,0
             ld (eo),a


ebyte:
             inc l
             
             jp nz, bnext
             ret

eo:	DB 001H

text:
db 'SCORE: 100',128
; de - address of string to print. End of string 128
; b - x(0-31), c - y(0-31)
print:
             ld a,(de)
             and 127
             
             push de              ;address of current character

             sub 32
             ld h,0
             ld l,a
             add hl,hl
             add hl,hl
             add hl,hl

             ld de,FONT
             add hl,de

             push hl              ;address of font
             push bc             
             ld hl, 0c000h
             ld a,c
             rla
             rla
             rla
             ld c,a

             add a,8
             ld c,a
             add hl,bc
             pop bc
             
             ex de,hl
             pop hl
             push bc
             ld b,8
print_loop:
             ld a,(hl)
             ld (de),a
             push de
             ld a,d
             add a,20h
             ld d,a
trick1:
             ld a,(hl)
             nop
             ld (de),a
             pop de

             dec de
             inc hl
             dec b
             jp nz,print_loop
             
             pop bc
             pop de
             inc de
             inc b
             ld a,(de)
             and 128
             ret nz
             jp print
             
message1:
        ld a,03eh
        ld (trick1), a
        ld a,0ffh
        ld (trick1+1), a

        ld de,text1
        ld bc,10*256+21
        call print

        ld de,text2
        ld bc,10*256+19
        call print
        
        ld a,07eh
        ld (trick1), a
        ld a,000h
        ld (trick1+1), a
        
        ld de,text
        ld bc,011dh
        call print
        ret

message3:
        ld a,03eh
        ld (trick1), a
        ld a,0ffh
        ld (trick1+1), a

        ld de,text5
        ld bc,6*256+19
        call print

        ld de,text6
        ld bc,6*256+17
        call print
        
        ld de,text7
        ld bc,6*256+15
        call print


        ret



;    Type Byte   Range            Description
;    ----------------------------------------

;    RW   0      0-255            X Pixel Position of Sprite
;    RW   1      0-192            Y Pixel Position of Sprite
;    RW   2      0=Stationary
;                1=Horizontal     Sprite Type
;                2=Vertical
;    RW   3                       Speed
;    RO   4,5                     Old Screen Address
;    RO   6      0-7              Old X Offset for Graphics
;    RO   7,8                     Old Graphics Address
;    RW   9      0-7              0 bit Size 16x16 - 0 32x16 - 1 1 bit direction 0-left 1-right
;    RW   10                      Address of sprite graphics base/256
;    RW   11                      animation speed delay (count before animating)
;    RW   12     0-7              Current Animation Frame offset
;    RO   13                      animation speed counter
;    RW   14     (0-255)          Max
;    RW   15     (0-255)          Min

;    RO = Read Only
;    RW = Read/Write

;    In theory, 6 bytes are read only so, the packed bytes (uncompressed) could be stored
;    as 10 bytes for a sprite.

;    Sprite offset could be blanked at start, thus needing 9 bytes

;    Sprite Type and and speed delay will be 0-15 so could be stored and then unpacked thus
;    compressing storage before unpacking to memory to 8 bytes per sprite.

;    This means, even if a screen has 8 sprites, that is 64 bytes.

;    However, it would be good to add:
;    SPRITE_TYPE 3 = Horizontal, but when max is hit then gfx start-256, when min hit, gfx=start+256 (allows left and right anims)
;    SPRITE_TYPE 4 = Vertical, but when max is hit then gfx start-256, when min hit, gfx=start+256 (allows left and right anims)

playersprite_small:
defb    mario/256
playersprite_big:
defb     mariobig0L0/256
playersprite_jump_small:
defb    mariojump/256
playersprite_jump_big:
defb     mariobigjump0L0/256
playersprite:
defb     mario/256
bigsmall:
defb     1
switch_bigsmall:
defb     0
switch:
defb     0
level:
defb     1
current_level:
defw     0
shift:
defb     0
allowjump:
defb     1
firsttime:
defb     1

sprites:
player:
defb    0                    ; XPos (0-255)
defb    256-48                    ; YPos
defb    vertical
defb    0
defw    0000                 ; RO
defb    0                    ; RO
defw    0000                 ; RO
defb    0
;defb    mariobig0L0/256             ; Lo Byte
defb    mario/256             ; Lo Byte
defb    1                    ; Animation Speed Delay
defb    1                    ; Frame Offset
defb    0                    ; RO: Animation Speed Counter
defb    160                   ; Max
defb    32                    ; Min

sprites2:
sprites_not_player:
defb    100
defb    208
defb    horizontal
defb    -2
defw    0000
defb    0
defw    0000
defb    0
defb    sheep/256
defb    2
defb    0
defb    0
defb    256-96
defb    80

defb    224
defb    128
defb    horizontal
defb    -1
defw    0000
defb    0
defw    0000
defb    0
defb    sheep/256
defb    2
defb    0
defb    0
defb    240
defb    208

defb    32
defb    128
defb    vertical
defb    -4
defw    0000
defb    0
defw    0000
defb    0
defb    mario/256
defb    2
defb    0
defb    0
defb    240-64
defb    64
player_intro:
defb    100-16
defb    192+16
defb    horizontal
defb    -1
defw    0000
defb    0
defw    0000
defb    1
defb    mariobig0L0/256
defb    2
defb    0
defb    0
defb    256-80
defb    80-16

defb    48
defb    128
defb    horizontal
defb    -2
defw    0000
defb    0
defw    0000
defb    0
defb    sheep/256
defb    2
defb    0
defb    0
defb    240-16
defb    16

defb    48
defb    144
defb    horizontal
defb    -2
defw    0000
defb    0
defw    0000
defb    0
defb    sheep/256
defb    2
defb    0
defb    0
defb    240-16
defb    16

defb    48
defb    160
defb    horizontal
defb    -1
defw    0000
defb    0
defw    0000
defb    0
defb    sheep/256
defb    2
defb    0
defb    0
defb    240-16
defb    16

mus_current:
         defw 0
mus_fragment:
         defb 0
mus_data:
         defw music0_ch1
         defw music0_ch2
         defw music0_ch3

         defw music1_ch1
         defw music1_ch2
         defw music1_ch3
         
         defw music1_ch1
         defw music1_ch2
         defw music1_ch3

         defw music2_ch1
         defw music2_ch2
         defw music2_ch3
         
         defw music2_ch1
         defw music2_ch2
         defw music2_ch3
         
         defw music3_ch1
         defw music3_ch2
         defw music3_ch3

         defw music1_ch1
         defw music1_ch2
         defw music1_ch3
         
         defw music1_ch1
         defw music1_ch2
         defw music1_ch3

         defw music4_ch1
         defw music4_ch2
         defw music4_ch3

         defw music5_ch1
         defw music5_ch2
         defw music5_ch3

;MML created by Stas Bergich from the following source:
;http://ichigos.com/sheets/s (Super Mario Bros. 2 http://ichigos.com/res/getfile.php?id=1413&type=pdf)
music0_ch1:
db 'L4O5E8E8P8E8P8C8E GPO4GP',0
music0_ch2:
db 'L4O4F+8F+8P8F+8P8F+8F+ BPEP',0
music0_ch3:
db 'L4O2D8D8P8D8P8D8D O3GPO1GP',0

music1_ch1:
db 'L4O5CP8O4GP8E P8ABB-8A GO5EGAF8G8 P8EC8D8O4BP8  ',0
music1_ch2:
db 'L4O4EP8CP8O3G O4P8CDD-8C CGBO5CO4A8B8 P8AE8F8DP8',0
music1_ch3:
db 'L4O3GP8EP8C P8FGG-8F EO4CEFD8E8 P8CO3A8B8GP8',0

music2_ch1:
db 'L8O5P4GF+FD+4E PO4G+AO5CPO4AO5CD P4GF+FD+4E PG4GG4P4 L8O5P4GF+FD+4E PO4G+AO5CPO4AO5CD P4E-4PD4PC4P4P2',0
music2_ch2:
db 'L8O5P4ED+DO4B4O5C PO4EFGPO4CEF P4O5ED+DO4B4O5C POO6C4CC4P4 O5P4ED+DO4B4O5C PO4EFGPO4CEF P4A-4PF4P E4P4P2',0
music2_ch3:
db 'L4O2CP8O3G8PO3C O2FP8O3C8CO2F CP8E8PG8O3C8 P2P4O2G CP8O3G8PO3C O2FP8O3C8CO2F CO3A-P8B-P8 O3CP8O2G8GC',0

music3_ch1:
db 'L8O5CCPCPCD4 ECPO4AG2 O5CCPCPCDE P1 L8O5CCPCPCD4 ECPO4AG2 O5EEPEPCE4 G4P4O4G4P4',0
music3_ch2:
db 'L8O4A-A-PA-PA-B-4 GEPEC2 A-A-PA-PA-B-G P1 A-A-PA-PA-B-4 GEPEC2 F+F+PF+PF+F+4 B4P4G4P4',0
music3_ch3:
db 'L4O1A-P8O2E-8PA- GP8C8PO1G A-P8O2E-8PA- GP8C8PO1G A-P8O2E-8PA- GP8C8PO1G O2D8D8P8D8P8D8D GPO1GP',0

music4_ch1:
db 'L4O5E8CO4G8P4G+ A8O5FF8O4AP BO5A8A8AG8F8 E8CO4A8GP4 O5E8CO4G8P4G+ A8O5FF8O4AP B8O5FF8FE8D8 C2P2',0
music4_ch2:
db 'L4O5C8O4AE8P4E+ F8O5CC8O4FP GO5F8F8FE8G8 C8O4AF8EP4 O5C8O4AE8PE+ F8O5CC8O4FP G8O5DD8DC8O4B8 G8EE8CP',0
music4_ch3:
db 'L4O2CP8F+8GO3C O2FFO3C8C8O2F DP8F8GB GGO3C8C8O2G CP8F+8GO3C O2FFO3C8C8O2F G8GG8GA8B8 O3CO2GCP',0

music5_ch1:
db 'L8O5CCPCPCD4 ECPO4AG2 O5CCPCPCDE P4EGO6ECDG L8O5CCPCPCD4 ECPO4AG2',0
music5_ch2:
db 'L8O4A-A-PA-PA-B-4 GEPEC2 A-A-PA-PA-B-G P1 A-A-PA-PA-B-4 GEPEC2',0
music5_ch3:
db 'L4O1A-P8O2E-8PA- GP8C8PO1G A-P8O2E-8PA- GP8C8PO1G A-P8O2E-8PA- GP8C8PO1G',0

music_die:
db 'L32O6BAGFEDCO5BAGFEDC',0

text1:
db 'SUPER  MARIC',128
text2:
db '    & Co',128

text5:
db '  SUPER MARIC & Co',128

text6:
db ' By S.Bergich  2010',128

text7:
db '   for Vector 06C',128


FONT:
incbin "font.bin"

jump:
        defb 0

jumpcounter:
        defb 0
jumppattern:
        defb -16,-16,-16,-16,-16,-16,0,0,0,0,16,16,16,16,16,16
        ;defb -48,-32,-16,-8,-8,-8,0,0,0,0,8,8,8,16,32,48
        ;defb -32,-22,-16,-12,-8,-4,0,0,0,0,4,8,12,16,22,32
        ;defb -12,-8,-6,-4,-2,-1,0,0,0,0,1,2,4,6,8,12
jumpscroll:
        defb 3,7,11,15,11,7,3,0
;org 05000h
include "music.asm"

include "sprites.asm"
org 05000h
BYTETAB:

        include "shifted.asm"
org 06000h
include "tiles.asm"

include "levels.asm"

;       Lookup must lie on a 256 bouundry


end 00100h                ; Tell PASMO to run from 32768
