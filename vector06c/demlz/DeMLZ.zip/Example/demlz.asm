;������������ Z80->��580 ���� ����������, 2008, 2009

		.org	4000h
DEC40:
MS:		push	psw	  ; ldi
		mov	a, m	  ;
		stax	d	  ;
		inx	h	  ;
		inx	d	  ;
		pop	psw	  ;
M0:		lxi	b, 02FFh
M1:		call	ExAfAf
M1X:		add	a
		jnz	M2	  ; jr	  nz, M2
		mov	a, m
		inx	h
		ral
M2:		sta	RestA1+1; rl	  C
		mov	a, c	  ;
		ral	 	  ;
		mov	c, a	  ;
RestA1:	mvi	a,0
		jnc	M1X	  ; jr	  nc, M1X
		call	ExAfAf
		dcr	b	  ; djnz  X2
		jnz	X2
		mov	a, c	  ; sra	  C
		ral	 	  ;
		mov	a, c	  ;
		rar	 	  ;
		mov	c, a	  ;
		mvi	a, 002h
		jc	N1	  ; jr	  c, N1
		inr	a
		inr	c
		jz	N2	  ; jr	  z, N2
		lxi	b, 033Fh
		jmp	M1	  ; jr	  M1
X2:
		dcr	b	  ; djnz  X3
		jnz	X3
		sta	RestA3+1; srl	  C
		mov	a, c	  ;
		ora	a	  ;
		rar	 	  ;
		mov	c, a	  ;
RestA3:	mvi	a,0
		jc	MS	  ; jr	  c, MS
		inr	b
		jmp	M1	  ; jr	  M1
X6:		add	c
N2:		lxi	b, 04FFh
		jmp	M1	  ; jr	  M1
N1:		inr	c
		jnz	M4	  ; jr	  nz, M4
		call	ExAfAf
		inr	b
N5:
		sta	RestA2+1; rr	  C
		mov	a, c	  ;
		rar	 	  ;
		mov	c, a	  ;
		rc
		mov	a, b	  ; rl	  B
		ral	 	  ;
		mov	b, a	  ;
RestA2:	mvi	a,0
		add	a
		jnz	N6	  ; jr	  nz, N6
		mov	a, m
		inx	h
		ral
N6:		jnc	N5	  ; jr	  nc, N5
		call	ExAfAf
		add	b
		mvi	b, 006h
		jmp	M1	  ; jr	  M1
X3:
		dcr	b	  ; djnz  X4
		jnz	X4
		mvi	a, 001h
		jmp	M3	  ; jr	  M3
X4:
		dcr	b	  ; djnz  X5
		jnz	X5
		inr	c
		jnz	M4	  ; jr	  nz, M4
		lxi	b, 051Fh
		jmp	M1	  ; jr	  M1
X5:
		dcr	b	  ; djnz  X6
		jnz	X6
		mov	b, c
M4:		mov	c, m
		inx	h
M3:		dcr	b
		push	h
		mov	l, c
		mov	h, b
		dad	d
		mov	c, a
LdirLoop:	mov	a, m	  ; ldir
		stax	d	  ;
		inx	h	  ;
		inx	d	  ;
		dcr	c	  ;
		jnz	LdirLoop;
		pop	h
		jmp	M0	  ; jr	  M0

ExAfAf:	push	h	  ; ex	  AF, AF'
		push	psw	  ;
AF:		lxi	h,8000h ;
		xthl	 	  ;
		shld	AF+1	  ;
		pop	psw	  ;
		pop	h	  ;
		ret

		.end
