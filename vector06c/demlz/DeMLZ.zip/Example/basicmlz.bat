tasm -85 -b demlz.asm demlz.bin
copy /b demlz.bin+basic25.mlz basic25mlz.bin
tasm -85 -b basicmlz.asm basicmlz.bin
copy /b basicmlz.bin+basic25mlz.bin basicmlz.rom