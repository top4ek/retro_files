		.db 0C3h, 4Eh,0A1h, 22h,0B9h,0B2h,0D5h,0E5h
		.db  4Eh, 23h, 23h, 7Eh, 32h, 9Bh,0A1h,	32h
		.db  3Dh,0A7h, 32h,0CAh,0ACh, 23h, 5Eh,	23h
		.db  56h,0EBh, 22h, 59h,0A0h,0EBh, 23h,	23h
		.db  23h, 5Eh, 23h, 56h, 23h, 22h,0B1h,0B2h
		.db 0E1h, 19h, 46h, 23h, 7Eh, 23h, 32h,	43h
		.db 0A0h, 90h, 32h,0A4h,0B2h, 22h, 55h,0B2h
		.db 0EBh, 68h, 26h,   0, 29h, 29h, 19h,	22h
		.db  9Eh,0B2h, 21h, 27h,   0, 29h, 29h,	19h
		.db  22h,0CFh,0A4h, 22h, 5Dh,0AAh, 22h,0EAh
		.db 0AFh,0EBh, 69h, 26h,   0, 29h, 19h,0E5h
		.db  21h,0E8h, 46h, 11h,   3,0BAh, 19h,0D1h
		.db  19h,0D1h, 22h, 0Bh,0A3h, 22h, 99h,0A8h
		.db  22h, 26h,0AEh, 21h, 7Eh,0B3h, 3Eh,	5Ah
		.db  36h,   0, 23h, 3Dh,0C2h, 70h,0A0h,	32h
		.db 0DCh,0A6h, 32h, 69h,0ACh, 32h,0F5h,0B1h
		.db  32h, 40h,0A5h, 32h,0CEh,0AAh, 32h,	5Bh
		.db 0B0h, 32h, 31h,0A5h, 32h,0BFh,0AAh,	32h
		.db  4Ch,0B0h, 32h,0CFh,0A6h, 32h, 5Ch,0ACh
		.db  32h,0E8h,0B1h, 32h, 57h,0A2h, 32h,0F9h
		.db 0A7h, 32h, 86h,0ADh, 32h,0EBh,0A6h,	32h
		.db  78h,0ACh, 32h,   4,0B2h, 32h, 5Dh,0A6h
		.db  32h,0EBh,0ABh, 32h, 78h,0B1h, 32h,	4Dh
		.db 0A5h, 32h,0DBh,0AAh, 32h, 68h,0B0h,	32h
		.db  1Fh,0A7h, 32h,0ACh,0ACh, 32h, 38h,0B2h
		.db  32h,0E6h,0A5h, 32h, 74h,0ABh, 32h,	  1
		.db 0B1h, 32h,0A6h,0A1h, 32h, 48h,0A7h,	32h
		.db 0D5h,0ACh, 3Eh, 0Fh, 32h, 1Bh,0A5h,	32h
		.db 0A9h,0AAh, 32h, 36h,0B0h, 32h, 1Dh,0A5h
		.db  32h,0ABh,0AAh, 32h, 38h,0B0h, 21h,	  0
		.db    0, 22h,0B3h,0A5h, 22h, 41h,0ABh,	22h
		.db 0CEh,0B0h, 22h, 72h,0A6h, 22h,   0,0ACh
		.db  22h, 8Dh,0B1h, 22h, 25h,0A4h, 22h,0B3h
		.db 0A9h, 22h, 40h,0AFh, 22h, 76h,0A6h,	22h
		.db    4,0ACh, 22h, 91h,0B1h, 22h, 36h,0A4h
		.db  22h, 22h,0A6h, 22h, 10h,0A6h, 22h,0C4h
		.db 0A9h, 22h,0B0h,0ABh, 22h, 9Eh,0ABh,	22h
		.db  51h,0AFh, 22h, 3Dh,0B1h, 22h, 2Bh,0B1h
		.db  24h, 2Ch, 22h, 9Ch,0B3h, 22h,0AAh,0B3h
		.db  22h,0B8h,0B3h,0C3h, 48h,0A1h, 8Eh,	81h
		.db  85h, 9Fh, 99h, 81h, 2Ch,0A0h, 3Eh,	40h
		.db 0EBh,0E3h,0E5h,0C3h, 54h,0B2h,   0,	3Ah
		.db  7Eh,0B3h,0FEh,   7,0CAh, 8Fh,0A1h,	3Eh
		.db    0,0B7h,0CAh, 73h,0A1h, 32h, 3Dh,0A7h
		.db  32h, 9Bh,0A1h, 32h,0CAh,0ACh, 32h,0AAh
		.db 0B3h, 32h, 9Ch,0B3h, 32h,0B8h,0B3h,0AFh
		.db  32h, 58h,0A1h,   1, 0Dh,	0, 21h,	9Bh
		.db 0B3h, 7Eh,0B7h,0C2h, 83h,0A1h, 2Bh,	2Bh
		.db  2Bh, 0Eh, 0Ah, 79h,0D3h, 15h, 7Eh,	70h
		.db 0D3h, 14h, 2Bh, 0Dh,0F2h, 83h,0A1h,0AFh
		.db  32h, 7Eh,0B3h, 21h, 9Ch,0B3h, 35h,0C2h
		.db  1Ah,0A5h, 36h,   3, 23h, 35h,0C2h,	1Ah
		.db 0A5h, 23h, 7Eh, 2Bh, 77h, 3Eh,   0,0B7h
		.db  3Eh,   0,0C2h,0B0h,0A1h, 32h, 1Fh,0A7h
		.db  32h, 4Dh,0A5h, 32h, 40h,0A5h, 32h,	76h
		.db 0A6h, 32h, 77h,0A6h, 3Ah, 5Eh,0A4h,	32h
		.db  53h,0A4h, 23h, 23h, 5Eh, 23h, 56h,	7Ah
		.db 0B3h,0CAh, 70h,0A2h, 3Ah, 7Fh,0B3h,0B7h
		.db 0CAh,0DAh,0A1h, 3Dh, 32h, 7Fh,0B3h,0C3h
		.db  21h,0A4h, 72h, 2Bh, 73h, 23h, 1Ah,	13h
		.db 0FEh,0FFh,0CAh, 56h,0A2h,0FEh, 85h,0D2h
		.db  18h,0A2h,0FEh, 60h,0DAh, 1Eh,0A4h,0CAh
		.db 0CBh,0A4h,0FEh, 61h,0CAh,	7,0A5h,0FEh
		.db  70h,0DAh,0F7h,0A3h,0CAh,0CFh,0A3h,0FEh
		.db  71h,0CAh,0D5h,0A3h,0FEh, 82h,0DAh,0DFh
		.db 0A3h,0CAh,0B0h,0A3h,0FEh, 83h,0CAh,	9Dh
		.db 0A3h,0FEh, 84h,0CAh, 79h,0A3h,0FEh,	85h
		.db 0CAh, 49h,0A3h,0FEh, 86h,0CAh, 63h,0A3h
		.db 0FEh, 87h,0CAh,0F7h,0A2h,0FEh, 88h,0CAh
		.db  32h,0A3h,0FEh, 89h,0CAh,0FEh,0A2h,0FEh
		.db 0CAh,0DAh, 86h,0A2h,0CAh,0A8h,0A3h,0FEh
		.db 0EAh,0DAh,0EAh,0A2h,0CAh, 93h,0A2h,0FEh
		.db 0EBh,0CAh,0DBh,0A2h,0FEh,0FCh,0DAh,0B7h
		.db 0A2h,0CAh,0A6h,0A2h,0FEh,0FDh,0CAh,	7Eh
		.db 0A2h,0FEh,0FFh,0C2h, 1Ah,0A5h, 3Eh,	  0
		.db 0B7h,0CAh, 70h,0A2h, 3Dh, 32h, 57h,0A2h
		.db  87h,0E5h, 6Fh, 26h,   0,	1,0C6h,0B3h
		.db    9, 5Eh, 23h, 56h,0E1h,0C3h,0DAh,0A1h
		.db  21h, 9Ch,0B3h, 3Eh,   1, 77h, 23h,	77h
		.db  32h, 7Eh,0B3h,0C3h, 35h,0A7h, 1Ah,	13h
		.db  32h, 4Dh,0A5h,0C3h,0DAh,0A1h,0D6h,0AAh
		.db  47h, 3Ah, 41h,0A6h, 80h, 32h, 41h,0A6h
		.db 0C3h,0DAh,0A1h, 1Ah, 13h,0B7h,0F2h,	9Ah
		.db 0A2h, 3Ch, 32h,0E6h,0A5h, 1Ah,0FEh,0EAh
		.db 0CAh, 21h,0A4h,0C3h,0DAh,0A1h, 1Ah,	13h
		.db  32h, 1Bh,0A5h, 32h, 1Dh,0A5h, 1Ah,0FEh
		.db 0FCh,0CAh, 21h,0A4h,0C3h,0DAh,0A1h,0E5h
		.db  21h, 82h,0B3h,0CDh,0C2h,0A2h,0E1h,0C3h
		.db 0DAh,0A1h,0D6h,0EBh, 47h, 7Eh,0B7h,0CAh
		.db 0D3h,0A2h, 23h, 35h,0C2h,0D6h,0A2h,	2Bh
		.db  36h,   0,0C9h, 34h, 23h, 70h, 23h,	5Eh
		.db  23h, 56h,0C9h,0E5h, 21h, 82h,0B3h,	36h
		.db    0, 23h, 23h, 73h, 23h, 72h,0E1h,0C3h
		.db 0DAh,0A1h,0D6h,0CAh,0B7h,0CAh,0DAh,0A1h
		.db  3Dh, 32h, 7Fh,0B3h,0C3h, 21h,0A4h,0AFh
		.db  32h, 1Fh,0A7h,0C3h,0DAh,0A1h, 1Ah,0B7h
		.db 0CAh,   8,0A3h,0AFh, 32h, 1Fh,0A7h,	1Ah
		.db  13h,0E5h,	 1, 95h,0BBh, 6Fh, 26h,	  0
		.db  29h,   9, 4Eh, 23h, 46h, 2Ah,0B9h,0B2h
		.db    9, 7Eh, 23h, 22h, 10h,0A6h, 22h,	36h
		.db 0A4h, 4Fh,	 6,   0,   9, 22h, 22h,0A6h
		.db 0E1h, 1Ah,0FEh, 89h,0CAh, 21h,0A4h,0C3h
		.db 0DAh,0A1h, 1Ah,0B7h,0F2h, 38h,0A3h,	3Ch
		.db  32h, 72h,0A6h, 13h, 1Ah,0B7h,0F2h,	42h
		.db 0A3h, 3Ch, 32h, 73h,0A6h, 13h,0C3h,0DAh
		.db 0A1h, 1Ah,0B7h,0F2h, 4Fh,0A3h, 3Ch,	32h
		.db 0EBh,0A6h, 13h, 1Ah, 32h,0E1h,0A6h,	13h
		.db  1Ah, 32h,0CFh,0A6h, 32h,0DCh,0A6h,	13h
		.db 0C3h,0DAh,0A1h,0AFh, 32h,0EBh,0A6h,	32h
		.db 0E1h,0A6h, 32h,0CFh,0A6h, 32h,0DCh,0A6h
		.db  32h, 72h,0A6h, 32h, 73h,0A6h,0C3h,0DAh
		.db 0A1h, 13h, 3Ah, 57h,0A2h,0FEh,   3,0CAh
		.db 0DAh,0A1h, 3Ch, 32h, 57h,0A2h, 3Dh,0E5h
		.db  87h, 6Fh, 26h,   0,   1,0C6h,0B3h,	  9
		.db  73h, 23h, 72h, 1Bh, 1Ah,0CDh,0A9h,0B2h
		.db 0EBh,0E1h,0C3h,0DAh,0A1h, 1Ah, 13h,	32h
		.db  9Bh,0A1h, 32h, 9Ch,0B3h,0C3h,0DAh,0A1h
		.db  1Ah, 13h, 32h, 58h,0A1h,0C3h,0DAh,0A1h
		.db  1Ah, 13h, 23h, 77h, 23h, 1Ah, 13h,	77h
		.db  2Bh, 2Bh, 72h, 2Bh, 73h, 21h,0ACh,0BAh
		.db  22h,0A3h,0B3h, 3Eh,0A9h, 32h,0A7h,0B3h
		.db 0AFh, 32h, 5Eh,0A4h,0C3h, 1Ah,0A5h,	72h
		.db  2Bh, 73h,0C3h, 1Ah,0A5h, 72h, 2Bh,	73h
		.db 0AFh, 32h,0A7h,0B3h,0C3h, 1Ah,0A5h,0D6h
		.db  72h, 32h, 1Bh,0A5h, 1Ah, 13h, 32h,	1Dh
		.db 0A5h, 32h, 31h,0A5h, 1Ah, 13h, 32h,0A8h
		.db 0B3h, 32h, 2Ch,0A5h,0C3h,0DAh,0A1h,0D6h
		.db  61h, 47h, 1Ah, 13h, 32h, 99h,0B3h,0B7h
		.db  78h,0C2h, 0Ah,0A4h,0FEh,	8,0C2h,	0Ah
		.db 0A4h,0AFh, 32h, 1Fh,0A7h, 32h, 9Bh,0B3h
		.db  1Ah,0FEh, 62h,0DAh,0DAh,0A1h,0FEh,	70h
		.db 0D2h,0DAh,0A1h,0C3h, 21h,0A4h, 32h,	5Eh
		.db 0A4h, 72h, 2Bh, 73h, 21h,	0,   0,	22h
		.db 0A1h,0B3h, 3Eh,0A9h, 32h,0A7h,0B3h,	21h
		.db 0ACh,0BAh, 22h,0A3h,0B3h, 21h,0C0h,0BBh
		.db  22h, 10h,0A6h, 21h,0ACh,0BAh, 22h,0B3h
		.db 0A5h,0AFh, 32h,0AAh,0A6h, 21h,   0,	  0
		.db  22h, 67h,0A6h, 3Ah, 4Dh,0A5h,0B7h,0CAh
		.db  1Ah,0A5h, 21h, 24h,   0, 11h,0BDh,0B2h
		.db  29h, 19h, 5Eh, 23h, 56h, 21h, 2Ch,	  0
		.db    1,0BDh,0B2h, 29h,   9, 23h, 7Eh,	2Bh
		.db  6Eh, 0Eh,	 1, 67h,0BAh,0DAh, 7Bh,0A4h
		.db 0C2h, 78h,0A4h, 7Dh,0BBh,0DAh, 7Bh,0A4h
		.db 0EBh, 0Eh,	 0, 7Ch, 2Fh, 67h, 7Dh,	2Fh
		.db  6Fh, 23h, 19h,0E5h, 79h,0B7h,0C2h,	90h
		.db 0A4h, 7Ch, 2Fh, 67h, 7Dh, 2Fh, 6Fh,	23h
		.db  22h, 76h,0A6h,0E1h, 3Ah, 4Dh,0A5h,	2Fh
		.db  3Ch, 5Fh, 16h,0FFh,   6,	0,   4,	19h
		.db 0DAh, 9Eh,0A4h, 79h,0B7h,0CAh,0AFh,0A4h
		.db  7Ch, 2Fh, 67h, 7Dh, 2Fh, 6Fh, 23h,0EBh
		.db  2Ah, 76h,0A6h, 19h, 22h, 76h,0A6h,	78h
		.db  32h, 40h,0A5h, 79h,0B7h,0CAh, 1Ah,0A5h
		.db  3Ah, 4Dh,0A5h, 2Fh, 3Ch, 32h, 4Dh,0A5h
		.db 0C3h, 1Ah,0A5h, 1Ah, 13h,0E5h,   1,	92h
		.db 0BAh, 6Fh, 26h,   0, 29h,	9, 4Eh,	23h
		.db  46h, 2Ah,0B9h,0B2h,   9, 7Eh, 32h,0A7h
		.db 0B3h, 32h,0C4h,0A3h, 32h, 2Bh,0A4h,	23h
		.db  7Eh, 23h, 22h,0A3h,0B3h, 22h,0BEh,0A3h
		.db  22h, 30h,0A4h, 4Fh,   6,	0,   9,	22h
		.db 0B3h,0A5h, 22h, 3Ch,0A4h,0E1h, 1Ah,0FEh
		.db  60h,0CAh, 21h,0A4h,0C3h,0DAh,0A1h,	1Ah
		.db  13h, 2Bh, 2Bh, 77h, 2Bh, 77h, 23h,	23h
		.db  23h, 1Ah,0FEh, 61h,0CAh, 21h,0A4h,0C3h
		.db 0DAh,0A1h, 3Eh, 0Fh,0FEh, 0Fh,0CAh,	3Fh
		.db 0A5h, 3Ah,0A8h,0B3h, 3Dh, 32h,0A8h,0B3h
		.db 0C2h, 3Fh,0A5h, 3Eh, 16h, 32h,0A8h,0B3h
		.db    6,   0, 3Ah, 1Bh,0A5h,0B8h,0D2h,	3Bh
		.db 0A5h,0C6h,	 2, 3Dh, 32h, 1Bh,0A5h,	3Eh
		.db    0,0B7h,0CAh, 59h,0A5h, 3Dh, 32h,	40h
		.db 0A5h, 2Ah, 76h,0A6h, 11h,	0,   0,	7Bh
		.db 0B7h,0F2h, 55h,0A5h, 15h, 19h, 22h,	76h
		.db 0A6h, 3Ah,0A7h,0B3h,0B7h,0C2h, 67h,0A5h
		.db 0AFh, 32h, 96h,0B3h,0C3h, 35h,0A7h,	2Ah
		.db 0A3h,0B3h, 7Eh,0B7h,0C2h,0B8h,0A5h,	3Ah
		.db 0A7h,0B3h, 3Dh, 32h,0A7h,0B3h,0C2h,0B2h
		.db 0A5h, 23h, 7Eh,0FEh,0FFh,0C2h, 60h,0A5h
		.db  23h, 7Eh, 3Dh, 2Ah,0CFh,0A4h, 44h,	4Dh
		.db  6Fh, 26h,	 0, 29h,   9, 4Eh, 23h,	46h
		.db  2Ah,0B9h,0B2h,   9, 7Eh, 32h,0A7h,0B3h
		.db  23h, 7Eh, 23h, 22h,0A3h,0B3h, 4Fh,	  6
		.db    0,   9, 22h,0B3h,0A5h,0AFh, 32h,0AAh
		.db 0A6h, 21h,	 0,   0, 22h, 67h,0A6h,0C3h
		.db  3Fh,0A5h, 21h,0ACh,0BAh, 22h,0A3h,0B3h
		.db  4Eh, 23h, 11h,   0,   0, 79h,0E6h,	10h
		.db 0CAh,0C5h,0A5h, 5Eh, 23h, 79h,0E6h,	  8
		.db 0CAh,0CDh,0A5h, 56h, 23h,0EBh, 22h,	59h
		.db 0A6h,0EBh, 79h,0E6h,   4,0CAh,0DAh,0A5h
		.db  7Eh, 23h, 32h, 43h,0A6h, 79h,0E6h,	  2
		.db 0CAh,0F6h,0A5h, 46h, 23h, 3Eh,   0,	80h
		.db 0F2h,0ECh,0A5h,0AFh,0FEh, 20h,0DAh,0F3h
		.db 0A5h, 3Eh, 1Fh, 32h, 94h,0B3h, 79h,0E6h
		.db    1,0CAh,0FEh,0A5h, 7Eh, 23h, 32h,0A5h
		.db 0A6h, 79h,0E6h, 80h,0CAh,	9,0A6h,	7Eh
		.db  23h, 32h, 5Dh,0A6h, 22h,0A3h,0B3h,	21h
		.db 0C1h,0BBh, 7Ch,0B5h,0CAh, 39h,0A6h,	7Eh
		.db  23h, 22h, 10h,0A6h,0FEh, 80h,0C2h,	31h
		.db 0A6h, 21h,0C0h,0BBh, 22h, 10h,0A6h,	7Eh
		.db 0FEh, 80h,0CAh, 39h,0A6h, 23h, 22h,	10h
		.db 0A6h, 47h, 3Ah, 43h,0A6h, 80h, 32h,	43h
		.db 0A6h, 3Ah, 5Eh,0A4h,0B7h,0CAh, 55h,0A6h
		.db 0C6h,   0,0C6h,   0, 6Fh, 26h,   0,	29h
		.db 0D5h, 11h,0BDh,0B2h, 19h, 5Eh, 23h,	56h
		.db 0EBh, 22h,0A1h,0B3h,0D1h, 2Ah,0A1h,0B3h
		.db    1,   0,	 0,   9,   1,	0,   0,	79h
		.db 0B7h,0F2h, 65h,0A6h,   5,0E5h, 21h,	  0
		.db    0,   9, 22h, 67h,0A6h, 44h, 4Dh,0E1h
		.db    9,   1,	 0,   0,   9,	1,   0,	  0
		.db    9, 22h, 8Eh,0B3h, 3Ah,0A5h,0A6h,	  7
		.db    7,   7,0E6h,   3,0FEh,	2,0DAh,	9Ah
		.db 0A6h, 0Eh,0FFh,0CAh, 90h,0A6h, 0Eh,	  1
		.db  3Ah,0AAh,0A6h, 81h, 32h,0AAh,0A6h,0C3h
		.db  9Dh,0A6h, 32h, 25h,0A7h, 3Ah, 1Bh,0A5h
		.db  2Fh,0E6h, 0Fh, 47h, 3Eh, 1Dh,0E6h,	0Fh
		.db  90h,0C6h,	 0,0F2h,0AFh,0A6h,0AFh,0FEh
		.db  10h,0DAh,0B6h,0A6h, 3Eh, 0Fh, 32h,	96h
		.db 0B3h, 3Ah,0A5h,0A6h,0E6h,0F0h, 0Fh,	0Fh
		.db  0Fh, 0Fh,0E6h,   9,0EEh,	9, 47h,	3Ah
		.db  95h,0B3h,0B0h, 32h, 95h,0B3h, 3Eh,	  1
		.db 0B7h,0CAh,0DBh,0A6h, 3Dh, 32h,0CFh,0A6h
		.db 0C3h,0FAh,0A6h, 3Eh,   1, 32h,0CFh,0A6h
		.db  3Eh,   0,0B7h,0CAh,0FAh,0A6h, 3Dh,	32h
		.db 0E1h,0A6h, 11h,   5,   0, 7Bh,0B7h,0F2h
		.db 0F3h,0A6h, 15h, 2Ah, 72h,0A6h, 19h,	22h
		.db  72h,0A6h, 3Ah, 25h,0A7h,0FEh,   2,0D2h
		.db  1Eh,0A7h,	 6,   0, 3Ah, 95h,0B3h,0E6h
		.db    8,0CAh, 1Ah,0A7h,   4, 3Ah, 5Ah,0A6h
		.db 0B7h,0CAh, 1Ah,0A7h,0FEh, 80h,0D2h,	1Ah
		.db 0A7h,   5, 78h, 32h, 25h,0A7h, 3Eh,	  0
		.db 0B7h,0CAh, 32h,0A7h, 3Eh,	1,0B7h,0CAh
		.db  32h,0A7h, 3Ah, 96h,0B3h,0F6h, 10h,	32h
		.db  96h,0B3h, 32h,0A6h,0A1h, 21h,0AAh,0B3h
		.db  35h,0C2h,0A8h,0AAh, 36h,	3, 23h,	35h
		.db 0C2h,0A8h,0AAh, 23h, 7Eh, 2Bh, 77h,	3Eh
		.db  10h,0B7h, 3Eh,   0,0C2h, 52h,0A7h,	32h
		.db 0ACh,0ACh, 32h,0DBh,0AAh, 32h,0CEh,0AAh
		.db  32h,   4,0ACh, 32h,   5,0ACh, 3Ah,0ECh
		.db 0A9h, 32h,0E1h,0A9h, 23h, 23h, 5Eh,	23h
		.db  56h, 7Ah,0B3h,0CAh, 12h,0A8h, 3Ah,	80h
		.db 0B3h,0B7h,0CAh, 7Ch,0A7h, 3Dh, 32h,	80h
		.db 0B3h,0C3h,0AFh,0A9h, 72h, 2Bh, 73h,	23h
		.db  1Ah, 13h,0FEh,0FFh,0CAh,0F8h,0A7h,0FEh
		.db  85h,0D2h,0BAh,0A7h,0FEh, 60h,0DAh,0ACh
		.db 0A9h,0CAh, 59h,0AAh,0FEh, 61h,0CAh,	95h
		.db 0AAh,0FEh, 70h,0DAh, 85h,0A9h,0CAh,	5Dh
		.db 0A9h,0FEh, 71h,0CAh, 63h,0A9h,0FEh,	82h
		.db 0DAh, 6Dh,0A9h,0CAh, 3Eh,0A9h,0FEh,	83h
		.db 0CAh, 2Bh,0A9h,0FEh, 84h,0CAh,   7,0A9h
		.db 0FEh, 85h,0CAh,0D7h,0A8h,0FEh, 86h,0CAh
		.db 0F1h,0A8h,0FEh, 87h,0CAh, 85h,0A8h,0FEh
		.db  88h,0CAh,0C0h,0A8h,0FEh, 89h,0CAh,	8Ch
		.db 0A8h,0FEh,0CAh,0DAh, 25h,0A8h,0CAh,	36h
		.db 0A9h,0FEh,0EAh,0DAh, 78h,0A8h,0CAh,	3Ah
		.db 0A8h,0FEh,0EBh,0CAh, 69h,0A8h,0FEh,0FCh
		.db 0DAh, 5Eh,0A8h,0CAh, 4Dh,0A8h,0FEh,0FDh
		.db 0CAh, 32h,0A8h,0FEh,0FFh,0C2h,0A8h,0AAh
		.db  3Eh,   0,0B7h,0CAh, 12h,0A8h, 3Dh,	32h
		.db 0F9h,0A7h, 87h,0E5h, 6Fh, 26h,   0,	  1
		.db 0CCh,0B3h,	 9, 5Eh, 23h, 56h,0E1h,0C3h
		.db  7Ch,0A7h, 21h,0AAh,0B3h, 36h,   1,	23h
		.db  36h,   1, 3Ah, 7Eh,0B3h,0F6h,   2,	32h
		.db  7Eh,0B3h,0C3h,0C2h,0ACh,0D6h,0AAh,	47h
		.db  3Ah,0CFh,0ABh, 80h, 32h,0CFh,0ABh,0C3h
		.db  7Ch,0A7h, 1Ah, 13h, 32h,0DBh,0AAh,0C3h
		.db  7Ch,0A7h, 1Ah, 13h,0B7h,0F2h, 41h,0A8h
		.db  3Ch, 32h, 74h,0ABh, 1Ah,0FEh,0EAh,0CAh
		.db 0AFh,0A9h,0C3h, 7Ch,0A7h, 1Ah, 13h,	32h
		.db 0A9h,0AAh, 32h,0ABh,0AAh, 1Ah,0FEh,0FCh
		.db 0CAh,0AFh,0A9h,0C3h, 7Ch,0A7h,0E5h,	21h
		.db  86h,0B3h,0CDh,0C2h,0A2h,0E1h,0C3h,	7Ch
		.db 0A7h,0E5h, 21h, 86h,0B3h, 36h,   0,	23h
		.db  23h, 73h, 23h, 72h,0E1h,0C3h, 7Ch,0A7h
		.db 0D6h,0CAh,0B7h,0CAh, 7Ch,0A7h, 3Dh,	32h
		.db  80h,0B3h,0C3h,0AFh,0A9h,0AFh, 32h,0ACh
		.db 0ACh,0C3h, 7Ch,0A7h, 1Ah,0B7h,0CAh,	96h
		.db 0A8h,0AFh, 32h,0ACh,0ACh, 1Ah, 13h,0E5h
		.db    1, 95h,0BBh, 26h,   0, 6Fh, 29h,	  9
		.db  4Eh, 23h, 46h, 2Ah,0B9h,0B2h,   9,	7Eh
		.db  23h, 22h, 9Eh,0ABh, 22h,0C4h,0A9h,	4Fh
		.db    6,   0,	 9, 22h,0B0h,0ABh,0E1h,	1Ah
		.db 0FEh, 89h,0CAh,0AFh,0A9h,0C3h, 7Ch,0A7h
		.db  1Ah,0B7h,0F2h,0C6h,0A8h, 3Ch, 32h,	  0
		.db 0ACh, 13h, 1Ah,0B7h,0F2h,0D0h,0A8h,	3Ch
		.db  32h,   1,0ACh, 13h,0C3h, 7Ch,0A7h,	1Ah
		.db 0B7h,0F2h,0DDh,0A8h, 3Ch, 32h, 78h,0ACh
		.db  13h, 1Ah, 32h, 6Eh,0ACh, 13h, 1Ah,	32h
		.db  5Ch,0ACh, 32h, 69h,0ACh, 13h,0C3h,	7Ch
		.db 0A7h,0AFh, 32h, 78h,0ACh, 32h, 6Eh,0ACh
		.db  32h, 5Ch,0ACh, 32h, 69h,0ACh, 32h,	  0
		.db 0ACh, 32h,	 1,0ACh,0C3h, 7Ch,0A7h,	13h
		.db  3Ah,0F9h,0A7h,0FEh,   3,0CAh, 7Ch,0A7h
		.db  3Ch, 32h,0F9h,0A7h, 3Dh,0E5h, 87h,	6Fh
		.db  26h,   0,	 1,0CCh,0B3h,	9, 73h,	23h
		.db  72h, 1Bh, 1Ah,0CDh,0A9h,0B2h,0EBh,0E1h
		.db 0C3h, 7Ch,0A7h, 1Ah, 13h, 32h, 3Dh,0A7h
		.db  32h,0AAh,0B3h,0C3h, 7Ch,0A7h, 1Ah,	13h
		.db  32h, 58h,0A1h,0C3h, 7Ch,0A7h, 1Ah,	13h
		.db  23h, 77h, 23h, 1Ah, 13h, 77h, 2Bh,	2Bh
		.db  72h, 2Bh, 73h, 21h,0CFh,0BAh, 22h,0B1h
		.db 0B3h, 3Eh,0E7h, 32h,0B5h,0B3h,0AFh,	32h
		.db 0ECh,0A9h,0C3h,0A8h,0AAh, 72h, 2Bh,	73h
		.db 0C3h,0A8h,0AAh, 72h, 2Bh, 73h,0AFh,	32h
		.db 0B5h,0B3h,0C3h,0A8h,0AAh,0D6h, 72h,	32h
		.db 0A9h,0AAh, 1Ah, 13h, 32h,0ABh,0AAh,	32h
		.db 0BFh,0AAh, 1Ah, 13h, 32h,0B6h,0B3h,	32h
		.db 0BAh,0AAh,0C3h, 7Ch,0A7h,0D6h, 61h,	47h
		.db  1Ah, 13h, 32h, 99h,0B3h,0B7h, 78h,0C2h
		.db  98h,0A9h,0FEh,   8,0C2h, 98h,0A9h,0AFh
		.db  32h,0ACh,0ACh, 32h, 9Bh,0B3h, 1Ah,0FEh
		.db  62h,0DAh, 7Ch,0A7h,0FEh, 70h,0D2h,	7Ch
		.db 0A7h,0C3h,0AFh,0A9h, 32h,0ECh,0A9h,	72h
		.db  2Bh, 73h, 21h,   0,   0, 22h,0AFh,0B3h
		.db  3Eh,0E7h, 32h,0B5h,0B3h, 21h,0CFh,0BAh
		.db  22h,0B1h,0B3h, 21h,   0,	0, 22h,	9Eh
		.db 0ABh, 21h,0CFh,0BAh, 22h, 41h,0ABh,0AFh
		.db  32h, 38h,0ACh, 21h,   0,	0, 22h,0F5h
		.db 0ABh, 3Ah,0DBh,0AAh,0B7h,0CAh,0A8h,0AAh
		.db  21h, 1Dh,	 0, 11h,0BDh,0B2h, 29h,	19h
		.db  5Eh, 23h, 56h, 21h, 1Bh,	0,   1,0BDh
		.db 0B2h, 29h,	 9, 23h, 7Eh, 2Bh, 6Eh,	0Eh
		.db    1, 67h,0BAh,0DAh,   9,0AAh,0C2h,	  6
		.db 0AAh, 7Dh,0BBh,0DAh,   9,0AAh,0EBh,	0Eh
		.db    0, 7Ch, 2Fh, 67h, 7Dh, 2Fh, 6Fh,	23h
		.db  19h,0E5h, 79h,0B7h,0C2h, 1Eh,0AAh,	7Ch
		.db  2Fh, 67h, 7Dh, 2Fh, 6Fh, 23h, 22h,	  4
		.db 0ACh,0E1h, 3Ah,0DBh,0AAh, 2Fh, 3Ch,	5Fh
		.db  16h,0FFh,	 6,   0,   4, 19h,0DAh,	2Ch
		.db 0AAh, 79h,0B7h,0CAh, 3Dh,0AAh, 7Ch,	2Fh
		.db  67h, 7Dh, 2Fh, 6Fh, 23h,0EBh, 2Ah,	  4
		.db 0ACh, 19h, 22h,   4,0ACh, 78h, 32h,0CEh
		.db 0AAh, 79h,0B7h,0CAh,0A8h,0AAh, 3Ah,0DBh
		.db 0AAh, 2Fh, 3Ch, 32h,0DBh,0AAh,0C3h,0A8h
		.db 0AAh, 1Ah, 13h,0E5h,   1, 92h,0BAh,	26h
		.db    0, 6Fh, 29h,   9, 4Eh, 23h, 46h,	2Ah
		.db 0B9h,0B2h,	 9, 7Eh, 32h,0B5h,0B3h,	32h
		.db  52h,0A9h, 32h,0B9h,0A9h, 23h, 7Eh,	23h
		.db  22h,0B1h,0B3h, 22h, 4Ch,0A9h, 22h,0BEh
		.db 0A9h, 4Fh,	 6,   0,   9, 22h, 41h,0ABh
		.db  22h,0CAh,0A9h,0E1h, 1Ah,0FEh, 60h,0CAh
		.db 0AFh,0A9h,0C3h, 7Ch,0A7h, 1Ah, 13h,	2Bh
		.db  2Bh, 77h, 2Bh, 77h, 23h, 23h, 23h,	1Ah
		.db 0FEh, 61h,0CAh,0AFh,0A9h,0C3h, 7Ch,0A7h
		.db  3Eh, 0Fh,0FEh, 0Fh,0CAh,0CDh,0AAh,	3Ah
		.db 0B6h,0B3h, 3Dh, 32h,0B6h,0B3h,0C2h,0CDh
		.db 0AAh, 3Eh,	 7, 32h,0B6h,0B3h,   6,	0Fh
		.db  3Ah,0A9h,0AAh,0B8h,0D2h,0C9h,0AAh,0C6h
		.db    2, 3Dh, 32h,0A9h,0AAh, 3Eh,   0,0B7h
		.db 0CAh,0E7h,0AAh, 3Dh, 32h,0CEh,0AAh,	2Ah
		.db    4,0ACh, 11h,   0,   0, 7Bh,0B7h,0F2h
		.db 0E3h,0AAh, 15h, 19h, 22h,	4,0ACh,	3Ah
		.db 0B5h,0B3h,0B7h,0C2h,0F5h,0AAh,0AFh,	32h
		.db  97h,0B3h,0C3h,0C2h,0ACh, 2Ah,0B1h,0B3h
		.db  7Eh,0B7h,0C2h, 46h,0ABh, 3Ah,0B5h,0B3h
		.db  3Dh, 32h,0B5h,0B3h,0C2h, 40h,0ABh,	23h
		.db  7Eh,0FEh,0FFh,0C2h,0EEh,0AAh, 23h,	7Eh
		.db  3Dh, 2Ah, 5Dh,0AAh, 44h, 4Dh, 26h,	  0
		.db  6Fh, 29h,	 9, 4Eh, 23h, 46h, 2Ah,0B9h
		.db 0B2h,   9, 7Eh, 32h,0B5h,0B3h, 23h,	7Eh
		.db  23h, 22h,0B1h,0B3h, 4Fh,	6,   0,	  9
		.db  22h, 41h,0ABh,0AFh, 32h, 38h,0ACh,	21h
		.db    0,   0, 22h,0F5h,0ABh,0C3h,0CDh,0AAh
		.db  21h,0CFh,0BAh, 22h,0B1h,0B3h, 4Eh,	23h
		.db  11h,   0,	 0, 79h,0E6h, 10h,0CAh,	53h
		.db 0ABh, 5Eh, 23h, 79h,0E6h,	8,0CAh,	5Bh
		.db 0ABh, 56h, 23h,0EBh, 22h,0E7h,0ABh,0EBh
		.db  79h,0E6h,	 4,0CAh, 68h,0ABh, 7Eh,	23h
		.db  32h,0D1h,0ABh, 79h,0E6h,	2,0CAh,	84h
		.db 0ABh, 46h, 23h, 3Eh,   0, 80h,0F2h,	7Ah
		.db 0ABh,0AFh,0FEh, 20h,0DAh, 81h,0ABh,	3Eh
		.db  1Fh, 32h, 94h,0B3h, 79h,0E6h,   1,0CAh
		.db  8Ch,0ABh, 7Eh, 23h, 32h, 33h,0ACh,	79h
		.db 0E6h, 80h,0CAh, 97h,0ABh, 7Eh, 23h,	32h
		.db 0EBh,0ABh, 22h,0B1h,0B3h, 21h,   0,	  0
		.db  7Ch,0B5h,0CAh,0C7h,0ABh, 7Eh, 23h,	22h
		.db  9Eh,0ABh,0FEh, 80h,0C2h,0BFh,0ABh,	21h
		.db    0,   0, 22h, 9Eh,0ABh, 7Eh,0FEh,	80h
		.db 0CAh,0C7h,0ABh, 23h, 22h, 9Eh,0ABh,	47h
		.db  3Ah,0D1h,0ABh, 80h, 32h,0D1h,0ABh,	3Ah
		.db 0ECh,0A9h,0B7h,0CAh,0E3h,0ABh,0C6h,	  0
		.db 0C6h,   0, 6Fh, 26h,   0, 29h,0D5h,	11h
		.db 0BDh,0B2h, 19h, 5Eh, 23h, 56h,0EBh,	22h
		.db 0AFh,0B3h,0D1h, 2Ah,0AFh,0B3h,   1,	  0
		.db    0,   9,	 1,   0,   0, 79h,0B7h,0F2h
		.db 0F3h,0ABh,	 5,0E5h, 21h,	0,   0,	  9
		.db  22h,0F5h,0ABh, 44h, 4Dh,0E1h,   9,	  1
		.db    0,   0,	 9,   1,   0,	0,   9,	22h
		.db  90h,0B3h, 3Ah, 33h,0ACh,	7,   7,	  7
		.db 0E6h,   3,0FEh,   2,0DAh, 28h,0ACh,	0Eh
		.db 0FFh,0CAh, 1Eh,0ACh, 0Eh,	1, 3Ah,	38h
		.db 0ACh, 81h, 32h, 38h,0ACh,0C3h, 2Bh,0ACh
		.db  32h,0B2h,0ACh, 3Ah,0A9h,0AAh, 2Fh,0E6h
		.db  0Fh, 47h, 3Eh, 20h,0E6h, 0Fh, 90h,0C6h
		.db    0,0F2h, 3Dh,0ACh,0AFh,0FEh, 10h,0DAh
		.db  44h,0ACh, 3Eh, 0Fh, 32h, 97h,0B3h,	3Ah
		.db  33h,0ACh,0E6h,0F0h, 0Fh, 0Fh, 0Fh,0E6h
		.db  12h,0EEh, 12h, 47h, 3Ah, 95h,0B3h,0B0h
		.db  32h, 95h,0B3h, 3Eh,   0,0B7h,0CAh,	68h
		.db 0ACh, 3Dh, 32h, 5Ch,0ACh,0C3h, 87h,0ACh
		.db  3Eh,   0, 32h, 5Ch,0ACh, 3Eh,   0,0B7h
		.db 0CAh, 87h,0ACh, 3Dh, 32h, 6Eh,0ACh,	11h
		.db    0,   0, 7Bh,0B7h,0F2h, 80h,0ACh,	15h
		.db  2Ah,   0,0ACh, 19h, 22h,	0,0ACh,	3Ah
		.db 0B2h,0ACh,0FEh,   2,0D2h,0ABh,0ACh,	  6
		.db    0, 3Ah, 95h,0B3h,0E6h, 10h,0CAh,0A7h
		.db 0ACh,   4, 3Ah,0E8h,0ABh,0B7h,0CAh,0A7h
		.db 0ACh,0FEh, 80h,0D2h,0A7h,0ACh,   5,	78h
		.db  32h,0B2h,0ACh, 3Eh, 0Ah,0B7h,0CAh,0BFh
		.db 0ACh, 3Eh,	 1,0B7h,0CAh,0BFh,0ACh,	3Ah
		.db  97h,0B3h,0F6h, 10h, 32h, 97h,0B3h,	32h
		.db  48h,0A7h, 21h,0B8h,0B3h, 35h,0C2h,	35h
		.db 0B0h, 36h,	 3, 23h, 35h,0C2h, 35h,0B0h
		.db  23h, 7Eh, 2Bh, 77h, 3Eh,	0,0B7h,	3Eh
		.db    0,0C2h,0DFh,0ACh, 32h, 38h,0B2h,	32h
		.db  68h,0B0h, 32h, 5Bh,0B0h, 32h, 91h,0B1h
		.db  32h, 92h,0B1h, 3Ah, 79h,0AFh, 32h,	6Eh
		.db 0AFh, 23h, 23h, 5Eh, 23h, 56h, 7Ah,0B3h
		.db 0CAh, 9Fh,0ADh, 3Ah, 81h,0B3h,0B7h,0CAh
		.db    9,0ADh, 3Dh, 32h, 81h,0B3h,0C3h,	3Ch
		.db 0AFh, 72h, 2Bh, 73h, 23h, 1Ah, 13h,0FEh
		.db 0FFh,0CAh, 85h,0ADh,0FEh, 85h,0D2h,	47h
		.db 0ADh,0FEh, 60h,0DAh, 39h,0AFh,0CAh,0E6h
		.db 0AFh,0FEh, 61h,0CAh, 22h,0B0h,0FEh,	70h
		.db 0DAh, 12h,0AFh,0CAh,0EAh,0AEh,0FEh,	71h
		.db 0CAh,0F0h,0AEh,0FEh, 82h,0DAh,0FAh,0AEh
		.db 0CAh,0CBh,0AEh,0FEh, 83h,0CAh,0B8h,0AEh
		.db 0FEh, 84h,0CAh, 94h,0AEh,0FEh, 85h,0CAh
		.db  64h,0AEh,0FEh, 86h,0CAh, 7Eh,0AEh,0FEh
		.db  87h,0CAh, 12h,0AEh,0FEh, 88h,0CAh,	4Dh
		.db 0AEh,0FEh, 89h,0CAh, 19h,0AEh,0FEh,0CAh
		.db 0DAh,0B2h,0ADh,0DAh,0C3h,0AEh,0FEh,0EAh
		.db 0DAh,   5,0AEh,0CAh,0C7h,0ADh,0FEh,0EBh
		.db 0CAh,0F6h,0ADh,0FEh,0FCh,0DAh,0EBh,0ADh
		.db 0CAh,0DAh,0ADh,0FEh,0FDh,0CAh,0BFh,0ADh
		.db 0FEh,0FFh,0C2h, 35h,0B0h, 3Eh,   1,0B7h
		.db 0CAh, 9Fh,0ADh, 3Dh, 32h, 86h,0ADh,	87h
		.db 0E5h, 6Fh, 26h,   0,   1,0D2h,0B3h,	  9
		.db  5Eh, 23h, 56h,0E1h,0C3h,	9,0ADh,	21h
		.db 0B8h,0B3h, 36h,   1, 23h, 36h,   1,	3Ah
		.db  7Eh,0B3h,0F6h,   4, 32h, 7Eh,0B3h,0C3h
		.db  4Eh,0B2h,0D6h,0AAh, 47h, 3Ah, 5Ch,0B1h
		.db  80h, 32h, 5Ch,0B1h,0C3h,	9,0ADh,	1Ah
		.db  13h, 32h, 68h,0B0h,0C3h,	9,0ADh,	1Ah
		.db  13h,0B7h,0F2h,0CEh,0ADh, 3Ch, 32h,	  1
		.db 0B1h, 1Ah,0FEh,0EAh,0CAh, 3Ch,0AFh,0C3h
		.db    9,0ADh, 1Ah, 13h, 32h, 36h,0B0h,	32h
		.db  38h,0B0h, 1Ah,0FEh,0FCh,0CAh, 3Ch,0AFh
		.db 0C3h,   9,0ADh,0E5h, 21h, 8Ah,0B3h,0CDh
		.db 0C2h,0A2h,0E1h,0C3h,   9,0ADh,0E5h,	21h
		.db  8Ah,0B3h, 36h,   0, 23h, 23h, 73h,	23h
		.db  72h,0E1h,0C3h,   9,0ADh,0D6h,0CAh,0B7h
		.db 0CAh,   9,0ADh, 3Dh, 32h, 81h,0B3h,0C3h
		.db  3Ch,0AFh,0AFh, 32h, 38h,0B2h,0C3h,	  9
		.db 0ADh, 1Ah,0B7h,0CAh, 23h,0AEh,0AFh,	32h
		.db  38h,0B2h, 1Ah, 13h,0E5h,	1, 95h,0BBh
		.db  26h,   0, 6Fh, 29h,   9, 4Eh, 23h,	46h
		.db  2Ah,0B9h,0B2h,   9, 7Eh, 23h, 22h,	2Bh
		.db 0B1h, 22h, 51h,0AFh, 4Fh,	6,   0,	  9
		.db  22h, 3Dh,0B1h,0E1h, 1Ah,0FEh, 89h,0CAh
		.db  3Ch,0AFh,0C3h,   9,0ADh, 1Ah,0B7h,0F2h
		.db  53h,0AEh, 3Ch, 32h, 8Dh,0B1h, 13h,	1Ah
		.db 0B7h,0F2h, 5Dh,0AEh, 3Ch, 32h, 8Eh,0B1h
		.db  13h,0C3h,	 9,0ADh, 1Ah,0B7h,0F2h,	6Ah
		.db 0AEh, 3Ch, 32h,   4,0B2h, 13h, 1Ah,	32h
		.db 0FAh,0B1h, 13h, 1Ah, 32h,0E8h,0B1h,	32h
		.db 0F5h,0B1h, 13h,0C3h,   9,0ADh,0AFh,	32h
		.db    4,0B2h, 32h,0FAh,0B1h, 32h,0E8h,0B1h
		.db  32h,0F5h,0B1h, 32h, 8Dh,0B1h, 32h,	8Eh
		.db 0B1h,0C3h,	 9,0ADh, 13h, 3Ah, 86h,0ADh
		.db 0FEh,   3,0CAh,   9,0ADh, 3Ch, 32h,	86h
		.db 0ADh, 3Dh,0E5h, 87h, 6Fh, 26h,   0,	  1
		.db 0D2h,0B3h,	 9, 73h, 23h, 72h, 1Bh,	1Ah
		.db 0CDh,0A9h,0B2h,0EBh,0E1h,0C3h,   9,0ADh
		.db  1Ah, 13h, 32h,0CAh,0ACh, 32h,0B8h,0B3h
		.db 0C3h,   9,0ADh, 1Ah, 13h, 32h, 58h,0A1h
		.db 0C3h,   9,0ADh, 1Ah, 13h, 23h, 77h,	23h
		.db  1Ah, 13h, 77h, 2Bh, 2Bh, 72h, 2Bh,	73h
		.db  21h,0ACh,0BAh, 22h,0BFh,0B3h, 3Eh,0A9h
		.db  32h,0C3h,0B3h,0AFh, 32h, 79h,0AFh,0C3h
		.db  35h,0B0h, 72h, 2Bh, 73h,0C3h, 35h,0B0h
		.db  72h, 2Bh, 73h,0AFh, 32h,0C3h,0B3h,0C3h
		.db  35h,0B0h,0D6h, 72h, 32h, 36h,0B0h,	1Ah
		.db  13h, 32h, 38h,0B0h, 32h, 4Ch,0B0h,	1Ah
		.db  13h, 32h,0C4h,0B3h, 32h, 47h,0B0h,0C3h
		.db    9,0ADh,0D6h, 61h, 47h, 1Ah, 13h,	32h
		.db  99h,0B3h,0B7h, 78h,0C2h, 25h,0AFh,0FEh
		.db    8,0C2h, 25h,0AFh,0AFh, 32h, 38h,0B2h
		.db  32h, 9Bh,0B3h, 1Ah,0FEh, 62h,0DAh,	  9
		.db 0ADh,0FEh, 70h,0D2h,   9,0ADh,0C3h,	3Ch
		.db 0AFh, 32h, 79h,0AFh, 72h, 2Bh, 73h,	21h
		.db    0,   0, 22h,0BDh,0B3h, 3Eh,0A9h,	32h
		.db 0C3h,0B3h, 21h,0ACh,0BAh, 22h,0BFh,0B3h
		.db  21h,0C0h,0BBh, 22h, 2Bh,0B1h, 21h,0ACh
		.db 0BAh, 22h,0CEh,0B0h,0AFh, 32h,0C5h,0B1h
		.db  21h,   0,	 0, 22h, 82h,0B1h, 3Ah,	68h
		.db 0B0h,0B7h,0CAh, 35h,0B0h, 21h, 24h,	  0
		.db  11h,0BDh,0B2h, 29h, 19h, 5Eh, 23h,	56h
		.db  21h, 2Ch,	 0,   1,0BDh,0B2h, 29h,	  9
		.db  23h, 7Eh, 2Bh, 6Eh, 0Eh,	1, 67h,0BAh
		.db 0DAh, 96h,0AFh,0C2h, 93h,0AFh, 7Dh,0BBh
		.db 0DAh, 96h,0AFh,0EBh, 0Eh,	0, 7Ch,	2Fh
		.db  67h, 7Dh, 2Fh, 6Fh, 23h, 19h,0E5h,	79h
		.db 0B7h,0C2h,0ABh,0AFh, 7Ch, 2Fh, 67h,	7Dh
		.db  2Fh, 6Fh, 23h, 22h, 91h,0B1h,0E1h,	3Ah
		.db  68h,0B0h, 2Fh, 3Ch, 5Fh, 16h,0FFh,	  6
		.db    0,   4, 19h,0DAh,0B9h,0AFh, 79h,0B7h
		.db 0CAh,0CAh,0AFh, 7Ch, 2Fh, 67h, 7Dh,	2Fh
		.db  6Fh, 23h,0EBh, 2Ah, 91h,0B1h, 19h,	22h
		.db  91h,0B1h, 78h, 32h, 5Bh,0B0h, 79h,0B7h
		.db 0CAh, 35h,0B0h, 3Ah, 68h,0B0h, 2Fh,	3Ch
		.db  32h, 68h,0B0h,0C3h, 35h,0B0h, 1Ah,	13h
		.db 0E5h,   1, 92h,0BAh, 6Fh, 26h,   0,	29h
		.db    9, 4Eh, 23h, 46h, 2Ah,0B9h,0B2h,	  9
		.db  7Eh, 32h,0C3h,0B3h, 32h,0DFh,0AEh,	32h
		.db  46h,0AFh, 23h, 7Eh, 23h, 22h,0BFh,0B3h
		.db  22h,0D9h,0AEh, 22h, 4Bh,0AFh, 4Fh,	  6
		.db    0,   9, 22h,0CEh,0B0h, 22h, 57h,0AFh
		.db 0E1h, 1Ah,0FEh, 60h,0CAh, 3Ch,0AFh,0C3h
		.db    9,0ADh, 1Ah, 13h, 2Bh, 2Bh, 77h,	2Bh
		.db  77h, 23h, 23h, 23h, 1Ah,0FEh, 61h,0CAh
		.db  3Ch,0AFh,0C3h,   9,0ADh, 3Eh, 0Fh,0FEh
		.db  0Fh,0CAh, 5Ah,0B0h, 3Ah,0C4h,0B3h,	3Dh
		.db  32h,0C4h,0B3h,0C2h, 5Ah,0B0h, 3Eh,	16h
		.db  32h,0C4h,0B3h,   6,   0, 3Ah, 36h,0B0h
		.db 0B8h,0D2h, 56h,0B0h,0C6h,	2, 3Dh,	32h
		.db  36h,0B0h, 3Eh,   0,0B7h,0CAh, 74h,0B0h
		.db  3Dh, 32h, 5Bh,0B0h, 2Ah, 91h,0B1h,	11h
		.db    0,   0, 7Bh,0B7h,0F2h, 70h,0B0h,	15h
		.db  19h, 22h, 91h,0B1h, 3Ah,0C3h,0B3h,0B7h
		.db 0C2h, 82h,0B0h,0AFh, 32h, 98h,0B3h,0C3h
		.db  4Eh,0B2h, 2Ah,0BFh,0B3h, 7Eh,0B7h,0C2h
		.db 0D3h,0B0h, 3Ah,0C3h,0B3h, 3Dh, 32h,0C3h
		.db 0B3h,0C2h,0CDh,0B0h, 23h, 7Eh,0FEh,0FFh
		.db 0C2h, 7Bh,0B0h, 23h, 7Eh, 3Dh, 2Ah,0EAh
		.db 0AFh, 44h, 4Dh, 26h,   0, 6Fh, 29h,	  9
		.db  4Eh, 23h, 46h, 2Ah,0B9h,0B2h,   9,	7Eh
		.db  32h,0C3h,0B3h, 23h, 7Eh, 23h, 22h,0BFh
		.db 0B3h, 4Fh,	 6,   0,   9, 22h,0CEh,0B0h
		.db 0AFh, 32h,0C5h,0B1h, 21h,	0,   0,	22h
		.db  82h,0B1h,0C3h, 5Ah,0B0h, 21h,0ACh,0BAh
		.db  22h,0BFh,0B3h, 4Eh, 23h, 11h,   0,	  0
		.db  79h,0E6h, 10h,0CAh,0E0h,0B0h, 5Eh,	23h
		.db  79h,0E6h,	 8,0CAh,0E8h,0B0h, 56h,	23h
		.db 0EBh, 22h, 74h,0B1h,0EBh, 79h,0E6h,	  4
		.db 0CAh,0F5h,0B0h, 7Eh, 23h, 32h, 5Eh,0B1h
		.db  79h,0E6h,	 2,0CAh, 11h,0B1h, 46h,	23h
		.db  3Eh,   0, 80h,0F2h,   7,0B1h,0AFh,0FEh
		.db  20h,0DAh, 0Eh,0B1h, 3Eh, 1Fh, 32h,	94h
		.db 0B3h, 79h,0E6h,   1,0CAh, 19h,0B1h,	7Eh
		.db  23h, 32h,0C0h,0B1h, 79h,0E6h, 80h,0CAh
		.db  24h,0B1h, 7Eh, 23h, 32h, 78h,0B1h,	22h
		.db 0BFh,0B3h, 21h,0C1h,0BBh, 7Ch,0B5h,0CAh
		.db  54h,0B1h, 7Eh, 23h, 22h, 2Bh,0B1h,0FEh
		.db  80h,0C2h, 4Ch,0B1h, 21h,0C0h,0BBh,	22h
		.db  2Bh,0B1h, 7Eh,0FEh, 80h,0CAh, 54h,0B1h
		.db  23h, 22h, 2Bh,0B1h, 47h, 3Ah, 5Eh,0B1h
		.db  80h, 32h, 5Eh,0B1h, 3Ah, 79h,0AFh,0B7h
		.db 0CAh, 70h,0B1h,0C6h,   0,0C6h,   0,	6Fh
		.db  26h,   0, 29h,0D5h, 11h,0BDh,0B2h,	19h
		.db  5Eh, 23h, 56h,0EBh, 22h,0BDh,0B3h,0D1h
		.db  2Ah,0BDh,0B3h,   1,   0,	0,   9,	  1
		.db    0,   0, 79h,0B7h,0F2h, 80h,0B1h,	  5
		.db 0E5h, 21h,	 0,   0,   9, 22h, 82h,0B1h
		.db  44h, 4Dh,0E1h,   9,   1,	4,   0,	  9
		.db    1,   0,	 0,   9, 22h, 92h,0B3h,	3Ah
		.db 0C0h,0B1h,	 7,   7,   7,0E6h,   3,0FEh
		.db    2,0DAh,0B5h,0B1h, 0Eh,0FFh,0CAh,0ABh
		.db 0B1h, 0Eh,	 1, 3Ah,0C5h,0B1h, 81h,	32h
		.db 0C5h,0B1h,0C3h,0B8h,0B1h, 32h, 3Eh,0B2h
		.db  3Ah, 36h,0B0h, 2Fh,0E6h, 0Fh, 47h,	3Eh
		.db  1Dh,0E6h, 0Fh, 90h,0C6h,	0,0F2h,0CAh
		.db 0B1h,0AFh,0FEh, 10h,0DAh,0D1h,0B1h,	3Eh
		.db  0Fh, 32h, 98h,0B3h, 3Ah,0C0h,0B1h,0E6h
		.db 0F0h, 0Fh, 0Fh,0E6h, 24h,0EEh, 24h,	47h
		.db  3Ah, 95h,0B3h,0B0h, 32h, 95h,0B3h,	3Eh
		.db    1,0B7h,0CAh,0F4h,0B1h, 3Dh, 32h,0E8h
		.db 0B1h,0C3h, 13h,0B2h, 3Eh,	1, 32h,0E8h
		.db 0B1h, 3Eh,	 0,0B7h,0CAh, 13h,0B2h,	3Dh
		.db  32h,0FAh,0B1h, 11h,   5,	0, 7Bh,0B7h
		.db 0F2h, 0Ch,0B2h, 15h, 2Ah, 8Dh,0B1h,	19h
		.db  22h, 8Dh,0B1h, 3Ah, 3Eh,0B2h,0FEh,	  2
		.db 0D2h, 37h,0B2h,   6,   0, 3Ah, 95h,0B3h
		.db 0E6h, 20h,0CAh, 33h,0B2h,	4, 3Ah,	75h
		.db 0B1h,0B7h,0CAh, 33h,0B2h,0FEh, 80h,0D2h
		.db  33h,0B2h,	 5, 78h, 32h, 3Eh,0B2h,	3Eh
		.db    0,0B7h,0CAh, 4Bh,0B2h, 3Eh,   1,0B7h
		.db 0CAh, 4Bh,0B2h, 3Ah, 98h,0B3h,0F6h,	10h
		.db  32h, 98h,0B3h, 32h,0D5h,0ACh, 3Ah,	7Eh
		.db 0B3h,0FEh,	 7,0C0h, 11h,0F6h,0B9h,0AFh
		.db  32h,0E6h,0A5h, 32h, 74h,0ABh, 32h,	  1
		.db 0B1h, 32h,0A6h,0A1h, 32h, 48h,0A7h,	32h
		.db 0D5h,0ACh, 1Ah, 32h, 41h,0A6h, 32h,0CFh
		.db 0ABh, 32h, 5Ch,0B1h, 3Eh,0F8h,0D3h,	22h
		.db  13h, 1Ah,0CDh,0A9h,0B2h, 22h, 9Fh,0B3h
		.db  13h, 1Ah,0CDh,0A9h,0B2h, 22h,0ADh,0B3h
		.db  13h, 1Ah,0CDh,0A9h,0B2h, 22h,0BBh,0B3h
		.db  13h,0EBh, 22h, 55h,0B2h, 3Ah, 43h,0A0h
		.db  3Dh, 32h, 43h,0A0h,0C0h, 21h, 56h,0BAh
		.db  22h, 55h,0B2h, 3Eh, 0Fh, 32h, 43h,0A0h
		.db 0C9h, 21h,	 0,   0,0B7h,0C8h, 3Dh,	6Fh
		.db    1,   9,0B4h, 29h,   9, 4Eh, 23h,	46h
		.db  21h,   0,0B4h,   9,0C9h,0F8h, 0Eh,	10h
		.db  0Eh, 60h, 0Dh, 80h, 0Ch,0D8h, 0Bh,	28h
		.db  0Bh, 88h, 0Ah,0F0h,   9, 60h,   9,0E0h
		.db    8, 58h,	 8,0E0h,   7, 7Ch,   7,	  8
		.db    7,0B0h,	 6, 40h,   6,0ECh,   5,	94h
		.db    5, 44h,	 5,0F8h,   4,0B0h,   4,	70h
		.db    4, 2Ch,	 4,0F0h,   3,0BEh,   3,	84h
		.db    3, 58h,	 3, 20h,   3,0F6h,   2,0CAh
		.db    2,0A2h,	 2, 7Ch,   2, 58h,   2,	38h
		.db    2, 16h,	 2,0F8h,   1,0DFh,   1,0C2h
		.db    1,0ACh,	 1, 90h,   1, 7Bh,   1,	65h
		.db    1, 51h,	 1, 3Eh,   1, 2Ch,   1,	1Ch
		.db    1, 0Bh,	 1,0FCh,   0,0EFh,   0,0E1h
		.db    0,0D6h,	 0,0C8h,   0,0BDh,   0,0B2h
		.db    0,0A8h,	 0, 9Fh,   0, 96h,   0,	8Eh
		.db    0, 85h,	 0, 7Eh,   0, 77h,   0,	70h
		.db    0, 6Bh,	 0, 64h,   0, 5Eh,   0,	59h
		.db    0, 54h,	 0, 4Fh,   0, 4Bh,   0,	47h
		.db    0, 42h,	 0, 3Fh,   0, 3Bh,   0,	38h
		.db    0, 35h,	 0, 32h,   0, 2Fh,   0,	2Ch
		.db    0, 2Ah,	 0, 27h,   0, 25h,   0,	23h
		.db    0, 21h,	 0, 1Fh,   0, 1Dh,   0,	1Ch
		.db    0, 1Ah,	 0, 19h,   0, 17h,   0,	16h
		.db    0, 15h,	 0, 13h,   0, 12h,   0,	11h
		.db    0, 10h,	 0, 0Fh,   0,	0,   0,	  0
		.db    0,   0,	 1,   1, 94h,0B6h,   0,	  0
		.db    0,   0,	 1,   1, 94h,0B6h, 2Ch,	  1
		.db  20h,   3, 30h,   1,   0, 3Ah, 0Dh,	10h
		.db  0Dh,   0,	 0,   0,   1,	3,   4,	95h
		.db 0B6h, 2Ch,	 1,0B8h,0BAh,	0,   0,0A9h
		.db  16h,   0,	 1, 0Fh, 20h, 7Ch,0B6h,	20h
		.db    3,0D1h,0BAh,   0,   0,0B2h,   7,	  0
		.db    1,   3,	 4, 95h,0B6h, 2Ch,   1,0B8h
		.db 0BAh,   0,	 0,0A9h, 16h,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,0E1h,0B5h,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
		.db    0,   0,	 0,   0,   0,	0,   0,	  0
