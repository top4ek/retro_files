mkdir examples
for /f "delims=" %%i in ('dir /a-d/b/s rmp\*.rmp') do copy /b RMPPlayer.bin+"%%i" examples\"%%~ni.rom"