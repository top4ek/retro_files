tasm -85 -b IndianVecBIOS.asm indian.bin
copy /b indian.bin+logo.bin+indian.pgt+indian.ct indian.rom