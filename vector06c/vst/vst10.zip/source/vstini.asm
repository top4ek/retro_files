		.org	100h

		di
		xra	a
		out	10h
		lxi	h,Test
		lxi	d,8000h
		lxi	b,3683
Loop:
		mov	a,m
		inx	h
		stax	d
		inx	d
		dcx	b
		mov	a,b
		ora	c
		jnz	Loop

Test:

		.end