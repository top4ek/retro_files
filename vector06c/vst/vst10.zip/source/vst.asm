;Vector Speed Test 1.0
;���� ����������, ���
;���� �������� ���������� ��������� ������ ��580��80
;����� ����� ��������� �� ��580��1, 1821��85 � Z80
;������ ��� ��8000 - 06.02.2009
;������ ��� ������� - 24-26.10.2009
;������������� � TASM - A Table Driven Cross Assembler for the MSDOS* Environment (tasm 3.01 ��� 3.2)

TestAdr	.equ	38h
Stack	.equ	0FFF0h
LowStack	.equ	8E80h
BaseComCount	.equ	10894

		.org	08000h

Begin:
Start:
		di
		xra	a
		out	10h
		mvi	a,0C3h
		sta	0
		lxi	h,8000h
		shld	1
		dcx	h
		mvi	m,76h
		mvi	b,16
ClrRam:
		dcx	h
		mvi	m,0
		dcr	b
		jnz	ClrRam
		lxi	sp,Stack
		lxi	h,TestDataInit
		lxi	d,TestAdr
		mvi	b,TestDataInitEnd-TestDataInit
move:	mov	a,m
		stax	d
		inx	h
		inx	d
		dcr	b
		jnz	move

;INX
		lxi	h,TestDataInx
		call	GenTestData1
		lxi	h,AdrToCount1
		shld	AdrToCount+1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextInx+7
		call	Byte2HEX
		shld	TextInx+5
;ADCA
		lxi	h,TestDataAdca
		call	GenTestData1
;		lxi	h,AdrToCount1
;		shld	AdrToCount+1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextAdca+7
		call	Byte2HEX
		shld	TextAdca+5
;ADCM
		lxi	h,TestDataAdcm
		call	GenTestData1
;		lxi	h,AdrToCount1
;		shld	AdrToCount+1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextAdcm+7
		call	Byte2HEX
		shld	TextAdcm+5
;CMA
		lxi	h,TestDataCma
		call	GenTestData1
;		lxi	h,AdrToCount1
;		shld	AdrToCount+1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextCma+7
		call	Byte2HEX
		shld	TextCma+5
;CMC
		lxi	h,TestDataCmc
		call	GenTestData1
;		lxi	h,AdrToCount1
;		shld	AdrToCount+1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextCmc+7
		call	Byte2HEX
		shld	TextCmc+5
;DAA
		lxi	h,TestDataDaa
		call	GenTestData1
;		lxi	h,AdrToCount1
;		shld	AdrToCount+1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextDaa+7
		call	Byte2HEX
		shld	TextDaa+5
;DAD
		lxi	h,TestDataDad
		call	GenTestData1
;		lxi	h,AdrToCount1
;		shld	AdrToCount+1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextDad+7
		call	Byte2HEX
		shld	TextDad+5
;EI
		lxi	h,TestDataEi
		call	GenTestData1
;		lxi	h,AdrToCount1
;		shld	AdrToCount+1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextEi+7
		call	Byte2HEX
		shld	TextEi+5
;ADDA
		lxi	h,TestDataAdda
		call	GenTestData1
;		lxi	h,AdrToCount1
;		shld	AdrToCount+1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextAdda+7
		call	Byte2HEX
		shld	TextAdda+5
;ADDM
		lxi	h,TestDataAddm
		call	GenTestData1
;		lxi	h,AdrToCount1
;		shld	AdrToCount+1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextAddm+7
		call	Byte2HEX
		shld	TextAddm+5
;ANAA
		lxi	h,TestDataAnaa
		call	GenTestData1
;		lxi	h,AdrToCount1
;		shld	AdrToCount+1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextAnaa+7
		call	Byte2HEX
		shld	TextAnaa+5
;ANAM
		lxi	h,TestDataAnam
		call	GenTestData1
;		lxi	h,AdrToCount1
;		shld	AdrToCount+1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextAnam+7
		call	Byte2HEX
		shld	TextAnam+5
;DCRA
		lxi	h,TestDataDcra
		call	GenTestData1
;		lxi	h,AdrToCount1
;		shld	AdrToCount+1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextDcra+7
		call	Byte2HEX
		shld	TextDcra+5
;DCRM
		lxi	h,TestDataDcrm
		call	GenTestData1
;		lxi	h,AdrToCount1
;		shld	AdrToCount+1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextDcrm+7
		call	Byte2HEX
		shld	TextDcrm+5
;DCX
		lxi	h,TestDataDcx
		call	GenTestData1
;		lxi	h,AdrToCount1
;		shld	AdrToCount+1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextDcx+7
		call	Byte2HEX
		shld	TextDcx+5
;INRA
		lxi	h,TestDataInra
		call	GenTestData1
;		lxi	h,AdrToCount1
;		shld	AdrToCount+1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextInra+7
		call	Byte2HEX
		shld	TextInra+5
;INRM
		lxi	h,TestDataInrm
		call	GenTestData1
;		lxi	h,AdrToCount1
;		shld	AdrToCount+1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextInrm+7
		call	Byte2HEX
		shld	TextInrm+5
;LDAX
		lxi	h,TestDataLdax
		call	GenTestData1
;		lxi	h,AdrToCount1
;		shld	AdrToCount+1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextLdax+7
		call	Byte2HEX
		shld	TextLdax+5
;MOVA
		lxi	h,TestDataMova
		call	GenTestData1
;		lxi	h,AdrToCount1
;		shld	AdrToCount+1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextMova+7
		call	Byte2HEX
		shld	TextMova+5
;MOVM
		lxi	h,TestDataMovm
		call	GenTestData1
;		lxi	h,AdrToCount1
;		shld	AdrToCount+1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextMovm+7
		call	Byte2HEX
		shld	TextMovm+5
;NOP
		lxi	h,TestDataNop
		call	GenTestData1
;		lxi	h,AdrToCount1
;		shld	AdrToCount+1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextNop+7
		call	Byte2HEX
		shld	TextNop+5
;ORAA
		lxi	h,TestDataOraa
		call	GenTestData1
;		lxi	h,AdrToCount1
;		shld	AdrToCount+1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextOraa+7
		call	Byte2HEX
		shld	TextOraa+5
;ORAM
		lxi	h,TestDataOram
		call	GenTestData1
;		lxi	h,AdrToCount1
;		shld	AdrToCount+1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextOram+7
		call	Byte2HEX
		shld	TextOram+5
;PUSH
		lxi	h,TestDataPush
		call	GenTestData1
;		lxi	h,AdrToCount1
;		shld	AdrToCount+1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextPush+7
		call	Byte2HEX
		shld	TextPush+5
;POP
		lxi	h,TestDataPop
		call	GenTestData1
;		lxi	h,AdrToCount1
;		shld	AdrToCount+1
		lxi	h,LowStack
		shld	SetStack+1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextPop+7
		call	Byte2HEX
		shld	TextPop+5
		lxi	h,Stack
		shld	SetStack+1
;RAL
		lxi	h,TestDataRal
		call	GenTestData1
;		lxi	h,AdrToCount1
;		shld	AdrToCount+1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextRal+7
		call	Byte2HEX
		shld	TextRal+5
;RAR
		lxi	h,TestDataRar
		call	GenTestData1
;		lxi	h,AdrToCount1
;		shld	AdrToCount+1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextRar+7
		call	Byte2HEX
		shld	TextRar+5
;RET
		lxi	h,TestDataRet
		call	GenTestData1
		call	GenStack
		lxi	h,LowStack
		shld	SetStack+1
;		lxi	h,AdrToCount1
;		shld	AdrToCount+1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextRet+7
		call	Byte2HEX
		shld	TextRet+5
		lxi	h,Stack
		shld	SetStack+1
;RLC
		lxi	h,TestDataRlc
		call	GenTestData1
;		lxi	h,AdrToCount1
;		shld	AdrToCount+1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextRlc+7
		call	Byte2HEX
		shld	TextRlc+5
;RNC
		lxi	h,TestDataRnc
		call	GenTestData1
;		lxi	h,AdrToCount1
;		shld	AdrToCount+1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextRnc+7
		call	Byte2HEX
		shld	TextRnc+5
;RC
		lxi	h,TestDataRc
		call	GenTestData1
		call	GenStack
		lxi	h,LowStack
		shld	SetStack+1
;		lxi	h,AdrToCount1
;		shld	AdrToCount+1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextRc+7
		call	Byte2HEX
		shld	TextRc+5
		lxi	h,Stack
		shld	SetStack+1
;RRC
		lxi	h,TestDataRrc
		call	GenTestData1
;		lxi	h,AdrToCount1
;		shld	AdrToCount+1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextRrc+7
		call	Byte2HEX
		shld	TextRrc+5
;SPHL
		lxi	h,TestDataSphl
		call	GenTestData1
;		lxi	h,AdrToCount1
;		shld	AdrToCount+1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextSphl+7
		call	Byte2HEX
		shld	TextSphl+5
;STAX
		lxi	h,TestDataStax
		call	GenTestData1
;		lxi	h,AdrToCount1
;		shld	AdrToCount+1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextStax+7
		call	Byte2HEX
		shld	TextStax+5
;STC
		lxi	h,TestDataStc
		call	GenTestData1
;		lxi	h,AdrToCount1
;		shld	AdrToCount+1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextStc+7
		call	Byte2HEX
		shld	TextStc+5
;SBBA
		lxi	h,TestDataSbba
		call	GenTestData1
;		lxi	h,AdrToCount1
;		shld	AdrToCount+1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextSbba+7
		call	Byte2HEX
		shld	TextSbba+5
;SBBM
		lxi	h,TestDataSbbm
		call	GenTestData1
;		lxi	h,AdrToCount1
;		shld	AdrToCount+1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextSbbm+7
		call	Byte2HEX
		shld	TextSbbm+5
;SUBA
		lxi	h,TestDataSuba
		call	GenTestData1
;		lxi	h,AdrToCount1
;		shld	AdrToCount+1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextSuba+7
		call	Byte2HEX
		shld	TextSuba+5
;SUBM
		lxi	h,TestDataSubm
		call	GenTestData1
;		lxi	h,AdrToCount1
;		shld	AdrToCount+1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextSubm+7
		call	Byte2HEX
		shld	TextSubm+5
;XCHG
		lxi	h,TestDataXchg
		call	GenTestData1
;		lxi	h,AdrToCount1
;		shld	AdrToCount+1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextXchg+7
		call	Byte2HEX
		shld	TextXchg+5
;XRAA
		lxi	h,TestDataXraa
		call	GenTestData1
;		lxi	h,AdrToCount1
;		shld	AdrToCount+1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextXraa+7
		call	Byte2HEX
		shld	TextXraa+5
;XRAM
		lxi	h,TestDataXram
		call	GenTestData1
;		lxi	h,AdrToCount1
;		shld	AdrToCount+1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextXram+7
		call	Byte2HEX
		shld	TextXram+5
;XTHL
		lxi	h,TestDataXthl
		call	GenTestData1
;		lxi	h,AdrToCount1
;		shld	AdrToCount+1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextXthl+7
		call	Byte2HEX
		shld	TextXthl+5
;MVIA
		lxi	h,TestDataMvia
		call	GenTestData2
		lxi	h,AdrToCount2
		shld	AdrToCount+1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextMvia+7
		call	Byte2HEX
		shld	TextMvia+5
;ACI
		lxi	h,TestDataAci
		call	GenTestData2
;		lxi	h,AdrToCount2
;		shld	AdrToCount+1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextAci+7
		call	Byte2HEX
		shld	TextAci+5
;ADI
		lxi	h,TestDataAdi
		call	GenTestData2
;		lxi	h,AdrToCount2
;		shld	AdrToCount+1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextAdi+7
		call	Byte2HEX
		shld	TextAdi+5
;ANI
		lxi	h,TestDataAni
		call	GenTestData2
;		lxi	h,AdrToCount2
;		shld	AdrToCount+1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextAni+7
		call	Byte2HEX
		shld	TextAni+5
;MVIM
		lxi	h,TestDataMvim
		call	GenTestData2
;		lxi	h,AdrToCount2
;		shld	AdrToCount+1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextMvim+7
		call	Byte2HEX
		shld	TextMvim+5
;ORI
		lxi	h,TestDataOri
		call	GenTestData2
;		lxi	h,AdrToCount2
;		shld	AdrToCount+1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextOri+7
		call	Byte2HEX
		shld	TextOri+5
;OUT
		lxi	h,TestDataOut
		call	GenTestData2
;		lxi	h,AdrToCount2
;		shld	AdrToCount+1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextOut+7
		call	Byte2HEX
		shld	TextOut+5
;SBI
		lxi	h,TestDataSbi
		call	GenTestData2
;		lxi	h,AdrToCount2
;		shld	AdrToCount+1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextSbi+7
		call	Byte2HEX
		shld	TextSbi+5
;SUI
		lxi	h,TestDataSui
		call	GenTestData2
;		lxi	h,AdrToCount2
;		shld	AdrToCount+1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextSui+7
		call	Byte2HEX
		shld	TextSui+5
;IN
		lxi	h,TestDataIn
		call	GenTestData2
;		lxi	h,AdrToCount2
;		shld	AdrToCount+1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextIn+7
		call	Byte2HEX
		shld	TextIn+5
;XRI
		lxi	h,TestDataXri
		call	GenTestData2
;		lxi	h,AdrToCount2
;		shld	AdrToCount+1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextXri+7
		call	Byte2HEX
		shld	TextXri+5
;LXI
		lxi	h,TestDataLxi
		call	GenTestData3
		lxi	h,AdrToCount3
		shld	AdrToCount+1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextLxi+7
		call	Byte2HEX
		shld	TextLxi+5
;CNC
		lxi	h,TestDataCnc
		call	GenTestData3
;		lxi	h,AdrToCount3
;		shld	AdrToCount+1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextCnc+7
		call	Byte2HEX
		shld	TextCnc+5
;CC
		lxi	h,TestDataCc
		call	GenTestData3
		call	GenAdr
;		lxi	h,AdrToCount3
;		shld	AdrToCount+1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextCc+7
		call	Byte2HEX
		shld	TextCc+5
;CALL
		lxi	h,TestDataCall
		call	GenTestData3
		call	GenAdr
;		lxi	h,AdrToCount3
;		shld	AdrToCount+1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextCall+7
		call	Byte2HEX
		shld	TextCall+5
;JNC
		lxi	h,TestDataJnc
		call	GenTestData3
;		lxi	h,AdrToCount3
;		shld	AdrToCount+1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextJnc+7
		call	Byte2HEX
		shld	TextJnc+5
;JC
		lxi	h,TestDataJc
		call	GenTestData3
		call	GenAdr
;		lxi	h,AdrToCount3
;		shld	AdrToCount+1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextJc+7
		call	Byte2HEX
		shld	TextJc+5
;JMP
		lxi	h,TestDataJmp
		call	GenTestData3
		call	GenAdr
;		lxi	h,AdrToCount3
;		shld	AdrToCount+1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextJmp+7
		call	Byte2HEX
		shld	TextJmp+5
;LHLD
		lxi	h,TestDataLhld
		call	GenTestData3
;		lxi	h,AdrToCount3
;		shld	AdrToCount+1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextLhld+7
		call	Byte2HEX
		shld	TextLhld+5
;LDA
		lxi	h,TestDataLda
		call	GenTestData3
;		lxi	h,AdrToCount3
;		shld	AdrToCount+1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextLda+7
		call	Byte2HEX
		shld	TextLda+5
;SHLD
		lxi	h,TestDataShld
		call	GenTestData3
;		lxi	h,AdrToCount3
;		shld	AdrToCount+1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextShld+7
		call	Byte2HEX
		shld	TextShld+5
;STA
		lxi	h,TestDataSta
		call	GenTestData3
;		lxi	h,AdrToCount3
;		shld	AdrToCount+1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextSta+7
		call	Byte2HEX
		shld	TextSta+5


;�������� ���������
		lxi	sp,LowStack
		call	Cls
		mvi	a,0C9h
		sta	38h
		ei
		hlt
		lxi	h, colors+15
colorset:
		mvi	a, 88h
		out	0
		mvi	c, 15
colorset1:	mov	a, c
		out	2
		mov	a, m
		out	0Ch
		dcx	h
		out	0Ch
		out	0Ch
		dcr	c
		out	0Ch
		out	0Ch
		out	0Ch
		jp	colorset1
		mvi	a,255
		out	3


		lxi	h,LogoTxt
		lxi	d,0E6FFh
		call	PrintText
		mvi	d,0E3h
		call	PrintText

		lxi	h,TextAci
		lxi	d,0E1E7h
		mvi	b,29
Column0:
		call	PrintText
		dcr	b
		jnz	Column0

		lxi	d,0EBE7h
		mvi	b,29
Column1:
		call	PrintText
		dcr	b
		jnz	Column1

		lxi	d,0F5E7h
		mvi	b,7
Column2:
		call	PrintText
		dcr	b
		jnz	Column2


neverend:
		jmp	neverend


Test:	
		pop	h
		shld	AdrRet+1
SetStack:
		lxi	h,Stack
		sphl
		shld	42h
		lxi	h,3Bh
		shld	39h
		lxi	h,TestExit
		lxi	d,Stack
		stc
		ei
		hlt
TestExit:
		pop	h
		call	AdrToCount
		shld	Count
AdrRet:	jmp	0
		

;��������� ���� � ���������� ��� (HEX)
;����	(DE-1)
;����� HL
Byte2HEX:
		inx	d
		ldax	d
		push	psw
		call	Nibl2HEX
		mov	h,a
		pop	psw
		rrc
		rrc
		rrc
		rrc
		call	Nibl2HEX
		mov	l,a
		ret

Nibl2HEX:
		ani	00001111b
		cpi	0Ah
		jnc	Symb
		adi	30h	
		ret
Symb:
		adi	41h-10
		ret

Cls:
		lxi	h,0E000h
		xra	a
ClrScr:	mov	m,a
		inx	h
		cmp	h
		jnz	ClrScr
		ret

PrintText:
		push b
		push d
PrintTextLoop:
		mov	a,m
		inx	h
		ora	a
		jz	PrintTextExit
		call	PrintChar
		inr	d
		jmp	PrintTextLoop
PrintTextExit:
		pop	d
		mov	a,e
		sui	8
		mov	e,a
		mov	a,d
		sbi	0
		mov	d,a
		pop	b
		ret

PrintChar:
		push	d
		push	h
		push	b
		mov	l,	a
		mvi	h,	0
		dad		h
		dad		h
		dad		h
		lxi	b,	Font-256
		dad		b
		mvi	b,	8
loopchar:
		mov	a,	m
		inx		h
		stax		d
		dcr		e
		dcr		b
		jnz		loopchar
		pop		b
		pop		h
		pop		d
		ret

;������������� �������� ������ � ������ TestAdr
;����
;HL - ������ ����� �������� ������������������ ������ 2 �����
GenTestData1:
		mov	e,m
		lxi	h,TestAdr+TestDataInitEnd-TestDataInit
		lxi	b,BaseComCount*3
GenTestDataLoop1:
		mov	m,e
		inx	h
		dcx	b
		mov	a,b
		ora	c
		jnz	GenTestDataLoop1
		ret
;������������� �������� ������ � ������ TestAdr
;����
;HL - ������ ����� �������� ������������������ ������ 2 �����
GenTestData2:
		mov	e,m
		inx	h
		mov	d,m
		lxi	h,TestAdr+TestDataInitEnd-TestDataInit
		lxi	b,BaseComCount*3/2
GenTestDataLoop2:
		mov	m,e
		inx	h
		mov	m,d
		inx	h
		dcx	b
		mov	a,b
		ora	c
		jnz	GenTestDataLoop2
		ret
;������������� �������� ������ � ������ TestAdr
;����
;HL - ������ ����� �������� ������������������ ������ 3 �����
GenTestData3:
		mov	a,m
		sta	TempA
		inx	h
		mov	e,m
		inx	h
		mov	d,m
		lxi	h,TestAdr+TestDataInitEnd-TestDataInit
		lxi	b,BaseComCount
GenTestDataLoop3:
		lda	TempA
		mov	m,a
		inx	h
		mov	m,e
		inx	h
		mov	m,d
		inx	h
		dcx	b
		mov	a,b
		ora	c
		jnz	GenTestDataLoop3
		ret
TempA		.db 0

;������������� ������
;��� JMP, CALL
GenAdr:
		lxi	h,TestAdr+TestDataInitEnd-TestDataInit+1	;������� ������ ����������
		lxi	d,TestAdr+TestDataInitEnd-TestDataInit+3	;������ ����� ��� ��������
		lxi	b,BaseComCount
GenAdrLoop:
		mov	m,e
		inx	h
		mov	m,d
		inx	h
		inx	h
		inx	d
		inx	d
		inx	d
		dcx	b
		mov	a,b
		ora	c
		jnz	GenAdrLoop
		ret

;������������� ������ � �����
;��� RET
GenStack:
		lxi	h,LowStack	;������� ������ ����������
		lxi	d,TestAdr+TestDataInitEnd-TestDataInit+1		;������ ����� ��� ��������
		lxi	b,14500
GenStackLoop:
		mov	m,e
		inx	h
		mov	m,d
		inx	h
		inx	d
		dcx	b
		mov	a,b
		ora	c
		jnz	GenStackLoop
		ret

AdrToCount:	jmp	0
;������������� �������� ����� � ���������� ������������ ������
;���� HL
;����� HL
AdrToCount1:
		lxi	d,-(TestAdr+TestDataInitEnd-TestDataInit)
		dad	d
		ret
AdrToCount2:
		lxi	d,-(TestAdr+TestDataInitEnd-TestDataInit)
		dad	d
		ora	a
		mov	a,h
		rar
		mov	h,a
		mov	a,l
		rar
		mov	l,a
		ret
AdrToCount3:
		lxi	d,-(TestAdr+TestDataInitEnd-TestDataInit)
		dad	d
		mov	b,h
		mov	c,l
		lxi	d,-3
;�������
		lxi	h,0
		mvi	a,17
DV0:		push	h
		dad	d
		jnc	DV1
		xthl
DV1:		pop	h
		push	psw
		mov	a,c
		ral
		mov	c,a
		mov	a,b
		ral
		mov	b,a
		mov	a,l
		ral
		mov	l,a
		mov	a,h
		ral
		mov	h,a
		pop	psw
		dcr	a
		jnz	DV0
;		ora	a
;		mov	a,h
;		rar
;		mov	d,a
;		mov	a,l
;		rar
;		mov	e,a
		mov	h,b
		mov	l,c
		ret

TestDataInit:
		jmp	0
		shld	39h
		lxi	h,Stack
		lxi	sp,Stack
		ei
		nop
TestDataInitEnd:

LogoTxt	.db "Vector Speed Test 1.0",0
		.db 127," Ivan Gorodetsky, Ufa 2009",0

TestDataAci:		aci		0
TestDataAdca:		adc		a
TestDataAdcm:	adc		m
TestDataAdi:		adi		0
TestDataAdda:		add		a
TestDataAddm:	add		m
TestDataAnaa:		ana		a
TestDataAnam:	ana		m
TestDataAni:		ani		0
TestDataCnc:		cnc		0
TestDataCc:		cc		0
TestDataCall:		call		0
TestDataCma:		cma
TestDataCmc:		cmc
TestDataDaa:		daa
TestDataDad:		dad		h
TestDataDcra:		dcr		a
TestDataDcrm:	dcr		m
TestDataDcx:		dcx		h
TestDataEi:		ei
TestDataIn:		in		1
TestDataInra:		inr		a
TestDataInrm:		inr		m
TestDataInx:		inx		h
TestDataJnc:		jnc		0
TestDataJc:		jc		0
TestDataJmp:		jmp		0
TestDataLda:		lda		8000h
TestDataLdax:		ldax		d
TestDataLhld:		lhld		8000h
TestDataLxi:		lxi		h,1
TestDataMova:	mov		a,a
TestDataMovm:	mov		m,a
TestDataMvia:		mvi		a,1
TestDataMvim:	mvi		m,1
TestDataNop:		nop
TestDataOraa:		ora		a
TestDataOram:	ora		m
TestDataOri:		ori		0
TestDataOut:		out		0Ch
TestDataPop:		pop		h
TestDataPush:		push	h
TestDataRnc:		rnc
TestDataRc:		rc
TestDataRal:		ral
TestDataRar:		rar
TestDataRet:		ret
TestDataRlc:		rlc
TestDataRrc:		rrc
TestDataSbba:		sbb		a
TestDataSbbm:	sbb		m
TestDataSbi:		sbi		0
TestDataShld:		shld		Stack
TestDataSphl:		sphl
TestDataSta:		sta		Stack
TestDataStax:		stax		d
TestDataStc:		stc
TestDataSuba:		sub		a
TestDataSubm:	sub		m
TestDataSui:		sui		0
TestDataXchg:		xchg
TestDataXraa:		xra		a
TestDataXram:	xra		m
TestDataXri:		xri		0
TestDataXthl:		xthl


TextAci:		.db "Aci--XXXX",0
TextAdca:		.db "AdcR-XXXX",0
TextAdcm:	.db "AdcM-XXXX",0
TextAdi:		.db "Adi--XXXX",0
TextAdda:	.db "AddR-XXXX",0
TextAddm:	.db "AddM-XXXX",0
TextAnaa:	.db "AnaR-XXXX",0
TextAnam:	.db "AnaM-XXXX",0
TextAni:		.db "Ani--XXXX",0
TextCnc:		.db "C*-N-XXXX",0
TextCc:		.db "C*-Y-XXXX",0
TextCall:		.db "Call-XXXX",0
TextCma:		.db "Cma--XXXX",0
TextCmc:		.db "Cmc--XXXX",0
TextDaa:		.db "Daa--XXXX",0
TextDad:		.db "Dad--XXXX",0
TextDcra:		.db "DcrR-XXXX",0
TextDcrm:	.db "DcrM-XXXX",0
TextDcx:		.db "Dcx--XXXX",0
TextEi:		.db "Ei---XXXX",0
TextIn:		.db "In---XXXX",0
TextInra:		.db "InrR-XXXX",0
TextInrm:		.db "InrM-XXXX",0
TextInx:		.db "Inx--XXXX",0
TextJnc:		.db "J*-N-XXXX",0
TextJc:		.db "J*-Y-XXXX",0
TextJmp:		.db "Jmp--XXXX",0
TextLda:		.db "Lda--XXXX",0
TextLdax:	.db "Ldax-XXXX",0
TextLhld:		.db "Lhld-XXXX",0
TextLxi:		.db "Lxi--XXXX",0
TextMova:	.db "MovR-XXXX",0
TextMovm:	.db "MovM-XXXX",0
TextMvia:	.db "MviR-XXXX",0
TextMvim:	.db "MviM-XXXX",0
TextNop:		.db "Nop--XXXX",0
TextOraa:		.db "OraR-XXXX",0
TextOram:	.db "OraM-XXXX",0
TextOri:		.db "Ori--XXXX",0
TextOut:		.db "Out--XXXX",0
TextPop:		.db "Pop--XXXX",0
TextPush:	.db "Push-XXXX",0
TextRnc:		.db "R*-N-XXXX",0
TextRc:		.db "R*-Y-XXXX",0
TextRal:		.db "Ral--XXXX",0
TextRar:		.db "Rar--XXXX",0
TextRet:		.db "Ret--XXXX",0
TextRlc:		.db "Rlc--XXXX",0
TextRrc:		.db "Rrc--XXXX",0
TextSbba:	.db "SbbR-XXXX",0
TextSbbm:	.db "SbbM-XXXX",0
TextSbi:		.db "Sbi--XXXX",0
TextShld:		.db "Shld-XXXX",0
TextSphl:		.db "Sphl-XXXX",0
TextSta:		.db "Sta--XXXX",0
TextStax:		.db "Stax-XXXX",0
TextStc:		.db "Stc--XXXX",0
TextSuba:	.db "SubR-XXXX",0
TextSubm:	.db "SubM-XXXX",0
TextSui:		.db "Sui--XXXX",0
TextXchg:	.db "Xchg-XXXX",0
TextXraa:		.db "XraR-XXXX",0
TextXram:	.db "XraM-XXXX",0
TextXri:		.db "Xri--XXXX",0
TextXthl:		.db "Xthl-XXXX",0


Count	.dw 0

#define col 173

colors:
		.db 0,col,0,col,0,col,0,col,0,col,0,col,0,col,0,col

Font:

End:
		.end
