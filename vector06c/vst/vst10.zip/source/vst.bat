tasm -b -85 vst.asm
copy	 /b vst.obj+font.bin vst.r80
tasm -b -85 vstini.asm
copy /b vstini.obj+vst.r80 vst.rom