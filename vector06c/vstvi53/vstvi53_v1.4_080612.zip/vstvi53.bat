tasm -tvm1 -b vstvi53.asm
copy /b vstvi53.obj+font.bin vstvi53.r80
tasm -tvm1 -b vstini.asm
copy /b vstini.obj+vstvi53.r80 vstvi53.rom