TestStart	.equ	8000h

		.org	100h

		di
		xra	a
		out	10h
		lxi	h,Test
		lxi	d,TestStart
		lxi	b,4853
Loop:
		mov	a,m
		inx	h
		stax	d
		inx	d
		dcx	b
		mov	a,b
		ora	c
		jnz	Loop
		jmp	TestStart
Test:

		.end