;Vector Speed Test with VI53 1.4
;���� ����������, ���
;���� �������� ���������� ��������� ������ ��580��80
;����� ����� ��������� �� ��580��1, 1821��85 � Z80
;������ ��� ��8000 - 06.02.2009
;������ ��� ������� - 24.10.2009-04.05.2011
;������������� � TASM - A Table Driven Cross Assembler for the MSDOS* Environment (tasm 3.01 ��� 3.2)
;� �������������� ����� � ������������ ������ 580��1 - TASMVM1.TAB

TestAdr	.equ	100h
Stack	.equ	0FFF0h
LowStack	.equ	9F00h
BaseComCount	.equ	2000

		.org	8000h
Start:
		di
		xra	a
		out	10h
		mvi	a,0C3h	;jmp
		sta	0
		lxi	h,Start
		shld	1
		mvi	a,0C9h	;ret
		sta	8
		sta	38h
		sta	40h

		lxi	sp,Stack
		lxi	h,TestDataInit
		lxi	d,TestAdr
		mvi	b,TestDataInitEnd-TestDataInit
move:	mov	a,m
		stax	d
		inx	h
		inx	d
		dcr	b
		jnz	move

		xchg
		call	GenTestOut
		lxi	d,Overhead
		dcx	h
		mov	m,d
		dcx	h
		mov	m,e
		jmp	TestAdr

Overhead:
		in	0Bh
		sta	OvhdLow+1
		in	0Bh
		sta	OvhdHigh+1
		

;INX
		lxi	h,TestDataInx
		call	GenTestData1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextInx+7
		call	Byte2HEX
		shld	TextInx+5
;ADCA
		lxi	h,TestDataAdca
		call	GenTestData1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextAdca+7
		call	Byte2HEX
		shld	TextAdca+5
;ADCM
		lxi	h,TestDataAdcm
		call	GenTestData1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextAdcm+7
		call	Byte2HEX
		shld	TextAdcm+5
;DI
		lxi	h,TestDataDi
		call	GenTestData1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextDi+7
		call	Byte2HEX
		shld	TextDi+5
;CMA
		lxi	h,TestDataCma
		call	GenTestData1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextCma+7
		call	Byte2HEX
		shld	TextCma+5
;CMC
		lxi	h,TestDataCmc
		call	GenTestData1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextCmc+7
		call	Byte2HEX
		shld	TextCmc+5
;DAA
		lxi	h,TestDataDaa
		call	GenTestData1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextDaa+7
		call	Byte2HEX
		shld	TextDaa+5
;DAD
		lxi	h,TestDataDad
		call	GenTestData1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextDad+7
		call	Byte2HEX
		shld	TextDad+5
;EI
		lxi	h,TestDataEi
		call	GenTestData1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextEi+7
		call	Byte2HEX
		shld	TextEi+5
;ADDA
		lxi	h,TestDataAdda
		call	GenTestData1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextAdda+7
		call	Byte2HEX
		shld	TextAdda+5
;ADDM
		lxi	h,TestDataAddm
		call	GenTestData1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextAddm+7
		call	Byte2HEX
		shld	TextAddm+5
;ANAA
		lxi	h,TestDataAnaa
		call	GenTestData1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextAnaa+7
		call	Byte2HEX
		shld	TextAnaa+5
;ANAM
		lxi	h,TestDataAnam
		call	GenTestData1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextAnam+7
		call	Byte2HEX
		shld	TextAnam+5
;DCRA
		lxi	h,TestDataDcra
		call	GenTestData1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextDcra+7
		call	Byte2HEX
		shld	TextDcra+5
;DCRM
		lxi	h,TestDataDcrm
		call	GenTestData1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextDcrm+7
		call	Byte2HEX
		shld	TextDcrm+5
;DCX
		lxi	h,TestDataDcx
		call	GenTestData1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextDcx+7
		call	Byte2HEX
		shld	TextDcx+5
;INRA
		lxi	h,TestDataInra
		call	GenTestData1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextInra+7
		call	Byte2HEX
		shld	TextInra+5
;INRM
		lxi	h,TestDataInrm
		call	GenTestData1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextInrm+7
		call	Byte2HEX
		shld	TextInrm+5
;LDAX
		lxi	h,TestDataLdax
		call	GenTestData1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextLdax+7
		call	Byte2HEX
		shld	TextLdax+5
;MOVA
		lxi	h,TestDataMova
		call	GenTestData1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextMova+7
		call	Byte2HEX
		shld	TextMova+5
;MOVM
		lxi	h,TestDataMovm
		call	GenTestData1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextMovm+7
		call	Byte2HEX
		shld	TextMovm+5
;NOP
		lxi	h,TestDataNop
		call	GenTestData1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextNop+7
		call	Byte2HEX
		shld	TextNop+5
;ORAA
		lxi	h,TestDataOraa
		call	GenTestData1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextOraa+7
		call	Byte2HEX
		shld	TextOraa+5
;ORAM
		lxi	h,TestDataOram
		call	GenTestData1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextOram+7
		call	Byte2HEX
		shld	TextOram+5
;PUSH
		lxi	h,TestDataPush
		call	GenTestData1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextPush+7
		call	Byte2HEX
		shld	TextPush+5
;POP
		lxi	h,TestDataPop
		call	GenTestData1
		lxi	h,LowStack
		shld	SetStack+1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextPop+7
		call	Byte2HEX
		shld	TextPop+5
		lxi	h,Stack
		shld	SetStack+1
;RAL
		lxi	h,TestDataRal
		call	GenTestData1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextRal+7
		call	Byte2HEX
		shld	TextRal+5
;RAR
		lxi	h,TestDataRar
		call	GenTestData1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextRar+7
		call	Byte2HEX
		shld	TextRar+5
;RET
		lxi	h,TestDataRet
		call	GenTestData1
		call	GenStack
		lxi	h,LowStack
		shld	SetStack+1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextRet+7
		call	Byte2HEX
		shld	TextRet+5
		lxi	h,Stack
		shld	SetStack+1
;RLC
		lxi	h,TestDataRlc
		call	GenTestData1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextRlc+7
		call	Byte2HEX
		shld	TextRlc+5
;RNC
		lxi	h,TestDataRnc
		call	GenTestData1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextRnc+7
		call	Byte2HEX
		shld	TextRnc+5
;RC
		lxi	h,TestDataRc
		call	GenTestData1
		call	GenStack
		lxi	h,LowStack
		shld	SetStack+1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextRc+7
		call	Byte2HEX
		shld	TextRc+5
		lxi	h,Stack
		shld	SetStack+1
;RRC
		lxi	h,TestDataRrc
		call	GenTestData1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextRrc+7
		call	Byte2HEX
		shld	TextRrc+5
;RSTRET
		lxi	h,TestDataRstRet
		call	GenTestData1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextRstRet+7+2
		call	Byte2HEX
		shld	TextRstRet+5+2
;SPHL
		lxi	h,TestDataSphl
		call	GenTestData1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextSphl+7
		call	Byte2HEX
		shld	TextSphl+5
;STAX
		lxi	h,TestDataStax
		call	GenTestData1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextStax+7
		call	Byte2HEX
		shld	TextStax+5
;STC
		lxi	h,TestDataStc
		call	GenTestData1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextStc+7
		call	Byte2HEX
		shld	TextStc+5
;SBBA
		lxi	h,TestDataSbba
		call	GenTestData1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextSbba+7
		call	Byte2HEX
		shld	TextSbba+5
;SBBM
		lxi	h,TestDataSbbm
		call	GenTestData1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextSbbm+7
		call	Byte2HEX
		shld	TextSbbm+5
;SUBA
		lxi	h,TestDataSuba
		call	GenTestData1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextSuba+7
		call	Byte2HEX
		shld	TextSuba+5
;SUBM
		lxi	h,TestDataSubm
		call	GenTestData1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextSubm+7
		call	Byte2HEX
		shld	TextSubm+5
;XCHG
		lxi	h,TestDataXchg
		call	GenTestData1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextXchg+7
		call	Byte2HEX
		shld	TextXchg+5
;XRAA
		lxi	h,TestDataXraa
		call	GenTestData1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextXraa+7
		call	Byte2HEX
		shld	TextXraa+5
;XRAM
		lxi	h,TestDataXram
		call	GenTestData1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextXram+7
		call	Byte2HEX
		shld	TextXram+5
;XTHL
		lxi	h,TestDataXthl
		call	GenTestData1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextXthl+7
		call	Byte2HEX
		shld	TextXthl+5
;MVIA
		lxi	h,TestDataMvia
		call	GenTestData2
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextMvia+7
		call	Byte2HEX
		shld	TextMvia+5
;ACI
		lxi	h,TestDataAci
		call	GenTestData2
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextAci+7
		call	Byte2HEX
		shld	TextAci+5
;ADI
		lxi	h,TestDataAdi
		call	GenTestData2
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextAdi+7
		call	Byte2HEX
		shld	TextAdi+5
;ANI
		lxi	h,TestDataAni
		call	GenTestData2
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextAni+7
		call	Byte2HEX
		shld	TextAni+5
;MVIM
		lxi	h,TestDataMvim
		call	GenTestData2
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextMvim+7
		call	Byte2HEX
		shld	TextMvim+5
;ORI
		lxi	h,TestDataOri
		call	GenTestData2
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextOri+7
		call	Byte2HEX
		shld	TextOri+5
;OUT
		lxi	h,TestDataOut
		call	GenTestData2
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextOut+7
		call	Byte2HEX
		shld	TextOut+5
;DADPCHL
		lxi	h,TestDataDadPchl
		call	GenTestData2
		lxi	h,TestAdr+TestDataInitEnd-TestDataInit
		shld	SetHL+1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextDadPchl+7+3
		call	Byte2HEX
		shld	TextDadPchl+5+3
		lxi	h,Stack
		shld	SetHL+1
;SBI
		lxi	h,TestDataSbi
		call	GenTestData2
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextSbi+7
		call	Byte2HEX
		shld	TextSbi+5
;SUI
		lxi	h,TestDataSui
		call	GenTestData2
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextSui+7
		call	Byte2HEX
		shld	TextSui+5
;IN
		lxi	h,TestDataIn
		call	GenTestData2
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextIn+7
		call	Byte2HEX
		shld	TextIn+5
;XRI
		lxi	h,TestDataXri
		call	GenTestData2
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextXri+7
		call	Byte2HEX
		shld	TextXri+5
;LXI
		lxi	h,TestDataLxi
		call	GenTestData3
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextLxi+7
		call	Byte2HEX
		shld	TextLxi+5
;CNC
		lxi	h,TestDataCnc
		call	GenTestData3
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextCnc+7
		call	Byte2HEX
		shld	TextCnc+5
;CC
		lxi	h,TestDataCc
		call	GenTestData3
		call	GenAdr
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextCc+7
		call	Byte2HEX
		shld	TextCc+5
;CALL
		lxi	h,TestDataCall
		call	GenTestData3
		call	GenAdr
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextCall+7
		call	Byte2HEX
		shld	TextCall+5
;JNC
		lxi	h,TestDataJnc
		call	GenTestData3
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextJnc+7
		call	Byte2HEX
		shld	TextJnc+5
;JC
		lxi	h,TestDataJc
		call	GenTestData3
		call	GenAdr
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextJc+7
		call	Byte2HEX
		shld	TextJc+5
;JMP
		lxi	h,TestDataJmp
		call	GenTestData3
		call	GenAdr
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextJmp+7
		call	Byte2HEX
		shld	TextJmp+5
;LHLD
		lxi	h,TestDataLhld
		call	GenTestData3
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextLhld+7
		call	Byte2HEX
		shld	TextLhld+5
;LDA
		lxi	h,TestDataLda
		call	GenTestData3
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextLda+7
		call	Byte2HEX
		shld	TextLda+5
;SHLD
		lxi	h,TestDataShld
		call	GenTestData3
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextShld+7
		call	Byte2HEX
		shld	TextShld+5
;STA
		lxi	h,TestDataSta
		call	GenTestData3
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextSta+7
		call	Byte2HEX
		shld	TextSta+5


;����������� ���� ����������
		xra	a
		dcr	a
		jpe	cpuNotZ80
;Z80
		lxi	h,Z80txt
		shld	cputype+1
		jmp	PrintResult
cpuNotZ80:
		push	psw
		pop	h
		mov	e,l
		mvi	a,00001010b
		xra	l
		mov	l,a
		push	h
		pop	psw
		push	psw
		pop	h
		mov	a,l
		xra	e
		cpi	00001000b
		jz	ItsVM1
		cpi	00000010b
		jnz	PrintResult
		lxi	h,i8085txt
		shld	cputype+1
		lxi	h,0
		shld	Skip85
		shld	Skip85+1
;ARHL
		lxi	h,TestDataArhl
		call	GenTestData1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextArhl+7
		call	Byte2HEX
		shld	TextArhl+5
;DSUB
		lxi	h,TestDataDsub85
		call	GenTestData1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextDsub85+7
		call	Byte2HEX
		shld	TextDsub85+5
;LDHI
		lxi	h,TestDataLdhi
		call	GenTestData2
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextLdhi+7
		call	Byte2HEX
		shld	TextLdhi+5
;LDSI
		lxi	h,TestDataLdsi
		call	GenTestData2
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextLdsi+7
		call	Byte2HEX
		shld	TextLdsi+5
;SIM
		lxi	h,TestDataSim
		call	GenTestData1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextSim+7
		call	Byte2HEX
		shld	TextSim+5
;RDEL
		lxi	h,TestDataRdel
		call	GenTestData1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextRdel+7
		call	Byte2HEX
		shld	TextRdel+5
;RIM
		lxi	h,TestDataRim
		call	GenTestData1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextRim+7
		call	Byte2HEX
		shld	TextRim+5
;LHLX85
		lxi	h,TestDataLhlx85
		call	GenTestData1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextLhlx85+7
		call	Byte2HEX
		shld	TextLhlx85+5
;SHLX85
		lxi	h,TestDataShlx85
		call	GenTestData1
		lxi	h,Stack
		shld	SetHL+1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextShlx85+7
		call	Byte2HEX
		shld	TextShlx85+5
;RSTVN
		lxi	h,TestDataRstv
		call	GenTestData1
		xra	a
		push	psw
		inx	sp
		pop	psw
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextRstvN+7+1
		call	Byte2HEX
		shld	TextRstvN+5+1
;RSTVY
		mvi	a,0FFh
		push	psw
		inx	sp
		pop	psw
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextRstvY+7+3
		call	Byte2HEX
		shld	TextRstvY+5+3

;JNK
		lxi	h,TestDataJnk
		call	GenTestData3
		mvi	a,0FFh
		push	psw
		inx	sp
		pop	psw
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextJnk+7
		call	Byte2HEX
		shld	TextJnk+5
;JK
		lxi	h,TestDataJk
		call	GenTestData3
		call	GenAdr
		mvi	a,0FFh
		push	psw
		inx	sp
		pop	psw
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextJk+7
		call	Byte2HEX
		shld	TextJk+5
		
		jmp	PrintResult
;��1
ItsVM1:
		lxi	h,VM1txt
		shld	cputype+1
		mvi	a,12+14
		sta	Column2-1

;ANX
		lxi	h,TestDataAnx
		call	GenTestData1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextAnx+7
		call	Byte2HEX
		shld	TextAnx+5
;DCMP
		lxi	h,TestDataDcmp
		call	GenTestData1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextDcmp+7
		call	Byte2HEX
		shld	TextDcmp+5
;DSUB
		lxi	h,TestDataDsub
		call	GenTestData1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextDsub+7
		call	Byte2HEX
		shld	TextDsub+5
;JOF
		lxi	h,TestDataJof
		call	GenTestData3
		call	GenAdr
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextJof+7
		call	Byte2HEX
		shld	TextJof+5
;LHLX
		lxi	h,TestDataLhlx
		call	GenTestData1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextLhlx+7
		call	Byte2HEX
		shld	TextLhlx+5
;MB
		lxi	h,TestDataMb
		call	GenTestData1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextMb+8
		call	Byte2HEX
		shld	TextMb+6
;ORX
		lxi	h,TestDataOrx
		call	GenTestData1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextOrx+7
		call	Byte2HEX
		shld	TextOrx+5
;RS
		lxi	h,TestDataRs
		call	GenTestData1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextRs+7
		call	Byte2HEX
		shld	TextRs+5
;SHLX
		lxi	h,TestDataShlx
		call	GenTestData1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextShlx+7
		call	Byte2HEX
		shld	TextShlx+5
;SMF0
		lxi	h,TestDataSmf0
		call	GenTestData2
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextSmf0+7
		call	Byte2HEX
		shld	TextSmf0+5
;SMF1
		lxi	h,TestDataSmf1
		call	GenTestData2
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextSmf1+7
		call	Byte2HEX
		shld	TextSmf1+5
;XRX
		lxi	h,TestDataXrx
		call	GenTestData1
		call	Test
		lxi	d,Count-1
		call	Byte2HEX
		shld	TextXrx+7
		call	Byte2HEX
		shld	TextXrx+5

PrintResult:

;�������� ���������
		lxi	sp,LowStack
		call	Cls
		ei
		hlt
		lxi	h, colors+15
colorset:
		mvi	a, 88h
		out	0
		mvi	c, 15
colorset1:	mov	a, c
		out	2
		mov	a, m
		out	0Ch
		dcx	h
		out	0Ch
		out	0Ch
		dcr	c
		out	0Ch
		out	0Ch
		out	0Ch
		jp	colorset1
		mvi	a,255
		out	3


		lxi	h,LogoTxt
		lxi	d,0E0FFh
		call	PrintText
		mvi	d,0E2h
		call	PrintText
cputype:
		lxi	h,VM80txt
		mvi	d,0E0h
		call	PrintText


		lxi	h,TextAci
		lxi	d,0E0E7h
		mvi	b,29
Column0:
		call	PrintText
		dcr	b
		jnz	Column0

		lxi	d,0EAE7h
		mvi	b,29
Column1:
		call	PrintText
		dcr	b
		jnz	Column1

		lxi	d,0F4E7h
		mvi	b,12
Column2:
		call	PrintText
		dcr	b
		jnz	Column2
Skip85:
		jmp	neverend
		lxi	h,Text85
		mvi	b,15
Column85:
		call	PrintText
		dcr	b
		jnz	Column85

neverend:
		jmp	neverend


Test:	
		pop	h
		shld	AdrRet+1
SetStack:
		lxi	sp,Stack
		lxi	d,Stack
		lxi	b,2
SetHL:
		lxi	h,Stack
		stc
		jmp	TestAdr
TestExit:
		in	0Bh
		mov	l,a
		in	0Bh
		mov	h,a
OvhdLow:
		mvi	a,0FFh
		sub	l
		mov	l,a
OvhdHigh:
		mvi	a,0FFh
		sbb	h
		mov	h,a
		shld	Count
AdrRet:	jmp	0


;��������� ���� � ���������� ��� (HEX)
;����	(DE-1)
;����� HL
Byte2HEX:
		inx	d
		ldax	d
		push	psw
		call	Nibl2HEX
		mov	h,a
		pop	psw
		rrc
		rrc
		rrc
		rrc
		call	Nibl2HEX
		mov	l,a
		ret

Nibl2HEX:
		ani	00001111b
		cpi	0Ah
		jnc	Symb
		adi	30h	
		ret
Symb:
		adi	41h-10
		ret

Cls:
		lxi	h,0E000h
		xra	a
ClrScr:	mov	m,a
		inx	h
		cmp	h
		jnz	ClrScr
		ret

PrintText:
		push b
		push d
PrintTextLoop:
		mov	a,m
		inx	h
		ora	a
		jz	PrintTextExit
		call	PrintChar
		inr	d
		jmp	PrintTextLoop
PrintTextExit:
		pop	d
		mov	a,e
		sui	8
		mov	e,a
		mov	a,d
		sbi	0
		mov	d,a
		pop	b
		ret

PrintChar:
		push	d
		push	h
		push	b
		mov	l,	a
		mvi	h,	0
		dad		h
		dad		h
		dad		h
		lxi	b,	Font-256
		dad		b
		mvi	b,	8
loopchar:
		mov	a,	m
		inx		h
		stax		d
		dcr		e
		dcr		b
		jnz		loopchar
		pop		b
		pop		h
		pop		d
		ret

;������������� �������� ������ � ������ TestAdr
;����
;HL - ������ ����� �������� ������������������ ������ 2 �����
GenTestData1:
		mov	e,m
		lxi	h,TestAdr+TestDataInitEnd-TestDataInit
		lxi	b,BaseComCount
GenTestDataLoop1:
		mov	m,e
		inx	h
		dcx	b
		mov	a,b
		ora	c
		jnz	GenTestDataLoop1
		call	GenTestOut
		ret
;������������� �������� ������ � ������ TestAdr
;����
;HL - ������ ����� �������� ������������������ ������ 2 �����
GenTestData2:
		mov	e,m
		inx	h
		mov	d,m
		lxi	h,TestAdr+TestDataInitEnd-TestDataInit
		lxi	b,BaseComCount
GenTestDataLoop2:
		mov	m,e
		inx	h
		mov	m,d
		inx	h
		dcx	b
		mov	a,b
		ora	c
		jnz	GenTestDataLoop2
		call	GenTestOut
		ret
;������������� �������� ������ � ������ TestAdr
;����
;HL - ������ ����� �������� ������������������ ������ 3 �����
GenTestData3:
		mov	a,m
		sta	TempA
		inx	h
		mov	e,m
		inx	h
		mov	d,m
		lxi	h,TestAdr+TestDataInitEnd-TestDataInit
		lxi	b,BaseComCount
GenTestDataLoop3:
		lda	TempA
		mov	m,a
		inx	h
		mov	m,e
		inx	h
		mov	m,d
		inx	h
		dcx	b
		mov	a,b
		ora	c
		jnz	GenTestDataLoop3
		call	GenTestOut
		ret
TempA		.db 0

GenTestOut:
		lxi	d,TestOut
		mvi	c,TestOutEnd-TestOut
GenTestOutLoop:
		ldax	d
		inx	d
		mov	m,a
		inx	h
		dcr	c
		jnz	GenTestOutLoop
		ret

;������������� ������
;��� JMP, CALL
GenAdr:
		lxi	h,TestAdr+TestDataInitEnd-TestDataInit+1	;������� ������ ����������
		lxi	d,TestAdr+TestDataInitEnd-TestDataInit+3	;������ ����� ��� ��������
		lxi	b,BaseComCount
GenAdrLoop:
		mov	m,e
		inx	h
		mov	m,d
		inx	h
		inx	h
		inx	d
		inx	d
		inx	d
		dcx	b
		mov	a,b
		ora	c
		jnz	GenAdrLoop
		ret

;������������� ������ � �����
;��� RET
GenStack:
		lxi	h,LowStack	;������� ������ ����������
		lxi	d,TestAdr+TestDataInitEnd-TestDataInit+1		;������ ����� ��� ��������
		lxi	b,BaseComCount
GenStackLoop:
		mov	m,e
		inx	h
		mov	m,d
		inx	h
		inx	d
		dcx	b
		mov	a,b
		ora	c
		jnz	GenStackLoop
		ret

TestDataInit:
		mvi	a,00110000b
		out	8
		mvi	a,0FFh
		out	0Bh
		out	0Bh
TestDataInitEnd:

TestOut:
		di
		xra	a
		out	8
		jmp	TestExit
TestOutEnd:


LogoTxt	.db "Vector Speed Test with VI53 v1.4",0
	.db 127," Ivan Gorodetsky, Ufa 2011",0

VM80txt	.db "CPU: 580VM80",0
VM1txt	.db "CPU: 580VM1",0
Z80txt	.db "CPU: Z80",0
i8085txt	.db "CPU: 1821VM85",0

TestDataAci:		aci		0
TestDataAdca:		adc		a
TestDataAdcm:	adc		m
TestDataAdi:		adi		0
TestDataAdda:		add		a
TestDataAddm:	add		m
TestDataAnaa:		ana		a
TestDataAnam:	ana		m
TestDataAni:		ani		0
TestDataCnc:		cnc		0
TestDataCc:		cc		0
TestDataCall:		call		0
TestDataCma:		cma
TestDataCmc:		cmc
TestDataDaa:		daa
TestDataDad:		dad		h
TestDataDcra:		dcr		a
TestDataDcrm:	dcr		m
TestDataDcx:		dcx		h
TestDataDi:		di
TestDataEi:		ei
TestDataIn:		in		1
TestDataInra:		inr		a
TestDataInrm:		inr		m
TestDataInx:		inx		h
TestDataJnc:		jnc		0
TestDataJc:		jc		0
TestDataJmp:		jmp		0
TestDataLda:		lda		8000h
TestDataLdax:		ldax		d
TestDataLhld:		lhld		8000h
TestDataLxi:		lxi		h,1
TestDataMova:	mov		a,a
TestDataMovm:	mov		m,a
TestDataMvia:		mvi		a,1
TestDataMvim:	mvi		m,1
TestDataNop:		nop
TestDataOraa:		ora		a
TestDataOram:	ora		m
TestDataOri:		ori		0
TestDataOut:		out		0Ch
TestDataPop:		pop		h
TestDataPush:		push	h
TestDataRnc:		rnc
TestDataRc:		rc
TestDataRal:		ral
TestDataRar:		rar
TestDataRet:		ret
TestDataRlc:		rlc
TestDataRrc:		rrc
TestDataSbba:		sbb		a
TestDataSbbm:	sbb		m
TestDataSbi:		sbi		0
TestDataShld:		shld		Stack
TestDataSphl:		sphl
TestDataSta:		sta		Stack
TestDataStax:		stax		d
TestDataStc:		stc
TestDataSuba:		sub		a
TestDataSubm:	sub		m
TestDataSui:		sui		0
TestDataXchg:		xchg
TestDataXraa:		xra		a
TestDataXram:	xra		m
TestDataXri:		xri		0
TestDataXthl:		xthl
TestDataDadPchl:	dad b \ pchl
TestDataRstRet:	rst		1

TestDataAnx:	anx
TestDataDcmp:	dcmp b
TestDataDsub:	dsub b
TestDataJof:	jof 0
TestDataLhlx:	lhlx
TestDataMb:	mb
TestDataOrx:	orx
TestDataRs:	rs
TestDataShlx:	shlx
TestDataSmf0:	smf0
TestDataSmf1:	smf1
TestDataXrx:	xrx


TestDataDsub85:	.db 08h
TestDataArhl:	.db 10h
TestDataRdel:	.db 18h
TestDataRim:	.db 20h
TestDataLdhi:	.db 28h,00
TestDataSim:	.db 30h
TestDataLdsi:	.db 38h,00
TestDataRstv:	.db 0CBh
TestDataShlx85:	.db 0D9h
TestDataJnk:	.db 0DDh,00,00
TestDataLhlx85:	.db 0EDh
TestDataJk:	.db 0FDh,00,00


TextAci:	.db "Aci--XXXX",0
TextAdca:		.db "AdcR-XXXX",0
TextAdcm:	.db "AdcM-XXXX",0
TextAdi:		.db "Adi--XXXX",0
TextAdda:	.db "AddR-XXXX",0
TextAddm:	.db "AddM-XXXX",0
TextAnaa:	.db "AnaR-XXXX",0
TextAnam:	.db "AnaM-XXXX",0
TextAni:		.db "Ani--XXXX",0
TextCnc:		.db "C*-N-XXXX",0
TextCc:		.db "C*-Y-XXXX",0
TextCall:		.db "Call-XXXX",0
TextCma:		.db "Cma--XXXX",0
TextCmc:		.db "Cmc--XXXX",0
TextDaa:		.db "Daa--XXXX",0
TextDad:		.db "Dad--XXXX",0
TextDcra:		.db "DcrR-XXXX",0
TextDcrm:	.db "DcrM-XXXX",0
TextDcx:		.db "Dcx--XXXX",0
TextDi:		.db "Di---XXXX",0
TextEi:		.db "Ei---XXXX",0
TextIn:		.db "In---XXXX",0
TextInra:		.db "InrR-XXXX",0
TextInrm:		.db "InrM-XXXX",0
TextInx:		.db "Inx--XXXX",0
TextJnc:		.db "J*-N-XXXX",0
TextJc:		.db "J*-Y-XXXX",0
TextJmp:		.db "Jmp--XXXX",0
TextLda:		.db "Lda--XXXX",0
TextLdax:	.db "Ldax-XXXX",0
TextLhld:		.db "Lhld-XXXX",0
TextLxi:		.db "Lxi--XXXX",0
TextMova:	.db "MovR-XXXX",0
TextMovm:	.db "MovM-XXXX",0
TextMvia:	.db "MviR-XXXX",0
TextMvim:	.db "MviM-XXXX",0
TextNop:		.db "Nop--XXXX",0
TextOraa:		.db "OraR-XXXX",0
TextOram:	.db "OraM-XXXX",0
TextOri:		.db "Ori--XXXX",0
TextOut:		.db "Out--XXXX",0
TextPop:		.db "Pop--XXXX",0
TextPush:	.db "Push-XXXX",0
TextRnc:		.db "R*-N-XXXX",0
TextRc:		.db "R*-Y-XXXX",0
TextRal:		.db "Ral--XXXX",0
TextRar:		.db "Rar--XXXX",0
TextRet:		.db "Ret--XXXX",0
TextRlc:		.db "Rlc--XXXX",0
TextRrc:		.db "Rrc--XXXX",0
TextSbba:	.db "SbbR-XXXX",0
TextSbbm:	.db "SbbM-XXXX",0
TextSbi:		.db "Sbi--XXXX",0
TextShld:		.db "Shld-XXXX",0
TextSphl:		.db "Sphl-XXXX",0
TextSta:		.db "Sta--XXXX",0
TextStax:		.db "Stax-XXXX",0
TextStc:		.db "Stc--XXXX",0
TextSuba:	.db "SubR-XXXX",0
TextSubm:	.db "SubM-XXXX",0
TextSui:		.db "Sui--XXXX",0
TextXchg:	.db "Xchg-XXXX",0
TextXraa:		.db "XraR-XXXX",0
TextXram:	.db "XraM-XXXX",0
TextXri:		.db "Xri--XXXX",0
TextXthl:		.db "Xthl-XXXX",0
			.db " ",0
			.db "Mix",0
TextDadPchl:	.db "DadPchl-XXXX",0
TextRstRet:	.db "RstRet-XXXX",0

		.db 0
		.db "VM1",0
TextAnx:	.db "Anx--XXXX",0
TextDcmp:	.db "Dcmp-XXXX",0
TextDsub:	.db "Dsub-XXXX",0
TextJof:	.db "Jof--XXXX",0
TextLhlx:	.db "Lhlx-XXXX",0
TextMb:		.db "Mb/Cs-XXXX",0
TextOrx:	.db "Orx--XXXX",0
TextRs:		.db "Rs---XXXX",0
TextShlx:	.db "Shlx-XXXX",0
TextSmf0:	.db "Smf0-XXXX",0
TextSmf1:	.db "Smf1-XXXX",0
TextXrx:	.db "Xrx--XXXX",0

Text85:
		.db 0
		.db "VM85",0
TextArhl:	.db "Arhl-XXXX",0
TextDsub85:	.db "Dsub-XXXX",0
TextJk:		.db "Jk-Y-XXXX",0
TextJnk:	.db "JnkN-XXXX",0
TextLdhi:	.db "Ldhi-XXXX",0
TextLdsi:	.db "Ldsi-XXXX",0
TextShlx85:	.db "Shlx-XXXX",0
TextSim:	.db "Sim--XXXX",0
TextRdel:	.db "Rdel-XXXX",0
TextRim:	.db "Rim--XXXX",0
TextRstvN:	.db "RstvN-XXXX",0
TextRstvY:	.db "RstvYRetXXXX",0
TextLhlx85:	.db "Lhlx-XXXX",0

Count	.dw 0

#define col 173

colors:
		.db 0,col,0,col,0,col,0,col,0,col,0,col,0,col,0,col

Font:

End:
		.end
