tasm -85 -b deexo.asm deexo.bin
copy /B deexo.bin+basic25.exo basic25exo.bin
tasm -85 -b basicexo.asm basicexo.bin
copy /b basicexo.bin+basic25exo.bin basicexo.rom