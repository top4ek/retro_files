.include "deexohead.asm"

		.org	100h

		di
		xra	a
		out	10h
		lxi	h,deexo
		lxi	d,deexostart
		lxi	b,packedsize+deexosize
Mov:		mov	a,m
		stax	d
		inx	h
		inx	d
		dcx	b
		mov	a,b
		ora	c
		jnz	Mov

		lxi	h,0
		sphl
		xchg
		push	d
		lxi	h,deexostart+deexosize
		jmp	deexostart

deexo:

		.end