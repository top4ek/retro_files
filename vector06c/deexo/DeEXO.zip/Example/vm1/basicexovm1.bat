tasm -tvm1 -b deexo.asm deexo.bin
copy /B deexo.bin+basic25.exo basic25exo.bin
tasm -tvm1 -b basicexo.asm basicexo.bin
copy /b basicexo.bin+basic25exo.bin basicexo.rom